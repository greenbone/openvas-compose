"""Scoped OpenSSL credentials, independent of migration orchestration imports."""

import fcntl
import os
import select
import subprocess
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, List, Optional, Union


class Secret:
    """Interactive UTF-8 input retained in memory, with OpenSSL first-line semantics."""

    def __init__(self, value: bytes) -> None:
        self.value = value + b"\n"


Passphrase = Union[Path, Secret]


@contextmanager
def openssl_process(
    source: Passphrase, arguments: List[str], **options: Any
) -> Iterator["subprocess.Popen[Any]"]:
    """Start OpenSSL before feeding a fresh credential pipe; reap on every exit.

    Data stdin remains available to the caller. Only this child inherits the
    credential descriptor. Cancellation is bounded even when OpenSSL never reads
    the credential or exits before consuming a long first line.
    """
    diagnostic_label = options.pop("diagnostic_label", None)
    diagnostic_stdout = options.pop("diagnostic_stdout", "payload")
    diagnostic_stderr = options.pop("diagnostic_stderr", "diagnostic")
    record = None
    if diagnostic_label is not None:
        from process_diagnostics import ProcessRecord
        record = ProcessRecord(["openssl"] + arguments, diagnostic_label, diagnostic_stdout, diagnostic_stderr)
        options["stderr"] = subprocess.PIPE
    reader: Optional[int] = None
    writer: Optional[int] = None
    process: "Optional[subprocess.Popen[Any]]" = None
    feeder: Optional[threading.Thread] = None
    cancelled = threading.Event()
    outcome = None
    try:
        if isinstance(source, Path):
            credential = "file:" + str(source)
        else:
            reader, writer = os.pipe()
            fcntl.fcntl(
                writer,
                fcntl.F_SETFL,
                fcntl.fcntl(writer, fcntl.F_GETFL) | os.O_NONBLOCK,
            )
            credential = "fd:" + str(reader)
            options["pass_fds"] = (reader,)
        process = subprocess.Popen(
            ["openssl"] + arguments + ["-pass", credential], **options
        )
        if record is not None:
            record.watch("stderr", process.stderr)
        if reader is not None:
            os.close(reader)
            reader = None
        if writer is not None:
            assert isinstance(source, Secret)
            descriptor = writer
            payload = source.value

            def feed() -> None:
                offset = 0
                try:
                    while offset < len(payload) and not cancelled.is_set():
                        if not select.select([], [descriptor], [], 0.05)[1]:
                            continue
                        try:
                            offset += os.write(
                                descriptor, payload[offset : offset + 65536]
                            )
                        except BlockingIOError:
                            continue
                except BrokenPipeError:
                    # OpenSSL may stop after the first newline, or fail early.
                    pass
                finally:
                    os.close(descriptor)

            feeder = threading.Thread(target=feed, name="openssl-passphrase")
            feeder.start()
            writer = None  # The feeder owns and closes it from this point.
        yield process
    except BaseException as error:
        if record is not None:
            from process_diagnostics import failure_outcome
            outcome = failure_outcome(error, process)
        raise
    finally:
        cancelled.set()
        if reader is not None:
            os.close(reader)
        if writer is not None:
            os.close(writer)
        try:
            if process is not None:
                if process.poll() is None:
                    process.kill()
                process.wait()
        finally:
            if record is not None:
                record.finish(process.returncode if process is not None else None, outcome)
            if feeder is not None and feeder.ident is not None:
                feeder.join()
            if process is not None:
                for stream in (process.stdin, process.stdout, process.stderr):
                    if stream is not None:
                        stream.close()


def openssl_run(
    source: Passphrase, arguments: List[str], **options: Any
) -> "subprocess.CompletedProcess[Any]":
    """Run a bounded or streaming-input probe with the same credential lifetime."""
    label = options.pop("diagnostic_label", None)
    if label is not None:
        from process_diagnostics import run_command
        kind = options.pop("diagnostic_stdout", "payload")
        stderr_kind = options.pop("diagnostic_stderr", "diagnostic")
        data = options.pop("input", None)
        timeout = options.pop("timeout", None)
        check = options.pop("check", False)
        target = options.pop("stdout", subprocess.PIPE)
        options.pop("stderr", None)
        result = run_command(["openssl"] + arguments, label, data=data,
                             timeout=timeout, env=options.pop("env", None),
                             stdout_kind=kind, stderr_kind=stderr_kind,
                             stdout_target=target,
                             opener=lambda **launch: openssl_process(source, arguments, **launch))
        if check:
            result.check_returncode()
        return result
    data = options.pop("input", None)
    timeout = options.pop("timeout", None)
    check = options.pop("check", False)
    if data is not None:
        options["stdin"] = subprocess.PIPE
    with openssl_process(source, arguments, **options) as process:
        stdout, stderr = process.communicate(data, timeout=timeout)
        result = subprocess.CompletedProcess(
            process.args, process.returncode, stdout, stderr
        )
        if check:
            result.check_returncode()
        return result
