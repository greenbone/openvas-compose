"""Shared destructive restoration, with verified data kept stopped for activation."""

import copy
from datetime import datetime
import fcntl
import hashlib
import json
import logging
import os
import re
import select
import signal
import stat
import subprocess
import threading
import time
from contextlib import ExitStack, contextmanager
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Set, Tuple

from guard import installation_identity
from diagnostics import customer, technical, failure, prompt as record_prompt

from capture import (
    ENCRYPTION,
    format_duration,
    Snapshot,
    application_name,
    check_stopped,
    identifier,
    inspect_archive,
    inventory,
    phase,
    reconcile_work,
    work_environment,
    work_identity,
)
from destination import PROVISION, Destination
from main import WRITERS, DeploymentPrerequisite, MigrationError, MigrationCancelled, discover, docker, execute, sql
from passphrase import Passphrase, openssl_process
from process_diagnostics import observed_process
from validation import SOURCE_TARGETS, Backup, SourceMapping, transform_expectations


def simple_mappings() -> "Dict[str, SourceMapping]":
    """Inspected Y Notification/Keycloak contracts; 07/08 supply other mappings."""
    return {
        "notification-service": SourceMapping(
            "notification",
            "notification-user",
            relation_moves={
                ("public", "schema_migrations"): "notification_service_migration_state"
            },
        ),
        "keycloak": SourceMapping("keycloak", "keycloak-user"),
    }


def control_identity(daemon: str, project: str) -> str:
    """Stable daemon/project restore attribution, independent of backup and journal."""
    return hashlib.sha256(
        json.dumps(["restore-control", daemon, project], separators=(",", ":")).encode()
    ).hexdigest()[:32]


def cleanup_lease(daemon: str, project: str) -> Path:
    """Name the local helper lease shared with the installation restore lock."""
    installation = hashlib.sha256(
        json.dumps([daemon, project], separators=(",", ":")).encode()
    ).hexdigest()
    return Path("/tmp") / f"osi-migration-cleanup-{installation}.lock"


@contextmanager
def restore_lock(daemon: str, project: str) -> Iterator[None]:
    """Hold a nonblocking installation restore lock through cleanup and activation.

    Args:
        daemon: Preflight-accepted local Docker daemon identity.
        project: Selected Compose installation. Different backups for this identity
            share the lock; dump and explicit deployment do not acquire this lock.

    Yields:
        Control while owning the kernel lock. Closing its descriptor releases it,
        including process exit; the lock file is intentionally retained in /tmp.

    Raises:
        MigrationError: Another restore owns the installation lock.
        OSError: The lock file cannot be opened safely or locked."""
    installation = hashlib.sha256(
        json.dumps([daemon, project], separators=(",", ":")).encode()
    ).hexdigest()
    path = Path("/tmp") / f"osi-migration-restore-{installation}.lock"
    descriptor = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise MigrationError(
                "Another restore process is already active for this installation."
            ) from None
        # A Docker cleanup helper can outlive a killed host command. Its lease
        # remains held until deletion exits; no competing restore may pass it.
        lease = os.open(
            cleanup_lease(daemon, project),
            os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW,
            0o600,
        )
        try:
            metadata = os.fstat(lease)
            if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != os.getuid():
                raise MigrationError("Invalid local cleanup operation lease ownership")
            try:
                fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise MigrationError(
                    "Legacy cleanup is still active for this installation"
                ) from None
        finally:
            os.close(lease)
        with work_identity("restore", control_identity(daemon, project)):
            yield
    finally:
        os.close(descriptor)


DEPLOYMENT_WARNING = (
    "IMPORTANT:\nAny changes made after the dump are not included in the backup.\n"
    "Upgrade to OPENVAS Security Intelligence 1.7.0 must have finished before restoration.\n"
    "Restoration can still be attempted if the deployment ended with an error.\n"
    "In this case, the script checks that database initialization succeeded and required service components are available.\n\n"
    "Do not restart, upgrade or reconfigure the deployment, until the restore finishes."
)
DEPLOYMENT_PROMPT = "Has the upgrade to OPENVAS Security Intelligence 1.7.0 finished? [y/N] "
REPLACEMENT_PROMPT = (
    "Discard the existing data listed above and start restoration? [y/N] "
)

COMPLETED_REPLACEMENT_PROMPT = (
    "Discard the completed migration and subsequent writes in all four mapped databases and restore the selected backup? [y/N] "
)


def affirmative_confirmation(prompt: str, refusal: str, *, action: str = "") -> None:
    """Require affirmative input from a terminal, treating absent input as refusal."""
    import sys

    from main import RestoreBlocker

    def refuse(message: str) -> None:
        if action:
            raise RestoreBlocker(message, action)
        raise MigrationError(message)

    record_prompt(prompt)
    if not sys.stdin.isatty():
        technical("Confirmation unavailable: no interactive terminal", logging.INFO)
        refuse(refusal + "; no interactive terminal is available")
    try:
        answer = input(prompt).strip().lower()
    except (EOFError, KeyboardInterrupt, MigrationError):
        technical("Confirmation interrupted or unavailable", logging.INFO)
        refuse(refusal)
    if answer not in ("y", "yes"):
        technical("Confirmation declined", logging.INFO)
        refuse(refusal)
    technical("Confirmation accepted", logging.INFO)


CAPTURE_TIME_PROMPT = (
    "Restore this backup? [y/N] "
)


def confirm_backup_capture(metadata: Dict[str, Any], *, confirmed: bool = False) -> None:
    """Show capture time and require new acknowledgement for this restore attempt."""
    from datetime import datetime, timezone
    import sys
    from main import RestoreAcknowledgementRefused, RestoreBlocker
    from validation import backup_capture_time

    captured = backup_capture_time(metadata)
    elapsed = (datetime.now(timezone.utc) - captured).total_seconds()
    remaining = int(abs(elapsed))
    parts = []
    for label, size in (("day", 86400), ("hour", 3600), ("minute", 60), ("second", 1)):
        count, remaining = divmod(remaining, size)
        if count or (size == 1 and not parts):
            parts.append(f"{count} {label}{'s' if count != 1 else ''}")
    relative = ", ".join(parts) + (" ago" if elapsed >= 0 else " in the future")
    customer("----------")
    customer("Backup capture time: " + captured.strftime("%Y-%m-%d %H:%M:%S UTC") + " — " + relative)
    if elapsed > 5 * 60 * 60:
        customer("WARNING: the backup is more than 5 hours old", level=logging.WARNING)
    customer("----------")
    if elapsed < 0:
        customer("WARNING: The backup capture time is inconsistent with the current host time: it is in the future. Check the host clock.", level=logging.WARNING)
    customer(
        "Restoring this backup replaces the current destination databases. "
        "Changes made after the backup are NOT included.\n"
        "If you are using an outdated backup, decline confirmation and follow the printed steps to create a fresh backup.",
        level=logging.WARNING,
        flush=True,
    )
    if confirmed:
        technical("Restore data-loss acknowledgement supplied by --confirm-restore", logging.INFO)
        return
    refusal = "Restoration was not confirmed; services and database data are unchanged"
    try:
        affirmative_confirmation(CAPTURE_TIME_PROMPT, refusal, action="Restore acknowledgement required")
    except (RestoreBlocker, OSError):
        technical("Restore data-loss acknowledgement refused or unavailable", logging.INFO)
        hint = ("To restore this backup, rerun with --confirm-restore."
                if sys.stdin.isatty() else
                "No interactive terminal is available. To confirm restoration non-interactively, rerun with --confirm-restore.")
        raise RestoreAcknowledgementRefused(
            refusal, hint + " Otherwise, to create a fresh backup, follow this sequence:",
        ) from None


REPLACE_COMPLETED_GUIDANCE = (
    "To start over from the selected backup, run the restore with --replace-completed. "
    "This replaces the restored database data and discards changes made to it since the previous restore."
)
RETRY_GUIDANCE = (
    "The restore did not finish. Do not use OPENVAS Security Intelligence yet.\n\n"
    "Retry the restore with the same backup. The restore will resume from established completed phases. "
    "You may need to enter the backup passphrase and confirm that existing database data can be replaced.\n\n"
    "Keep the backup until the restore finishes successfully."
)


def literal(value: str) -> str:
    """Quote a trusted PostgreSQL string literal by doubling embedded quotes.

    Args:
        value: String content used in generated SQL with the normal PostgreSQL
            standard-conforming-string setting; this is not identifier quoting.

    Returns:
        Single-quoted literal text without executing SQL."""
    return "'" + value.replace("'", "''") + "'"


@contextmanager
def restore_signals() -> Iterator[None]:
    """Convert the first SIGINT/SIGTERM into failure and suppress repeat cancellation.

    Use on the main thread. Restore previous handlers on exit. This context does
    not clean up services itself: callers must retain journals and run cleanup.

    Yields:
        Control to the protected restore operation.

    Raises:
        MigrationError: The first cancellation signal arrives within the context."""
    cancelled = False

    def interrupt(number: int, frame: Any) -> None:
        nonlocal cancelled
        if cancelled:
            return
        cancelled = True
        raise MigrationCancelled(
            f"Restore cancelled by signal {number}"
        )

    previous = {n: signal.getsignal(n) for n in (signal.SIGINT, signal.SIGTERM)}
    for number in previous:
        signal.signal(number, interrupt)
    try:
        yield
    finally:
        for number, handler in previous.items():
            signal.signal(number, handler)


def migration_jobs(services: Dict[str, Any]) -> List[str]:
    """Select discovered application migration jobs without changing their lifecycle.

    Args:
        services: Current discovered service mapping.

    Returns:
        Names ending in -migration, the Keycloak sidecar and destination initializer.
        Upgrade jobs remain excluded; callers stop selected jobs without changing policies."""
    return [
        name
        for name in services
        if name.endswith("-migration") or name in ("keycloak-sidecar", "osi-postgres-init")
    ]


def prepare_services(project: str, services: Dict[str, Any]) -> None:
    """Reestablish stopped writers and disabled restart after partial preparation.

    Sets writer/ingress policies to no and stops them plus migration jobs, leaving
    job policies intact. Attempts remaining operations after command failures;
    does not save previous policies/states or restart on cancellation.

    Args:
        project: Selected installation, re-discovered for final state checks.
        services: Current container identities. Caller holds restore_lock and records
            preparation intent durably before changing lifecycle state.

    Raises:
        MigrationError: Stopped/no state cannot be established and verified."""
    technical(f"Restore preparation: intent=disable restart and stop writers; project={project}")
    technical("Initializer coordination: intent=stop and check; service=osi-postgres-init")
    errors = []
    for name in [*WRITERS, "ingress"]:
        try:
            docker(
                "update",
                "--restart=no",
                services[name]["Id"],
                step=f"Disable automatic restart {name}",
            )
        except MigrationError as exc:
            errors.append(exc)
    for name in ["ingress", *WRITERS, *migration_jobs(services)]:
        try:
            docker("stop", services[name]["Id"], step=f"Stop {name}")
        except MigrationError as exc:
            errors.append(exc)
    check_stopped(project, ["ingress", *WRITERS, *migration_jobs(services)])
    _, current = discover(project)
    for name in [*WRITERS, "ingress"]:
        if current[name]["HostConfig"]["RestartPolicy"]["Name"] != "no":
            errors.append(MigrationError(f"Automatic restart is not disabled: {name}"))
    if errors:
        technical("Restore preparation outcome: state=unknown; lifecycle operation failed", logging.WARNING)
        raise errors[0]
    if "osi-postgres-init" in current and "osi-postgres-init" in services:
        technical("Initializer coordination: observed=stopped; service=osi-postgres-init")
    else:
        technical("Initializer coordination: observed=unavailable; service=osi-postgres-init")
    technical("Restore preparation outcome: state=confirmed stopped; restart policies=disabled")


def cleanup_failure(project: str, services: Dict[str, Any], work_id: str, *, report_observations: bool = True) -> bool:
    """Reconcile owned work and reattempt stopped/no policies without masking failure."""
    technical(f"Restore recovery: intent=reconcile owned work and establish stopped state; project={project}; recovery_id={work_id}")
    reconciled = False
    stopped = False
    try:
        reconcile_work(services, work_id, "restore")
        reconciled = True
    except Exception as error:
        failure(error, "restore recovery reconciliation failure")
        if report_observations:
            customer("Could not confirm that previous restore work has stopped.",
                     level=logging.WARNING, flush=True)
    try:
        _, current = discover(project)
        prepare_services(project, current)
        stopped = True
    except Exception as error:
        failure(error, "restore recovery service failure")
        if report_observations:
            customer("Could not confirm that all services are safely stopped.",
                     level=logging.WARNING, flush=True)

    technical("Restore recovery outcome: state={}; owned work={}; services={}".format(
        "confirmed stopped" if stopped and reconciled else "unknown",
        "confirmed stopped" if reconciled else "unknown",
        "confirmed stopped" if stopped else "unknown"),
        logging.INFO if stopped and reconciled else logging.WARNING)
    return stopped and reconciled


def reflect(container: Any, database: str) -> Dict[str, Any]:
    """Read catalog definitions, counts and sequence state in one exporter session.

    Args:
        container: Running PostgreSQL container with administrative credential access.
        database: Database to inspect while the caller keeps product writers stopped.

    Returns:
        Reflected inventory, after closing the exporter. No application payloads are
        copied and this does not prove full row-content equivalence.

    Raises:
        MigrationError: Exporter or inventory query fails.
        OSError: Exporter process or pipe access fails.
        ValueError: A reflected response cannot be decoded."""
    snapshot = Snapshot(container, database)
    try:
        return inventory(snapshot)
    finally:
        snapshot.close()


def report_existing_data(container: Any, destination: Destination) -> bool:
    """List nonempty application tables before asking for replacement consent.

    The snapshot is advisory: applications may still write until stopped. The
    later stopped-state inspection remains the authoritative safety check.
    """
    inspected_at = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")
    names = set(json.loads(sql(container, "postgres", "SELECT json_agg(datname) FROM pg_database")) or [])
    migration_schemas = {
        "asset_management_backend_migration_state",
        "vulnerability_intelligence_backend_migration_state",
        "notification_service_migration_state", "tunnel_migration_state",
    }
    history_tables = {"django_migrations", "schema_migrations", "_sqlx_migrations"}
    huey_tables = {"kv", "schedule", "task", "counter"}
    default_tables = {
        (destination.management_console.database, "public", "auth_permission"),
        (destination.management_console.database, "public", "django_content_type"),
        (destination.management_console.database, "public", "system_management_appliance_filter_options"),
        (destination.notification.database, "notification_service", "origins"),
        (destination.asset_management.database, "application", "asset_severity_summary_readiness"),
        (destination.asset_management.database, "application", "setting"),
    }
    found = []
    for database in destination.databases:
        if database == destination.keycloak.database or database not in names:
            continue
        for relation in reflect(container, database)["relations"]:
            schema, name = relation["schema"], relation["name"]
            if relation["kind"] not in ("r", "p") or not relation["rows"]:
                continue
            if schema in migration_schemas or name in history_tables:
                continue
            if database == destination.management_console.database and schema == "public" and name in huey_tables:
                continue
            if (database, schema, name) in default_tables:
                continue
            found.append((database, schema, name, relation["rows"]))
    if not found:
        return False
    customer(f"The following data was found in the datastore (as of {inspected_at}):")
    for database, schema, name, rows in sorted(found):
        customer(f"  {database}.{schema}.{name}: {rows} rows")
    customer("Especially if a previous restore attempt failed, this data can be safely discarded to retry.")
    return True


@contextmanager
def restore_progress(source: str) -> Iterator[None]:
    """Report progress while one archive is restored and transformed."""
    started = time.monotonic()
    done = threading.Event()
    customer(f"  Starting restore: {source}")

    def heartbeat() -> None:
        from capture import PROGRESS_INTERVAL
        while not done.wait(PROGRESS_INTERVAL):
            try:
                customer(f"  Restore in progress: {source} ({format_duration(time.monotonic() - started)} elapsed)")
            except OSError:
                return

    worker = threading.Thread(target=heartbeat)
    worker.start()
    try:
        yield
    finally:
        done.set()
        worker.join()
    customer(f"  Restore complete: {source} — {format_duration(time.monotonic() - started)}")


def comparable(data: Dict[str, Any]) -> Dict[str, Any]:
    """Compare observable source structure/state; extension owner is infrastructure."""
    result = copy.deepcopy(
        {
            key: data[key]
            for key in (
                "schemas",
                "relations",
                "functions",
                "types",
                "extensions",
                "large_objects",
            )
        }
    )
    for category in ("relations", "functions", "types", "extensions"):
        for item in result[category]:
            if category == "extensions" or item.get("extension"):
                item.pop("owner", None)
            if category == "relations" and item["kind"] in ("i", "I"):
                # pg_restore rebuilds indexes from current parent columns. A
                # preexisting index can retain old physical attribute names
                # after ALTER TABLE RENAME COLUMN; they are not table-column
                # identities. Keep ordered types/flags and index definition.
                for column in item["columns"]:
                    column.pop("name", None)
        result[category].sort(key=lambda item: json.dumps(item, sort_keys=True))
    result["schemas"].sort()
    return result


def inventory_differences(
    expected: Dict[str, Any], actual: Dict[str, Any]
) -> Iterator[str]:
    """Describe differences in comparable inventories without emitting definitions.

    Object names and numeric measurements are shareable technical context. Every
    other changed property is named only: even a default or enum can contain data.
    """
    for schema in sorted(set(expected["schemas"]) - set(actual["schemas"])):
        yield f"schema={schema}; missing object"
    for schema in sorted(set(actual["schemas"]) - set(expected["schemas"])):
        yield f"schema={schema}; unexpected object"
    if expected["large_objects"] != actual["large_objects"]:
        yield "property=large_objects; expected={}; actual={}".format(
            expected["large_objects"], actual["large_objects"])
    for category in ("relations", "functions", "types", "extensions"):
        def identity(item: Dict[str, Any]) -> Tuple[str, str, str]:
            # Input type identities distinguish overloaded functions. Their SQL
            # definitions and identity-argument text are never log material.
            arguments = json.dumps(item.get("arguments", []), ensure_ascii=True)
            return (
                item.get("schema", ""), item["name"],
                arguments if category == "functions" else "",
            )

        before = {identity(item): item for item in expected[category]}
        after = {identity(item): item for item in actual[category]}
        for key in sorted(set(before) | set(after)):
            schema, name, arguments = key
            label = f"category={category}; object={schema + '.' if schema else ''}{name}"
            if arguments:
                label += f"; input types={arguments}"
            if key not in after:
                yield f"{label}; missing object"
                continue
            if key not in before:
                yield f"{label}; unexpected object"
                continue
            left, right = before[key], after[key]
            for property_name in sorted(set(left) | set(right)):
                if left.get(property_name) == right.get(property_name):
                    continue
                if (
                    property_name in ("sequence", "sequence_definition")
                    and isinstance(left.get(property_name), dict)
                    and isinstance(right.get(property_name), dict)
                ):
                    for field in sorted(set(left[property_name]) | set(right[property_name])):
                        old = left[property_name].get(field)
                        new = right[property_name].get(field)
                        if old != new:
                            detail = f"{label}; property={property_name}.{field}"
                            if type(old) in (int, bool) and type(new) in (int, bool):
                                detail += f"; expected={old}; actual={new}"
                            yield detail
                else:
                    detail = f"{label}; property={property_name}"
                    if (
                        property_name == "rows"
                        and type(left.get(property_name)) is int
                        and type(right.get(property_name)) is int
                    ):
                        detail += f"; expected={left[property_name]}; actual={right[property_name]}"
                    yield detail


def report_inventory_differences(
    database: str, expected: Dict[str, Any], actual: Dict[str, Any]
) -> None:
    """Count every mismatch while retaining at most fifty diagnostic details."""
    total = 0
    for total, difference in enumerate(inventory_differences(expected, actual), 1):
        if total <= 50:
            technical(f"Verification difference: database={database}; {difference}")
    technical(
        f"Verification differences: database={database}; total={total}; "
        f"reported={min(total, 50)}; omitted={max(total - 50, 0)}"
    )


def bootstrap_extensions(
    container: Any, expectations: Dict[str, Dict[str, Any]], destination: "Destination"
) -> Set[str]:
    """Reconcile shared bootstrap policy with captured, available extensions.

    Missing bootstrap infrastructure uses the installed image's default version.
    Captured versions remain authoritative when available and in the required
    schema. Return the names whose extension-owned inventory is destination-only.
    This read-only planning must finish before any database deletion.
    """
    plan = execute(
        container,
        "sh",
        PROVISION,
        "bootstrap-plan",
        application_name(),
        step="Read shared bootstrap extension policy",
    )
    if not plan:
        raise MigrationError("Missing shared bootstrap extension policy")
    expected = expectations[destination.databases[0]]
    added: Set[str] = set()
    for row in plan.splitlines():
        fields = row.split("\t")
        if len(fields) != 3 or not all(fields):
            raise MigrationError("Invalid shared bootstrap extension policy")
        name, schema, names = fields
        reserved = set(names.split(","))
        for category in ("relations", "types", "functions"):
            for item in expected[category]:
                if item.get("extension") == name or item["schema"] != schema:
                    continue
                identities = {
                    item["name"],
                    item.get("row_type"),
                    item.get("array_type"),
                }
                if identities & reserved:
                    raise MigrationError(
                        "Source object collides with destination bootstrap infrastructure"
                    )
        captured = next(
            (item for item in expected["extensions"] if item["name"] == name), None
        )
        if captured is not None:
            if captured["schema"] != schema:
                raise MigrationError(
                    "Captured extension conflicts with destination bootstrap schema"
                )
            continue
        version = sql(
            container,
            "postgres",
            "SELECT default_version FROM pg_available_extensions "
            f"WHERE name={literal(name)}",
        )
        if not version:
            raise MigrationError(
                "Required bootstrap extension is unavailable on destination PostgreSQL"
            )
        expected["extensions"].append(
            {"name": name, "schema": schema, "version": version}
        )
        if schema not in expected["schemas"]:
            expected["schemas"].append(schema)
        added.add(name)
    return added


def include_bootstrap_inventory(
    container: Any, expected: Dict[str, Any], database: str, extensions: Set[str]
) -> None:
    """Include destination-only extension objects before importing application data."""
    if not extensions:
        return
    infrastructure = reflect(container, database)
    for category in ("relations", "types", "functions"):
        expected[category].extend(
            item
            for item in infrastructure[category]
            if item.get("extension") in extensions
        )


def verify(container: Any, expectations: Dict[str, Dict[str, Any]]) -> None:
    """Reflect each mapped database and require transformed inventory agreement.

    Writers must remain stopped. Definitions, exact counts and sequence state
    are checked without emitting SQL literals; mismatch raises MigrationError.
    Agreement does not establish full row-content or application equivalence.

    Args:
        container: Administrative destination PostgreSQL container.
        expectations: Validated transformed inventory by destination database.

    Raises:
        MigrationError: Reflection fails or inventory differs from expectations.
    """
    for database, expected in expectations.items():
        actual = reflect(container, database)
        actual_comparable, expected_comparable = comparable(actual), comparable(expected)
        if actual_comparable != expected_comparable:
            report_inventory_differences(database, expected_comparable, actual_comparable)
            # Definitions may include SQL literals; never emit a raw metadata diff.
            raise MigrationError(
                f"Restored inventory mismatch: {database}; structure/counts/sequence state differ"
            )
        technical(
            f"Verified {database}: structure, exact row counts and sequence state; counts do not prove full content equivalence.",
            flush=True,
        )


def recreate(
    container: Any, expectations: Dict[str, Dict[str, Any]], destination: "Destination"
) -> None:
    """Destructively recreate only the four supported mapped databases.

    Caller must hold the installation restore lock, validate backup/capacity,
    authorize replacement and stop writers with restart disabled. Connect via
    postgres so a missing mapped database remains recoverable. Reestablish
    bootstrap public privileges and supported extensions. Private schema owners
    derive from validated mapped objects; multi-owner schemas grant only those
    mapped roles. Does not restore source ACLs or grant every database role
    access to every schema. SQL failure propagates; retain stopped services
    for a full retry.

    Args:
        container: Administrative destination PostgreSQL container.
        expectations: Validated inventory defining destination infrastructure.
        destination: The same resolved identifiers used for deletion and replay.

    Raises:
        MigrationError: A destructive SQL or privilege operation fails.
    """
    for database in destination.databases:
        sql(
            container,
            "postgres",
            f"DROP DATABASE IF EXISTS {identifier(database)} WITH (FORCE)",
        )
    execute(
        container,
        "sh",
        PROVISION,
        "databases",
        application_name(),
        *destination.databases,
        *destination.roles,
        step="Provision mapped destination databases",
    )
    for database, roles in destination.database_roles.items():
        for schema in expectations[database]["schemas"]:
            if schema == "public":
                continue
            sql(
                container,
                database,
                f"CREATE SCHEMA IF NOT EXISTS {identifier(schema)}",
            )
            # Y application migrations create private schemas as their own roles.
            # Use validated mapped objects, including relocated histories, to
            # reproduce that ownership. Extension-only infrastructure stays admin.
            owners = sorted(
                {
                    item["owner"]
                    for category in ("relations", "types", "functions")
                    for item in expectations[database][category]
                    if item["schema"] == schema
                    and not item.get("extension")
                    and item["owner"] in roles
                }
            )
            if len(owners) == 1:
                sql(
                    container,
                    database,
                    f"ALTER SCHEMA {identifier(schema)} OWNER TO {identifier(owners[0])}",
                )
            elif owners:
                sql(
                    container,
                    database,
                    f"GRANT USAGE, CREATE ON SCHEMA {identifier(schema)} TO "
                    + ", ".join(identifier(role) for role in owners),
                )
        for extension in expectations[database]["extensions"]:
            if extension["name"] == "plpgsql":
                continue
            execute(
                container,
                "sh",
                PROVISION,
                "extension",
                application_name(),
                database,
                extension["name"],
                extension["schema"],
                extension["version"],
                step="Provision validated extension",
            )


def restore_archive(
    container: Any,
    path: Path,
    passphrase: Passphrase,
    database: str,
    toc: str,
    work_id: str,
) -> None:
    # Schema/extension infrastructure is created once. Never replay source ACLs
    # or source database creation. The TOC contains object names, never row data.
    """Stream ciphertext through OpenSSL into fail-fast pg_restore.

    Caller supplies a prevalidated bounded TOC, recreated destination and owned
    work identity with writers stopped. Filter shared infrastructure and source
    ACL/ownership entries; use a FIFO for the object list without disk plaintext.
    Check every producer/consumer exit and reap blocked helpers on failure;
    partial database writes require recreation before retry.

    Args:
        container: Administrative destination PostgreSQL container.
        path: Prevalidated encrypted custom-format archive.
        passphrase: Protected operator passphrase file.
        database: Recreated mapped destination database.
        toc: Bounded object listing retained by archive validation.
        work_id: Durable identity used to attribute and reconcile this attempt.

    Raises:
        MigrationError: FIFO setup, decryption or streamed restoration fails.
        OSError: A required file or producer/consumer process is inaccessible.
    """
    with ExitStack() as processes:
        filtered = (
            "\n".join(
                line
                for line in toc.splitlines()
                if not re.match(r"^\d+; \d+ \d+ (?:SCHEMA|EXTENSION) ", line)
            )
            + "\n"
        )
        tocpath = f"/tmp/osi-restore-{work_id}.list"
        script = (
            'set -eu; export PGPASSWORD="$(cat "$POSTGRES_PASSWORD_FILE")"; '
            'export PGAPPNAME="$3"; exec pg_restore -w -h 127.0.0.1 -U "$POSTGRES_USER" '
            '--no-owner --no-acl --exit-on-error --use-list "$2" --dbname "$1"'
        )
        decrypt: "Optional[subprocess.Popen[bytes]]" = None
        consumer: "Optional[subprocess.Popen[bytes]]" = None
        feeder: "Optional[subprocess.Popen[bytes]]" = None
        try:
            docker(
                "exec",
                "--env",
                "PGAPPNAME=" + application_name(),
                container["Id"],
                "sh",
                "-ceu",
                'umask 077; test ! -e "$1"; mkfifo "$1"',
                "toc",
                tocpath,
                step="Prepare archive object-list FIFO; no plaintext staging",
            )
            decrypt = processes.enter_context(
                openssl_process(
                    passphrase,
                    ["enc", "-d", *ENCRYPTION, "-in", str(path)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    env=work_environment(),
                    diagnostic_label="decrypt restore archive " + path.name,
                )
            )
            assert decrypt.stdout is not None
            consumer = processes.enter_context(observed_process(
                [
                    "docker",
                    "exec",
                    "-i",
                    "--env",
                    "PGAPPNAME=" + application_name(),
                    container["Id"],
                    "sh",
                    "-ceu",
                    script,
                    "restore",
                    database,
                    tocpath,
                    application_name(),
                ],
                "restore archive " + database,
                stdout_kind="diagnostic",
                stderr_kind="sql",
                stdin=decrypt.stdout,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=work_environment(),
            ))
            decrypt.stdout.close()
            feeder = processes.enter_context(observed_process(
                [
                    "docker",
                    "exec",
                    "--env",
                    f"PGAPPNAME={application_name()}",
                    "-i",
                    container["Id"],
                    "sh",
                    "-ceu",
                    'cat > "$1"',
                    "toc",
                    tocpath,
                ],
                "feed restore object list " + database,
                stdout_kind="diagnostic",
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=work_environment(),
            ))
            payload = filtered.encode()
            deadline = time.monotonic() + 60
            assert feeder.stdin is not None
            descriptor = feeder.stdin.fileno()
            fcntl.fcntl(descriptor, fcntl.F_SETFL,
                        fcntl.fcntl(descriptor, fcntl.F_GETFL) | os.O_NONBLOCK)
            offset = 0
            while offset < len(payload):
                if time.monotonic() >= deadline:
                    raise MigrationError(
                        "Archive object-list feeder failed or stalled"
                    )
                if not select.select([], [descriptor], [], 0.1)[1]:
                    if consumer.poll() is not None:
                        raise MigrationError(
                            "Archive object-list feeder failed or stalled"
                        )
                    continue
                try:
                    offset += os.write(descriptor, payload[offset:offset + 65536])
                except BlockingIOError:
                    continue
                except BrokenPipeError:
                    break
            feeder.stdin.close()
            while True:
                try:
                    feeder.wait(timeout=1)
                    break
                except subprocess.TimeoutExpired:
                    if consumer.poll() is not None or time.monotonic() >= deadline:
                        raise MigrationError(
                            "Archive object-list feeder failed or stalled"
                        ) from None
            restored = consumer.wait()
            decrypted = decrypt.wait()
            if restored or decrypted or feeder.returncode:
                raise MigrationError(
                    f"Streamed restoration failed: {database}"
                )
        finally:
            for process in (feeder, consumer):
                if process is not None and process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
            execute(
                container,
                "rm",
                "-f",
                tocpath,
                step="Remove archive object list",
            )


def apply_mapping(
    container: Any,
    database: str,
    original: Dict[str, Any],
    mapping: "SourceMapping",
    transformed: Dict[str, Any],
) -> None:
    """Apply only inspected object relocations and explicit ownership grants.

    The archive must already be restored while writers remain stopped; original
    inventory and transformed expectations must share one validated mapping.
    Follow reflected table dependencies without changing row payloads. Unsupported
    relocation or SQL failure aborts the attempt for caller-managed reset.

    Args:
        container: Administrative destination PostgreSQL container.
        database: Destination containing the just-restored source objects.
        original: Validated reflected inventory of the source archive.
        mapping: Inspected release-specific placement and ownership contract.
        transformed: Expected destination inventory for these source objects.

    Raises:
        MigrationError: A requested relocation or SQL ownership operation fails.
    """
    for source, target_schema in mapping.schema_moves.items():
        if source != target_schema:
            # Destination schema was reserved by bootstrap; source schema arrives
            # via source-named infrastructure prepared immediately before archive.
            raise MigrationError(
                "Whole-schema relocation requires explicit supported mapping; use relation migration-state relocation"
            )
    for relation in original["relations"]:
        identity = relation["schema"], relation["name"]
        target = mapping.relation_moves.get(identity)
        if (
            target
            and target != relation["schema"]
            and relation["kind"] not in ("i", "I")
            and not relation.get("sequence_owner")
        ):
            kind = {
                "r": "TABLE",
                "p": "TABLE",
                "v": "VIEW",
                "m": "MATERIALIZED VIEW",
                "S": "SEQUENCE",
            }[relation["kind"]]
            sql(
                container,
                database,
                f"ALTER {kind} {identifier(identity[0])}.{identifier(identity[1])} SET SCHEMA {identifier(target)}",
            )
    # Owner changes are applied to the validated dependency closure. Index/row/
    # array ownership follows parent ALTER; changing an owned sequence separately
    # would conflict with its parent. Extension-owned infrastructure remains admin.
    for category in ("relations", "types", "functions"):
        for item in transformed[category]:
            if item.get("extension"):
                continue
            name = identifier(item["schema"]) + "." + identifier(item["name"])
            if category == "relations":
                if item["kind"] in ("i", "I") or item.get("sequence_owner"):
                    continue
                kind = {
                    "r": "TABLE",
                    "p": "TABLE",
                    "v": "VIEW",
                    "m": "MATERIALIZED VIEW",
                    "S": "SEQUENCE",
                }[item["kind"]]
            elif category == "types":
                if item["kind"] == "m":
                    continue
                kind = "DOMAIN" if item["kind"] == "d" else "TYPE"
            else:
                kind = (
                    "PROCEDURE"
                    if item["definition"]
                    .lstrip()
                    .startswith("CREATE OR REPLACE PROCEDURE")
                    else "FUNCTION"
                )
                name += (
                    "("
                    + ", ".join(
                        identifier(arg[0]) + "." + identifier(arg[1])
                        for arg in item["arguments"]
                    )
                    + ")"
                )
            sql(
                container,
                database,
                f'ALTER {kind} {name} OWNER TO {identifier(item["owner"])}',
            )
    if original["large_objects"]:
        if mapping.owner is None or mapping.object_owners:
            raise MigrationError("Large objects need one inspected destination owner")
        oids = json.loads(
            sql(
                container,
                database,
                "SELECT coalesce(json_agg(oid),'[]') FROM pg_largeobject_metadata",
            )
        )
        for oid in oids:
            sql(
                container,
                database,
                f"ALTER LARGE OBJECT {int(oid)} OWNER TO {identifier(mapping.owner)}",
            )


def prepare_data(
    validated: Backup, daemon: str, project: str, services: Dict[str, Any],
    mappings: "Dict[str, SourceMapping]", destination: Destination,
) -> "Tuple[Dict[str, Dict[str, Any]], Set[str]]":
    """Validate the complete read-only data plan before completion invalidation."""
    expectations = transform_expectations(
        validated.metadata, mappings, targets=destination.targets()
    )
    database_roles = destination.database_roles
    installation = installation_identity(project)
    if validated.manifest["installation"] != installation:
        raise MigrationError("Validated backup belongs to another installation")
    for database, expected in expectations.items():
        for category in ("relations", "types", "functions"):
            if any(
                not item.get("extension")
                and item["owner"] not in database_roles[database]
                for item in expected[category]
            ):
                raise MigrationError(
                    f"Unsupported destination object owner: {database}"
                )
    for source, mapping in mappings.items():
        if mapping.schema_moves:
            raise MigrationError(
                "Whole-schema relocation unsupported; inspected relation moves are required"
            )
        if validated.metadata["databases"][source]["large_objects"] and (
            mapping.owner is None or mapping.object_owners
        ):
            raise MigrationError("Large objects need one inspected destination owner")
    container = services["osi-postgres"]
    if (
        sql(
            container,
            "postgres",
            "SELECT rolsuper FROM pg_roles WHERE rolname=current_user",
        )
        != "t"
    ):
        raise DeploymentPrerequisite(
            "Destination bootstrap connection must have administrative restoration privileges"
        )
    available = set(
        json.loads(sql(container, "postgres", "SELECT json_agg(rolname) FROM pg_roles"))
    )
    if not set(destination.roles) <= available:
        raise DeploymentPrerequisite(
            "Required database roles are missing. Restart the deployment and wait for database initialization to succeed, then retry restoration.",
            restore_fact="Required database roles are missing.", category="initialization",
        )
    extensions = {
        tuple(value)
        for value in json.loads(
            sql(
                container,
                "postgres",
                "SELECT coalesce(json_agg(json_build_array(name,version)),'[]') FROM pg_available_extension_versions",
            )
        )
    }
    if any(
        (extension["name"], extension["version"]) not in extensions
        for expected in expectations.values()
        for extension in expected["extensions"]
    ):
        raise MigrationError(
            "A captured extension version is unavailable on destination PostgreSQL; inspected support is required"
        )
    execute(
        container,
        "test",
        "-r",
        PROVISION,
        step="Required shared database provisioning script",
    )
    added_bootstrap = bootstrap_extensions(container, expectations, destination)
    return expectations, added_bootstrap


def restore_data(
    backup: Path,
    passphrase: Passphrase,
    validated: Backup,
    daemon: str,
    project: str,
    services: Dict[str, Any],
    mappings: "Dict[str, SourceMapping]",
    *,
    replace_existing: bool = False,
    prepared: "Optional[Tuple[Dict[str, Dict[str, Any]], Set[str]]]" = None,
    destination: "Optional[Destination]" = None,
    cleanup_on_failure: bool = True,
) -> Dict[str, Any]:
    """Replace and verify data while the caller holds restore_lock through activation.

    Consumes trusted Backup metadata and files; callers establish authorization,
    capacity and the read-only data plan before entry. Every invocation recreates
    all mapped databases. Cancellation or failure attempts stopped/no policies.

    Args:
        backup: Complete backup directory; artifacts must remain unchanged.
        passphrase: Protected operator passphrase file.
        validated: Trusted Backup from public validation or equivalent fixture checks.
        daemon: Preflight-accepted local Docker daemon identity.
        project: Selected Compose installation.
        services: Current target topology with administrative PostgreSQL access.
        mappings: Inspected source mappings in safe peer-archive insertion order.
        replace_existing: Authorize replacing existing destination rows or a different
            verified backup at this internal seam; public completion has extra checks.
        prepared: Previously checked expectations and bootstrap extension plan.
        destination: Mapping already resolved by the public caller. Direct data-seam
            callers resolve once here and translate their logical source mappings.
        cleanup_on_failure: Perform recovery here unless the caller owns it.

    Returns:
        Stable work attribution. Applications remain stopped; no migration
        completion is published and data-only verification does not authorize releases.

    Raises:
        MigrationError: Mapping, replacement, service, SQL or verification fails.
        OSError: Artifact, state or helper access fails.
        ValueError: Structured storage or SQL responses cannot be decoded."""
    if destination is None:
        destination = Destination.resolve(services["osi-postgres"])
        mappings = destination.mappings(mappings)
    expectations, added_bootstrap = prepared or prepare_data(
        validated, daemon, project, services, mappings, destination
    )
    container = services["osi-postgres"]
    with work_identity("restore", control_identity(daemon, project)):
        reconcile_work(
            services, control_identity(daemon, project), "restore"
        )
    if not replace_existing:
        raise MigrationError(
            "Replacing the destination databases requires authorization. Supply --replace-existing to replace the data."
        )
    work_id = control_identity(daemon, project)
    with work_identity("restore", work_id), restore_signals():
        try:
            customer("[3/9] Stop services")
            with phase(
                "disable automatic writer restart and stop writers, ingress and migration jobs",
                "prepare database restoration", quiet=True,
            ):
                prepare_services(project, services)
            customer("[4/9] Prepare destination databases")
            with phase("inspect stable destination replacement state", "inspect existing database state", quiet=True):
                databases = set(
                    json.loads(
                        sql(
                            container,
                            "postgres",
                            "SELECT json_agg(datname) FROM pg_database",
                        )
                    )
                )
                for database in destination.databases:
                    if database not in databases:
                        technical(
                            f"Destination absent: {database}; recreate on retry",
                            flush=True,
                        )
                        continue
                    for relation in reflect(container, database)["relations"]:
                        if relation["kind"] in ("r", "p", "m"):
                            technical(
                                f'Destination table: {database}/{relation["schema"]}/{relation["name"]}; rows={relation["rows"]}',
                                flush=True,
                            )
            with phase(
                "recreate mapped destination databases and bootstrap privileges",
                "prepare destination databases", quiet=True,
            ):
                recreate(container, expectations, destination)
                include_bootstrap_inventory(
                    container,
                    expectations[destination.databases[0]],
                    destination.databases[0],
                    added_bootstrap,
                )
            rows = {row[1]: row for row in validated.manifest["archives"]}
            # Explicit insertion ordering in mappings lets the inspected first
            # archive relocate conflicting migration state before its peer arrives.
            customer("[5/9] Restore captured databases")
            for number, (source, mapping) in enumerate(mappings.items(), 1):
                check_stopped(project, ["ingress", *WRITERS, *migration_jobs(services)])
                customer(f"  Database {number}/{len(mappings)}")
                original = validated.metadata["databases"][source]
                for schema in original["schemas"]:
                    sql(
                        container,
                        mapping.target,
                        f"CREATE SCHEMA IF NOT EXISTS {identifier(schema)}",
                    )
                with restore_progress(source), phase(f"stream {source} into {mapping.target}", "restore captured database data", quiet=True):
                    toc = validated.tocs.get(source)
                    if toc is None:
                        # Trusted shared-API fixtures can construct Backup directly;
                        # public validation always retains all five bounded TOCs.
                        toc = inspect_archive(
                            container, backup / rows[source][2], passphrase
                        )
                    restore_archive(
                        container,
                        backup / rows[source][2],
                        passphrase,
                        mapping.target,
                        toc,
                        work_id,
                    )
                    # Transform just this source through the complete mapping, then
                    # identify its destination objects from original identities.
                    per_source = transform_expectations(
                        {
                            "databases": {
                                name: (
                                    original
                                    if name == source
                                    else {
                                        **validated.metadata["databases"][name],
                                        "relations": [],
                                        "functions": [],
                                        "types": [],
                                        "extensions": [],
                                        "large_objects": 0,
                                    }
                                )
                                for name in SOURCE_TARGETS
                            }
                        },
                        {
                            name: (
                                rule
                                if name == source
                                else SourceMapping(rule.target, rule.owner)
                            )
                            for name, rule in mappings.items()
                        },
                        targets=destination.targets(),
                    )[mapping.target]
                    apply_mapping(
                        container, mapping.target, original, mapping, per_source
                    )
            customer("[6/9] Verify restored data")
            with phase("generic restored structure/count/sequence verification", "verify restored data", quiet=True):
                verify(container, expectations)
            technical("Restore progress: data=verified; schema and Findings history pending; PostgreSQL completion publication pending")
            return {"work_id": work_id}
        except BaseException as error:
            failure(error, "primary data restoration failure")
            technical("Restore outcome: data restoration failed; migration=incomplete", logging.ERROR)
            if cleanup_on_failure:
                try:
                    cleanup_failure(project, services, work_id)
                except Exception as cleanup_error:
                    failure(cleanup_error, "restore recovery failure")
            raise
