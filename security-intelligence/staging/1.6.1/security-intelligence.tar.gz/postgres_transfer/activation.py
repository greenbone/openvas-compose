"""Resume verified restoration and complete after successful required startup."""

import time
import logging

from diagnostics import customer, technical, failure
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Iterator, Optional, Tuple

from appliance_mapping import appliance_mapping
from capture import StateVolume, format_duration, phase, reconcile_work, work_identity
from deployment_advice import HostAdvice
from destination import PROVISION, Destination
from guard import (
    MIGRATION, Rejected, dump_success_identity, completion_identity,
    hex_value, installation_identity, valid_destination_mapping,
    FINDINGS_FROM, FINDINGS_THROUGH, valid_findings_history,
)
from main import (
    WRITERS, BackupIntegrityError, DeploymentPrerequisite, MigrationError,
    RestoreBlocker, discover, docker, execute, require_initialization,
)
from passphrase import Passphrase
from restoration import (
    cleanup_failure,
    control_identity,
    restore_data,
    restore_lock,
    restore_signals,
    simple_mappings,
    prepare_data,
    prepare_services,
)
from validation import (
    SourceMapping,
    fail,
    read_manifest,
    transform_expectations,
    validate_backup,
    validate_capacity,
)
from vulnerability_mapping import vulnerability_mappings

PROGRESS_INTERVAL = 30
READINESS_POLL_INTERVAL = 1

JOBS = ("asset-management-backend-migration", "management-console-backend-migration")
INFRASTRUCTURE = (
    "opensearch",
    "dmz-proxy",
    "asset-management-frontend",
    "vulnerability-intelligence-frontend",
    "management-console-frontend",
    "notification-service-frontend",
)


@contextmanager
def held_lock() -> Iterator[None]:
    """Leave acquisition and release to the caller already holding the lock."""
    yield


def complete_mappings(
    metadata: Dict[str, Any], source_version: str = "1.6.0"
) -> "Dict[str, SourceMapping]":
    """Compose inspected mappings in safe peer-archive order."""
    return {
        **vulnerability_mappings(metadata),
        "management-console-backend": appliance_mapping(metadata, source_version),
        **simple_mappings(),
    }


def binding(manifest: Dict[str, Any]) -> Dict[str, Any]:
    """Extract the installation, capture and manifest hash from a validated manifest.

    Args:
        manifest: Manifest already validated by validate_backup.

    Returns:
        A new binding dictionary; no state is read or changed."""
    return {
        "installation": manifest["installation"],
        "capture_id": manifest["capture_id"],
        "manifest_sha256": manifest["sha256"],
    }


def authorized(
    state: StateVolume,
    manifest: Dict[str, Any],
    project: str,
) -> None:
    """Require installation-level success independently of the selected capture.

    The manifest's installation and subsequent artifact/secret validation establish
    selected-backup compatibility; dump evidence does not authenticate its hash.
    """
    ready = state.read("dump-ready.json")
    fail(ready is not None, "You need to finish a backup before running the restore script.")
    try:
        expected = dump_success_identity(ready, project)
    except Rejected:
        raise MigrationError("Invalid completed dump evidence") from None
    fail(expected["installation"] == manifest["installation"],
         "Backup belongs to another installation")


def record_matches(
    value: Dict[str, Any], expected: Dict[str, Any], project: str
) -> bool:
    """Check durable record identity fields without reading or changing storage.

    Args:
        value: Candidate record.
        expected: Validated backup binding fields.
        project: Selected Compose installation.

    Returns:
        Whether schema, migration, project and backup binding match.
        Required verification and startup evidence require separate caller checks."""
    return (
        type(value.get("schema")) is int
        and value["schema"] == 2
        and value.get("migration") == MIGRATION
        and value.get("project") == project
        and all(value.get(key) == item for key, item in expected.items())
    )


def _completed_backup_matches(
    completed: Dict[str, Any], expected: Dict[str, Any], project: str,
    daemon: str, destination: Destination,
) -> bool:
    """Validate completion ownership and compare the selected backup identity.

    Reads no payloads, secrets or database contents and changes no state.
    Callers retain responsibility for reconciliation and authorization order.
    """
    try:
        completion_identity(completed, project)
    except Rejected:
        raise RestoreBlocker("Inconsistent completed migration; no data changed", EVIDENCE_ACTION) from None
    evidence_check(destination.matches_record(completed),
         "Inconsistent completed migration or destination mapping; no data changed")
    return record_matches(completed, expected, project)


EVIDENCE_ACTION = "Investigate and correct the invalid or conflicting migration evidence before selecting further work."


def read_restore_evidence(state: StateVolume, name: str) -> Optional[Dict[str, Any]]:
    """Read checkpoint evidence without exposing malformed record contents."""
    try:
        return state.read(name)
    except (MigrationError, ValueError):
        raise RestoreBlocker(f"Invalid or unreadable migration evidence: {name}", EVIDENCE_ACTION) from None


def evidence_check(condition: bool, message: str) -> None:
    if not condition:
        raise RestoreBlocker(message, EVIDENCE_ACTION)


REPORT_ENCRYPTION_KEYS = ("TASK_REPORT_CRYPTO_V1_PASSWORD", "TASK_REPORT_CRYPTO_V1_SALT")
POSTGRES_CHECKPOINT = "postgres-restored.json"
RECONSTRUCTION_CHECKPOINT = "findings-history-reconstructed.json"
FINAL_CHECKPOINT = "migration-complete.json"

def read_postgres_checkpoint(
    state: StateVolume, project: str, destination: Destination,
) -> Optional[Dict[str, Any]]:
    """Validate historical verified restoration independently of selected capture.

    A different valid capture is an explicit replacement-selection case; malformed
    ownership, mapping or fingerprints never authorize resume or automatic repair.
    """
    value = read_restore_evidence(state, POSTGRES_CHECKPOINT)
    if value is None:
        return None
    fingerprints = value.get("report_encryption_fingerprints")
    evidence_check(
        type(value.get("schema")) is int and value["schema"] == 2
        and value.get("migration") == MIGRATION
        and value.get("phase") == "postgres-restored"
        and value.get("project") == project
        and value.get("installation") == installation_identity(project)
        and isinstance(value.get("daemon"), str) and bool(value["daemon"])
        and value.get("data_verified") is True
        and hex_value(value.get("capture_id"), 32)
        and hex_value(value.get("manifest_sha256"), 64)
        and valid_destination_mapping(value.get("destination_mapping"))
        and destination.matches_record(value)
        and isinstance(fingerprints, dict) and set(fingerprints) == set(REPORT_ENCRYPTION_KEYS)
        and all(hex_value(item, 64) for item in fingerprints.values()),
        "Invalid postgres-restored.json identity, destination mapping or verification evidence; no data changed",
    )
    return value


def read_checkpoints(state: StateVolume, project: str, destination: Destination) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """Require incomplete evidence to form one consistently bound completed prefix."""
    postgres = read_postgres_checkpoint(state, project, destination)
    reconstruction = read_restore_evidence(state, RECONSTRUCTION_CHECKPOINT)
    if reconstruction is not None:
        evidence_check(postgres is not None, "Findings history completion is missing predecessor postgres-restored.json; no data changed")
        evidence_check(record_matches(reconstruction, {key: postgres[key] for key in
                    ("installation", "capture_id", "manifest_sha256")}, project)
             and reconstruction.get("phase") == "findings-history-reconstructed"
             and isinstance(reconstruction.get("daemon"), str) and bool(reconstruction["daemon"])
             and reconstruction.get("schema_prepared") is True
             and destination.matches_record(reconstruction)
             and valid_findings_history(reconstruction.get("findings_history")),
             "Invalid or conflicting findings-history-reconstructed.json evidence; no data changed")
    return postgres, reconstruction


def report_fingerprints(metadata: Dict[str, Any]) -> Dict[str, str]:
    """Retain only validated report-encryption-secret fingerprints for resume."""
    return {key: metadata["secrets"]["asset-management-backend"]["/run/secrets/" + key]
            for key in REPORT_ENCRYPTION_KEYS}


def invalidate_completion(state: StateVolume) -> None:
    """Durably remove completion records in order before data replacement."""
    for name in (FINAL_CHECKPOINT, RECONSTRUCTION_CHECKPOINT, POSTGRES_CHECKPOINT):
        technical(f"Restore completion removal: intent=invalidate {name} before database replacement")
        state.remove(name)
        technical(f"Restore completion removal: durable operation returned successfully; record={name}")


def _report_completed_noop() -> None:
    """Report preserved completed data without claiming present usability or health."""
    from cleanup import cleanup_command

    technical("Restore outcome: prior completion; current data and health not checked; data and service state preserved", logging.INFO)
    customer("Migration already complete for this backup; nothing to do.", flush=True)
    customer("Legacy database contents are retained. You can remove them later at any time with:\n  " + cleanup_command(), flush=True)


def await_service(project: str, name: str, *, job: bool = False) -> None:
    """Wait for configured readiness or this deliberately started job's exit."""
    started = time.monotonic()
    last = started
    while True:
        _, services = discover(project)
        container = services[name]
        state = container["State"]
        if job:
            fail(
                not state.get("Restarting"),
                f"Required migration failed and is restarting: {name}",
            )
        if job and not state["Running"] and not state.get("Restarting"):
            fail(state.get("ExitCode") == 0, f"Required migration failed: {name}")
            technical(f"Activation observed: service={name}; container={container['Id']}; job=exited successfully")
            return
        if not job:
            fail(
                state["Running"] and not state.get("Restarting"),
                f"Required service stopped during activation: {name}",
            )
            health = state.get("Health", {}).get("Status")
            if health == "healthy":
                technical(f"Activation observed: service={name}; container={container['Id']}; readiness=healthy")
                return
            fail(health != "unhealthy", f"Required service readiness failed: {name}")
        # The configured readiness grace is bounded; no overall restore deadline.
        config = container["Config"].get("Healthcheck", {})
        grace = (
            config.get("StartPeriod", 0)
            + config.get("Retries", 3)
            * (
                config.get("Interval", 30_000_000_000)
                + config.get("Timeout", 30_000_000_000)
            )
        ) / 1_000_000_000
        if not job:
            fail(
                time.monotonic() - started <= max(grace, 60),
                f"Required service readiness timed out: {name}",
            )
        if time.monotonic() - last >= PROGRESS_INTERVAL:
            elapsed = time.monotonic() - started
            technical(f"Activation still running: {name}; elapsed seconds={elapsed:.3f}")
            operation = "Schema migration" if job else "Application startup"
            customer(f"  {operation} in progress: {name} ({format_duration(elapsed)} elapsed)")
            last = time.monotonic()
        time.sleep(READINESS_POLL_INTERVAL)


def start_service(project: str, name: str, *, job: bool = False) -> None:
    """Start a stopped required container and wait for its configured readiness.

    Args:
        project: Selected Compose installation, re-discovered before starting.
        name: Required service name. Caller already prepared the restore lifecycle.
        job: Require successful process exit for an intentionally rerun migration job.

    Raises:
        MigrationError: Discovery, start, job exit or readiness fails.
        KeyError: The required service is missing from current discovery."""
    _, services = discover(project)
    container = services[name]
    # Preparation stopped every writer/job. docker start reruns a stopped job's
    # configured entrypoint, even when its previous execution exited0.
    if not container["State"]["Running"]:
        docker(
            "start",
            container["Id"],
            step=f"Start required {'migration' if job else 'service'} {name}",
        )
    await_service(project, name, job=job)


def schema_topology(services: Dict[str, Any]) -> None:
    """Check upfront configuration for the two required application schema jobs."""
    for name in JOBS:
        if name not in services:
            raise DeploymentPrerequisite(f"Unsupported activation topology: missing {name}")
        if "EXECUTION_MODE=migration_only" not in services[name]["Config"].get("Env", []):
            raise DeploymentPrerequisite(f"Unsupported required migration execution mode: {name}")


def activation_topology(services: Dict[str, Any]) -> None:
    """Check required applications and readiness without depending on schema jobs."""
    for name in (*WRITERS, "ingress", *INFRASTRUCTURE):
        if name not in services:
            raise DeploymentPrerequisite(f"Unsupported activation topology: missing {name}")
        probe = services[name]["Config"].get("Healthcheck", {}).get("Test", [])
        if not probe or probe[0] == "NONE":
            raise DeploymentPrerequisite(f"Unsupported activation readiness: {name}")


def require_current_initialization(project: str) -> None:
    """Recheck the current initializer when entering application preparation."""
    technical(f"Initialization recheck: intent=before application activation; project={project}")
    _, current = discover(project)
    require_initialization(current, before_activation=True)
    technical("Initialization recheck: observed=successful; establishes database infrastructure only")


def start_activation_dependencies(project: str) -> None:
    """Start the existing deployment dependencies in their established order."""
    for name in ("keycloak", "opensearch", "dmz-proxy", "notification-service"):
        start_service(project, name)


def prepare_schema(project: str) -> None:
    """Run both schema jobs directly, independently of application activation.

    The caller owns quiescence, initialization and upfront topology checks.
    Starting a container directly does not start its Compose dependencies.
    """
    for name in JOBS:
        with phase(f"Run required application database migration: {name}", "run required application migration", quiet=True):
            start_service(project, name, job=True)


def activate(project: str, services: Dict[str, Any]) -> None:
    """Confirm applications, restore restart policies and reopen ingress last.

    The caller has prepared the schema and started activation dependencies.
    This function neither runs schema jobs nor publishes migration completion.
    Failures propagate to the caller's established recovery boundary.
    """
    for name in WRITERS:
        if name not in ("keycloak", "notification-service"):
            start_service(project, name)
    for name in INFRASTRUCTURE:
        if name not in ("opensearch", "dmz-proxy"):
            start_service(project, name)
    # All application readiness passed before automatic restart is restored.
    for name in (*WRITERS, "ingress"):
        docker(
            "update",
            "--restart=always",
            services[name]["Id"],
            step=f"Enable supported restart policy {name}",
        )
    start_service(project, "ingress")


class RestoreOutcome:
    """Observed restore facts for dispatcher advice; never persisted evidence."""

    def __init__(self) -> None:
        self.activation_failed = False
        self.work_started = False
        self.replacement_invalidation_blocked = False
        self.completion = "incomplete"
        self.postgres_restored = False
        self.postgres_publication_unknown = False
        self.findings_reconstructed = False
        self.reconstruction_publication_unknown = False
        self.safe_state_unknown = False
        self.recovery_stopped = False

    def guidance_parts(self) -> Tuple[str, str]:
        """Return observed state and next actions separately for composition."""
        if self.completion == "unknown":
            state = "The restore could not confirm whether the migration finished. The product was left in its current state and may not be safely stopped."
            action = "Check that Docker is available, then retry the restore with the same backup. The restore will check its saved progress before continuing. Do not use the product until the restore reports success."
        elif self.safe_state_unknown:
            state = "The restore could not confirm that its previous work has stopped or that all services are safely stopped."
            action = "Check that Docker is available, then retry the restore with the same backup. The restore will check its saved progress before continuing. Do not use the product until the restore finishes successfully."
        elif self.reconstruction_publication_unknown:
            state = "The restore could not confirm whether Findings history reconstruction finished."
            action = "Retry the restore with the same backup. The restore will check its saved progress before deciding which steps to run."
        elif self.postgres_publication_unknown:
            state = "The restore could not confirm whether the database restore finished."
            action = "Check that Docker is available, then retry the restore with the same backup. The restore will check its saved progress before deciding which steps to run."
        elif self.findings_reconstructed:
            state = "The data restore and Findings history reconstruction finished, but the migration is not complete."
            action = "Retry the restore with the same backup. Your restored data will be kept, and the migration will retry starting the product. Keep the backup until the restore succeeds, and do not use the product until then."
        elif self.postgres_restored:
            state = "The database restore finished, but the migration is not complete."
            action = "Retry the restore with the same backup. The restored databases will be kept, and the migration will continue with the remaining steps. Keep the backup until the restore succeeds, and do not use the product until then."
        else:
            state = "The restore did not finish. Do not use OPENVAS Security Intelligence yet."
            action = ("Retry the restore with the same backup. The restore will resume from established completed phases. "
                      "You may need to enter the backup passphrase and confirm that existing database data can be replaced.\n\n"
                      "Keep the backup until the restore finishes successfully.")
        if (self.recovery_stopped and not self.safe_state_unknown
                and self.completion != "unknown" and not self.postgres_publication_unknown
                and not self.reconstruction_publication_unknown):
            state += " Recovery confirmed that owned restore work and affected services are stopped."
        return state, action


def restore(
    backup: Path,
    passphrase: Optional[Passphrase],
    daemon: str,
    project: str,
    services: Dict[str, Any],
    *,
    replace_existing: bool = False,
    replace_completed: bool = False,
    destination: "Optional[Destination]" = None,
    lock_held: bool = False,
    outcome: Optional[RestoreOutcome] = None,
    advice: Optional[HostAdvice] = None,
    confirm_restore: bool = False,
) -> None:
    """Restore the authorized backup and complete only after required startup.

    Owns the installation restore lock and signal handlers. Validates backup,
    authorization and the complete data plan before destructive work.
    A matching PostgreSQL checkpoint preserves restored data and skips archive checks.
    Completed reruns preserve later writes unless replacement is authorized.
    Failure cleanup closes writers and preserves durable phase completion;
    callers must exclude overlapping deployment independently of this lock.

    Args:
        backup: Complete backup directory retained unchanged during execution.
        passphrase: Protected passphrase for unfinished restoration; unused on resume.
        daemon: Preflight-accepted local Docker daemon identity.
        project: Selected Compose installation.
        services: Preflight-discovered destination topology.
        replace_existing: Permit replacing current rows during a data attempt.
        replace_completed: Deliberately discard intermediate/final work and later writes.
        destination: Exact mapping resolved before public replacement consent.
        lock_held: Public dispatcher already holds the installation lock through input and preflight.
        outcome: Mutable observation for dispatcher advice only; not durable evidence.
        advice: Selected host deployment advice; never executes deployment actions.
        confirm_restore: Explicit capture-time and data-loss acknowledgement for this attempt.

    Raises:
        MigrationError: Validation, restoration, activation or state publication fails.
        OSError: Storage or process access fails.
        ValueError: A record or response cannot be decoded."""
    outcome = outcome if outcome is not None else RestoreOutcome()
    selected_advice = advice if advice is not None else HostAdvice()
    def reconcile_restore_work() -> None:
        try:
            reconcile_work(services, control_identity(daemon, project), "restore")
        except Exception:
            outcome.safe_state_unknown = True
            raise

    with (
        held_lock() if lock_held else restore_lock(daemon, project)
    ), restore_signals(), work_identity("restore", control_identity(daemon, project)):
        destination = destination or Destination.resolve(services["osi-postgres"])
        technical("Destination databases: " + ", ".join(destination.databases), flush=True)
        with phase("read and structurally validate Complete migration backup manifest", "check backup manifest", quiet=True):
            manifest = read_manifest(backup, daemon, project)
        # Quiesce all prior attributed restore work before reading final success.
        # This neither prepares product services nor mutates migration evidence.
        with phase("reconcile surviving restore work", "reconcile interrupted restoration", quiet=True):
            reconcile_restore_work()
        state = StateVolume(project, services, create=False)
        with phase("validate installation successful-dump evidence", "check migration prerequisites", quiet=True):
            try:
                authorized(state, manifest, project)
            except (MigrationError, ValueError) as exc:
                message = str(exc) if isinstance(exc, MigrationError) else "Invalid completed dump evidence"
                raise RestoreBlocker(message, "Investigate the backup and its successful-dump evidence before restoring.") from None
        completed = None if replace_completed else read_restore_evidence(state, "migration-complete.json")
        expected = binding(manifest)
        if completed is not None:
            same_backup = _completed_backup_matches(
                completed, expected, project, daemon, destination
            )
            fail(same_backup or replace_completed,
                 "Selected backup differs from completed migration; supply --replace-completed to replace the data.")
        if completed is not None and not replace_completed:
            outcome.completion = "completed"
            _report_completed_noop()
            return
        postgres, reconstruction = (read_checkpoints(state, project, destination)
                                    if completed is None and not replace_completed else (None, None))
        if postgres is not None:
            fail(record_matches(postgres, expected, project) or replace_completed,
                 "Selected backup differs from verified PostgreSQL restoration; supply --replace-completed to replace the data.")
        restoration_required = postgres is None or replace_completed
        outcome.postgres_restored = postgres is not None
        reconstruction_required = reconstruction is None or replace_completed
        outcome.findings_reconstructed = reconstruction is not None
        if completed is not None:
            outcome.completion = "completed"
        require_initialization(services)
        validated = mappings = prepared = None
        if restoration_required:
            customer("[2/9] Validate backup")
            try:
                validated = validate_backup(
                    backup, passphrase, daemon, project, services,
                    check_capacity=False, manifest=manifest,
                )
            except (RestoreBlocker, BackupIntegrityError, DeploymentPrerequisite):
                raise
            except MigrationError as exc:
                raise RestoreBlocker(str(exc), "Investigate and correct the reported backup or access problem before restoring.") from None
            technical("Artifact validation complete; ciphertext, metadata and secrets passed.")
            validate_capacity(validated.metadata, services["osi-postgres"])
            try:
                mappings = destination.mappings(complete_mappings(
                    validated.metadata, selected_advice.source_version
                ))
                transform_expectations(validated.metadata, mappings, targets=destination.targets())
            except RestoreBlocker:
                raise
            except MigrationError as exc:
                raise RestoreBlocker(str(exc), "Investigate the unsupported or invalid source contents before restoring.") from None
            try:
                execute(services["osi-postgres"], "test", "-r", PROVISION,
                        step="Required shared database provisioning script")
            except MigrationError as exc:
                raise DeploymentPrerequisite(str(exc)) from None
        else:
            customer("[2/9] Validate backup - PostgreSQL restoration already completed; skipping")
        activation_topology(services)
        reconstruction_inputs = None
        if reconstruction_required:
            schema_topology(services)
            from findings_history import reconstruction_prerequisites
            fingerprints = report_fingerprints(validated.metadata) if restoration_required else postgres["report_encryption_fingerprints"]
            reconstruction_inputs = reconstruction_prerequisites(services, control_identity(daemon, project), fingerprints,
                                                                  restoration_required=restoration_required)
        if restoration_required:
            # Finish the complete read-only data plan before invalidating evidence.
            prepared = prepare_data(validated, daemon, project, services, mappings, destination)
            fail(replace_existing or replace_completed,
                 "Current replacement authorization required; supply --replace-existing")
            from restoration import confirm_backup_capture
            confirm_backup_capture(validated.metadata, confirmed=confirm_restore)
        reconcile_restore_work()
        outcome.work_started = True
        if restoration_required and (replace_completed or completed is not None or postgres is not None):
            try:
                invalidate_completion(state)
            except BaseException:
                # Removal can be durable despite a lost helper response. Observe
                # the remaining prefix before describing what a retry preserves.
                try:
                    reconcile_restore_work()
                    remaining_final = state.read(FINAL_CHECKPOINT)
                    if remaining_final is not None:
                        _completed_backup_matches(remaining_final, expected, project, daemon, destination)
                        # This is the earlier completion being deliberately replaced,
                        # not completion of the requested replacement attempt.
                        outcome.completion = "incomplete"
                        outcome.replacement_invalidation_blocked = True
                    else:
                        outcome.completion = "incomplete"
                        postgres, reconstruction = read_checkpoints(state, project, destination)
                        outcome.postgres_restored = postgres is not None
                        outcome.findings_reconstructed = reconstruction is not None
                except Exception as recovery_error:
                    failure(recovery_error, "completion invalidation observation failure")
                    outcome.postgres_publication_unknown = True
                raise
            postgres = reconstruction = None
            outcome.postgres_restored = False
            outcome.findings_reconstructed = False
            outcome.completion = "incomplete"
        completion = {
            "schema": 2, "migration": MIGRATION, "project": project, "daemon": daemon,
            **expected, "destination_mapping": destination.record(),
            "data_verified": True, "completion_basis": "verified-data-reconstruction-and-startup",
            "findings_history_reconstructed": True,
            "applications_activated": True,
        }
        work_id = control_identity(daemon, project)
        publication_started = False
        postgres_publication_started = False
        postgres_completion = None
        reconstruction_completion = None
        reconstruction_publication_started = False
        stage = "data restoration" if restoration_required else "remaining-phase preparation"
        try:
            if restoration_required:
                restore_data(
                    backup, passphrase, validated, daemon, project, services, mappings,
                    replace_existing=True, destination=destination, prepared=prepared,
                    cleanup_on_failure=False,
                )
                postgres_completion = {
                    "schema": 2, "migration": MIGRATION, "phase": "postgres-restored",
                    "project": project, "daemon": daemon, **expected,
                    "destination_mapping": destination.record(), "data_verified": True,
                    "report_encryption_fingerprints": report_fingerprints(validated.metadata),
                }
                stage = "PostgreSQL completion publication"
                with phase("publish verified PostgreSQL restoration", "record verified PostgreSQL restoration", quiet=True):
                    postgres_publication_started = True
                    state.write(POSTGRES_CHECKPOINT, postgres_completion)
                    postgres = postgres_completion
                    outcome.postgres_restored = True
                    technical("Restore progress: PostgreSQL completion durably published; remaining work pending")
            else:
                technical("Restore progress: verified PostgreSQL restoration observed; unfinished phases remain")
                customer("[3/9] Stop services")
                prepare_services(project, services)
                customer("[4/9] Prepare destination databases - PostgreSQL restoration already completed; skipping")
                customer("[5/9] Restore captured databases - PostgreSQL restoration already completed; skipping")
                customer("[6/9] Verify restored data - Restored data already verified; skipping")
            if reconstruction_required:
                stage = "schema preparation"
                customer("[7/9] Prepare application schemas")
                require_current_initialization(project)
                config, secrets = reconstruction_inputs
                if config.target_probe_deferred:
                    from findings_history import probe_database
                    stage = "restored Findings history database connection"
                    with phase("check configured application connection after verified PostgreSQL restoration",
                               "check restored Findings history database connection", quiet=True):
                        probe_database(services, config, secrets['DB_PASSWORD'])
                    config.target_probe_deferred = False
                stage = "schema preparation"
                prepare_schema(project)
                from findings_history import run_reconstruction
                stage = "Findings history reconstruction"
                customer("[8/9] Reconstruct findings history")
                technical("  Period: " + FINDINGS_FROM + " through " + FINDINGS_THROUGH + " (inclusive, UTC)")
                config, secrets = reconstruction_inputs
                result = run_reconstruction(config, secrets)
                reconstruction_completion = {
                    "schema": 2, "migration": MIGRATION, "phase": "findings-history-reconstructed",
                    "project": project, "daemon": daemon, **expected,
                    "destination_mapping": destination.record(), "schema_prepared": True,
                    "findings_history": {"from": FINDINGS_FROM, "through": FINDINGS_THROUGH, "result": result},
                }
                stage = "Findings history completion publication"
                reconstruction_publication_started = True
                state.write(RECONSTRUCTION_CHECKPOINT, reconstruction_completion)
                reconstruction = reconstruction_completion
                outcome.findings_reconstructed = True
                technical("Restore progress: Findings history completion durably published; activation pending")
            else:
                customer("[7/9] Prepare application schemas - Schema preparation and findings history reconstruction already completed; skipping")
                customer("[8/9] Reconstruct findings history - Findings history reconstruction already completed; skipping")
            completion["findings_history"] = reconstruction["findings_history"]
            stage = "application activation"
            customer("[9/9] Start stopped services and record migration completion")
            with phase("Start required services and check application readiness", "start required applications", quiet=True):
                require_current_initialization(project)
                start_activation_dependencies(project)
                activate(project, services)
            with phase("publish completed migration after required startup", "record completed migration", quiet=True):
                stage = "completion publication"
                technical("Restore completion publication: intent=durably record verified data, Findings history reconstruction and successful required startup")
                publication_started = True
                state.write("migration-complete.json", completion)
                outcome.completion = "completed"
                technical("Restore outcome: completed migration; durable publication acknowledged", logging.INFO)
        except BaseException as error:
            outcome.activation_failed = stage in ("schema preparation", "application activation")
            failure(error, "primary restoration failure")
            technical(f"Restore failure: stage={stage}; initiating failure preserved", logging.ERROR)
            # A failed response can follow the atomic rename. Reconcile the publisher
            # before checking success; never stop healthy services or revoke that success.
            reconciled = True
            try:
                reconcile_work(services, work_id, "restore")
            except Exception as recovery_error:
                failure(recovery_error, "restore failure reconciliation failure")
                reconciled = False
                outcome.safe_state_unknown = True
            if postgres_publication_started and not outcome.postgres_restored:
                try:
                    published_postgres = read_postgres_checkpoint(state, project, destination) if reconciled else None
                    if published_postgres == postgres_completion:
                        postgres = published_postgres
                        outcome.postgres_restored = True
                        customer("Verified PostgreSQL restoration was durably published despite the lost response.", flush=True)
                    elif not reconciled:
                        outcome.postgres_publication_unknown = True
                except Exception as recovery_error:
                    failure(recovery_error, "PostgreSQL completion observation failure")
                    outcome.postgres_publication_unknown = True
            if reconstruction_publication_started and not outcome.findings_reconstructed:
                try:
                    _, published_reconstruction = read_checkpoints(state, project, destination) if reconciled else (None, None)
                    if published_reconstruction == reconstruction_completion:
                        outcome.findings_reconstructed = True
                        customer("Findings history reconstruction was durably published despite the lost response.", flush=True)
                    elif not reconciled:
                        outcome.reconstruction_publication_unknown = True
                except Exception as recovery_error:
                    failure(recovery_error, "Findings history completion observation failure")
                    outcome.reconstruction_publication_unknown = True
            if publication_started:
                try:
                    published = state.read("migration-complete.json") if reconciled else None
                except Exception as recovery_error:
                    failure(recovery_error, "restore completion observation failure")
                    published = None
                    reconciled = False
                if not reconciled:
                    outcome.completion = "unknown"
                    technical("Restore outcome: completion publication unknown; service state retained; safe state=unknown", logging.ERROR)
                elif published == completion:
                    outcome.completion = "completed"
                    technical("Restore outcome: completed migration observed in durable evidence despite lost response", logging.INFO)
                else:
                    technical("Restore outcome: completion not observed after reconciliation; resume required", logging.WARNING)
                    try:
                        outcome.recovery_stopped = cleanup_failure(project, services, work_id, report_observations=False)
                        outcome.safe_state_unknown |= not outcome.recovery_stopped
                    except Exception as recovery_error:
                        failure(recovery_error, "restore recovery failure")
                        outcome.safe_state_unknown = True
            else:
                technical(f"Restore outcome: migration incomplete; failed stage={stage}; verified PostgreSQL completion={outcome.postgres_restored}", logging.WARNING)
                try:
                    outcome.recovery_stopped = cleanup_failure(project, services, work_id, report_observations=False)
                    outcome.safe_state_unknown |= not outcome.recovery_stopped
                except Exception as recovery_error:
                    failure(recovery_error, "restore recovery failure")
                    outcome.safe_state_unknown = True
            raise
        # Reporting follows durable completion. Output/selection failures must
        # not initiate data or service recovery for a completed operation.
        customer("The migration was successful. Restored data was verified and findings history was reconstructed.", flush=True)
        customer("If you ran the restore after a failed upgrade, redeploy OPENVAS Security Intelligence "
                 + selected_advice.target_version + " using the applicable procedure:", flush=True)
        selected_advice.show("redeploy")
        from cleanup import cleanup_command
        customer("Legacy database contents are retained. You can remove them later at any time with:\n  " + cleanup_command(), flush=True)
