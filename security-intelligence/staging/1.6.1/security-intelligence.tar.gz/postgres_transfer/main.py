"""Encrypted capture and preflight for Security Intelligence integration migration."""

import argparse
import getpass
import io
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tarfile
import time
import warnings
from contextlib import ExitStack, contextmanager
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple

from passphrase import Passphrase, Secret, openssl_run
from diagnostics import customer, technical, prompt
import diagnostics

if __name__ == "__main__":
    sys.modules["main"] = sys.modules[__name__]

PRODUCT_LABEL = "net.greenbone.deployment"
PROJECT_LABEL = "com.docker.compose.project"
SERVICE_LABEL = "com.docker.compose.service"
WRITER_LABEL = "net.greenbone.postgres-writer"
_last_discovery_identity = None
SOURCES = {
    "asset-management-postgres": "asset-management-backend",
    "vulnerability-intelligence-postgres": "vulnerability-intelligence-backend",
    "management-console-postgres": "management-console-backend",
    "notification-service-postgres": "notification-service",
    "keycloak-postgres": "keycloak",
}
TARGETS = (
    "vulnerability-management",
    "appliance-management",
    "notification",
    "keycloak",
)
WRITERS = (
    "asset-management-backend",
    "vulnerability-intelligence-backend",
    "management-console-backend",
    "management-console-backend-worker",
    "management-console-wst-server",
    "notification-service",
    "keycloak",
)
APP_CREDENTIALS = {
    "asset-management-backend": "/run/secrets/DB_PASSWORD",
    "vulnerability-intelligence-backend": "/run/secrets/vulnerability-intelligence-db-password",
    "management-console-backend": "/run/secrets/management-console-db-password",
    "management-console-backend-worker": "/run/secrets/management-console-db-password",
    "management-console-wst-server": "/run/secrets/management-console-db-password",
    "notification-service": "/run/secrets/notification-service-db-password",
    "keycloak": "/run/secrets/KC_DB_PASSWORD",
}
SECRET_PROVIDERS = {
    "asset-management-backend": "asset-management-backend-migration",
    "management-console-backend": "management-console-backend-migration",
    "management-console-backend-worker": "management-console-backend-migration",
}


def secret_provider(services: Dict[str, Any], application: str) -> Any:
    """Select the sole existing Compose container supplying an application's secrets."""
    provider = SECRET_PROVIDERS.get(application, application)
    if provider not in services:
        raise DeploymentPrerequisite(
            f"Secret provider {provider} is missing for {application}; "
            "prepare it through restarting OPENVAS Security Intelligence and try again.",
            restore_fact=f"Secret provider {provider} is missing for {application}", category="secret",
        )
    return services[provider]


SECRETS = {
    "asset-management-backend": (
        "/run/secrets/TASK_REPORT_CRYPTO_V1_PASSWORD",
        "/run/secrets/TASK_REPORT_CRYPTO_V1_SALT",
    ),
    "vulnerability-intelligence-backend": (
        "/run/secrets/vulnerability-intelligence-encryption-key",
    ),
    "management-console-backend": (
        "/run/secrets/secret-key",
        "/run/secrets/encryption-key",
        "/run/secrets/encryption-key-report-push-kc-client",
        "/run/secrets/support-package-download-url-key",
    ),
    "notification-service": (
        "/run/secrets/notification-service-encryption-key",
        "/run/secrets/notification-service-salt",
    ),
}


class PreflightResult:
    """Installation observations used to dispatch a checked migration command.

    Attributes:
        daemon: Local Docker daemon identity.
        project: Selected Compose installation.
        version: Installed version, or unknown source provenance during dump.
        services: Inspected containers keyed by Compose service name.
    """

    daemon: str
    project: str
    version: str
    services: Dict[str, Any]

    __slots__ = ("daemon", "project", "version", "services")

    def __init__(
        self, daemon: str, project: str, version: str, services: Dict[str, Any]
    ) -> None:
        object.__setattr__(self, "daemon", daemon)
        object.__setattr__(self, "project", project)
        object.__setattr__(self, "version", version)
        object.__setattr__(self, "services", services)

    def __setattr__(self, name: str, value: Any) -> None:
        raise AttributeError("cannot assign to immutable record")

    def __delattr__(self, name: str) -> None:
        raise AttributeError("cannot delete from immutable record")

    def __eq__(self, other: Any) -> bool:
        if type(other) is not type(self):
            return NotImplemented
        return (
            self.daemon,
            self.project,
            self.version,
            self.services,
        ) == (
            other.daemon,
            other.project,
            other.version,
            other.services,
        )

    def __hash__(self) -> int:
        return hash(
            (
                self.daemon,
                self.project,
                self.version,
                self.services,
            )
        )

    def __repr__(self) -> str:
        return "PreflightResult(daemon={self.daemon!r}, project={self.project!r}, version={self.version!r}, services={self.services!r})".format(
            self=self
        )


class MigrationError(Exception):
    """A safe, operator-facing diagnostic, containing no subprocess output."""


class RestoreBlocker(MigrationError):
    """Safe cause facts with the corrective action for the restore dispatcher."""

    def __init__(self, message: str, action: str, retry: bool = False) -> None:
        super().__init__(message)
        self.action = action
        self.retry = retry


class RestoreAcknowledgementRefused(RestoreBlocker):
    """Capture-time consequences were not acknowledged before restoration."""


class CredentialsTransferError(MigrationError):
    """Credentials could not be transferred to the reconstruction helper."""


class BackupIntegrityError(MigrationError):
    """A ciphertext artifact disagrees with its recorded size or checksum."""


class DowngradeRequired(MigrationError):
    """A known topology or valid release refusal with advisory recovery."""

    def __init__(self, message: str, advice_target: str, *, restore_fact: Optional[str] = None) -> None:
        super().__init__(message)
        self.advice_target = advice_target
        self.restore_fact = restore_fact or message


class DeploymentPrerequisite(MigrationError):
    """A deployment component must be prepared before restoration can proceed."""

    def __init__(self, message: str, *, restore_fact: Optional[str] = None, category: str = "general") -> None:
        super().__init__(message)
        self.restore_fact = restore_fact or message
        self.category = category


class InitializationIncomplete(DeploymentPrerequisite):
    """Deployment must complete database initialization before restoration."""


class MigrationCancelled(MigrationError):
    """Existing signal cancellation, with a safe observer outcome marker."""

    command_outcome = 'cancellation'


def run(
    args: List[str],
    step: str,
    data: Optional[str] = None,
    passphrase: Optional[Passphrase] = None,
) -> str:
    # During capture/recovery all external helpers inherit the durable attempt
    # marker, including service-state and SQL commands launched through here.
    """Run one bounded external helper without exposing its captured diagnostics.

    Args:
        args: Executable and arguments; callers must avoid secrets in argv.
        step: Safe operator-facing label for failures.
        data: Optional text supplied through stdin.

    Returns:
        Stripped stdout. Helpers inherit the current attempt environment.

    Raises:
        MigrationError: Launch, timeout (60 seconds), or exit-status failure."""
    from capture import work_environment

    from process_diagnostics import run_command
    opener = None
    if passphrase is not None:
        from passphrase import openssl_process
        opener = lambda **options: openssl_process(passphrase, args[1:], **options)
    kind = 'payload' if args[0] == 'openssl' else 'diagnostic'
    if args[:2] == ['docker', 'inspect']:
        kind = 'secret'
    sql_command = any('psql ' in arg for arg in args)
    if sql_command:
        kind = 'sql'
    try:
        result = run_command(args, step, data=data, env=work_environment(),
                             stdout_kind=kind, stderr_kind='psql' if sql_command else 'diagnostic', opener=opener)
    except (OSError, subprocess.TimeoutExpired):
        raise MigrationError(f"{step}: command unavailable or timed out") from None
    except ValueError:
        raise MigrationError(f"{step}: command response invalid or incomplete") from None
    if result.returncode:
        raise MigrationError(f"{step}: command failed (exit {result.returncode})")
    return result.stdout.decode('utf-8', 'replace').strip()


def docker(*args: str, step: str) -> str:
    """Run Docker through the bounded command and safe-diagnostic boundary.

    Args:
        args: Docker arguments; lifecycle effects depend on the chosen command.
        step: Safe label used when the command fails.

    Returns:
        Stripped Docker stdout.

    Raises:
        MigrationError: Docker is unavailable, times out, or exits unsuccessfully."""
    return run(["docker", *args], step)


def discover(project: Optional[str]) -> Tuple[str, Dict[str, Any]]:
    """Inspect labeled containers without changing their lifecycle.

    Args:
        project: Explicit Compose project, or None to require one unambiguous project.

    Returns:
        Selected project and service-name-to-inspect-record mapping, including stopped
        containers. Callers must re-discover after container recreation. Log the
        inventory initially and when the project or service/container mapping
        changes, independently of readiness state changes.

    Raises:
        MigrationError: Installation or service identity is absent or ambiguous.
        ValueError: Docker's inspection response is invalid JSON."""
    global _last_discovery_identity
    ids = docker(
        "ps",
        "-aq",
        "--filter",
        f"label={PRODUCT_LABEL}=security-intelligence",
        step="Discover installation",
    ).splitlines()
    if not ids:
        raise MigrationError("No Security Intelligence installation found")
    containers = json.loads(docker("inspect", *ids, step="Inspect installation"))
    projects = {c["Config"]["Labels"].get(PROJECT_LABEL) for c in containers}
    projects.discard(None)
    if project is None:
        if len(projects) != 1:
            raise MigrationError("Ambiguous installation; select --project explicitly. List the projects with 'docker compose ls --all'")
        project = projects.pop()
    if project not in projects and not any(
        c["Config"]["Labels"].get(PROJECT_LABEL) == project for c in containers
    ):
        raise MigrationError(
            "Selected project isn't a Security Intelligence installation"
        )
    services: Dict[str, Any] = {}
    for container in containers:
        labels = container["Config"]["Labels"]
        if labels.get(PROJECT_LABEL) != project:
            continue
        service = labels.get(SERVICE_LABEL)
        if (
            not service
            or service in services
            or labels.get("com.docker.compose.oneoff") == "True"
        ):
            raise MigrationError("Ambiguous service identity in selected installation")
        services[service] = container
    assert project is not None
    inventory = tuple(sorted((service, container["Id"]) for service, container in services.items()))
    # Each diagnostic destination represents a new invocation and needs its own
    # initial inventory, even when called repeatedly within one Python process.
    identity = (diagnostics.path, project, inventory)
    if identity != _last_discovery_identity:
        technical(f"Installation selected: project={project}")
        for service, container_id in inventory:
            technical(f"Service identity: service={service}; container={container_id}")
        _last_discovery_identity = identity
    return project, services


def require(services: Dict[str, Any], name: str, running: bool = True) -> Any:
    """Select a required service without starting it.

    Args:
        services: Discovered service inspection records.
        name: Required Compose service.
        running: Require running and non-restarting state when True.

    Returns:
        The original inspection record, not a copy or a fresh probe.

    Raises:
        MigrationError: The required topology or running-state condition fails."""
    container = services.get(name)
    if container is None:
        raise DeploymentPrerequisite(f"Unsupported topology: missing {name} - Restart OPENVAS Security Intelligence and try again.", restore_fact=f"Unsupported topology: missing {name}")
    if running and (
        not container["State"]["Running"] or container["State"].get("Restarting")
    ):
        raise DeploymentPrerequisite(f"{name} must be running for its preflight probes")
    return container


def require_initialization(services: Dict[str, Any], *, before_activation: bool = False) -> None:
    """Require observed successful initialization without changing service state.

    Roles may all exist after an initializer failure. Job completion establishes
    the deployment prerequisite, not verified restoration or completed migration.
    Operators must prevent overlapping deployment and restoration.

    Args:
        services: Read-only deployment container inspection records.
        before_activation: Identify the activation recheck after data restoration.
            Changes diagnostic context only, never the prerequisite decision.

    Raises:
        InitializationIncomplete: The initializer has not exited successfully.
    """
    initializer = services.get("osi-postgres-init", {})
    state = initializer.get("State", {})
    technical("Initialization prerequisite: service=osi-postgres-init; container={}; status={}; exit={}; running={}; restarting={}".format(
        initializer.get("Id", "unavailable"), state.get("Status", "unavailable"),
        state.get("ExitCode", "unavailable"), state.get("Running", "unavailable"),
        state.get("Restarting", "unavailable")))
    if (state.get("Status") != "exited" or state.get("ExitCode") != 0
            or state.get("Running") or state.get("Restarting")):
        boundary = "application activation" if before_activation else "service/database mutation"
        technical(f"Restore outcome: initialization refused before {boundary}; retry deployment prerequisite", logging.WARNING)
        raise InitializationIncomplete(
            "The database is not ready for the restore.\n\n"
            "Restart the OPENVAS Security Intelligence deployment and wait for it to finish starting. "
            "Then retry the restore."
        )
    technical("Initialization prerequisite: observed=successful; database infrastructure only; initialization does not establish restoration")


def execute(container: Any, *args: str, step: str) -> str:
    """Execute a bounded command inside an already running container.

    Args:
        container: Docker inspection record with an Id.
        args: Command and arguments; the command determines mutation effects.
        step: Safe diagnostic label.

    Returns:
        Stripped command stdout.

    Raises:
        MigrationError: Docker execution fails or exceeds the command timeout."""
    from capture import application_name

    # Set attribution in the initial process environment as well as libpq's
    # connection name. A shell exporting it later has an unchanged /proc environ.
    return docker("exec", "--env", "PGAPPNAME=" + application_name(),
                  container["Id"], *args, step=step)


def read_secret(container: Any, path: str) -> bytes:
    """Read a mounted container file without starting a stopped writer."""
    from process_diagnostics import run_command
    from capture import work_environment
    fact = f"Secret access {container['Config']['Labels'][SERVICE_LABEL]} {path}"
    step = fact + "; prepare accessible Compose secrets through restarting OPENVAS Security Intelligence and try again."
    def secret_error(detail):
        return DeploymentPrerequisite(f"{step}: {detail}", restore_fact=f"{fact}: {detail}", category="secret")
    if container["State"]["Running"] and not container["State"].get("Restarting"):
        try:
            result = run_command(
                ["docker", "exec", container["Id"], "cat", path], step,
                stdout_kind="secret", response_limit=1024 * 1024, env=work_environment(),
            )
        except (OSError, ValueError, subprocess.TimeoutExpired):
            raise secret_error("container file is inaccessible") from None
        if result.returncode or len(result.stdout) > 1024 * 1024:
            raise secret_error("container file is inaccessible")
        return result.stdout
    try:
        result = run_command(
            ["docker", "cp", f"{container['Id']}:{path}", "-"], step,
            stdout_kind="secret", response_limit=2 * 1024 * 1024, env=work_environment(),
        )
        if result.returncode:
            raise secret_error("container file is inaccessible")
        with tarfile.open(fileobj=io.BytesIO(result.stdout), mode="r:*") as archive:
            files = archive.getmembers()
            if len(files) != 1 or not files[0].isfile() or files[0].size > 1024 * 1024:
                raise secret_error("unsupported secret file")
            stream = archive.extractfile(files[0])
            if stream is None:
                raise secret_error("unreadable secret file")
            value = stream.read()
            return value
    except (OSError, ValueError, subprocess.TimeoutExpired, tarfile.TarError):
        raise secret_error("container file is inaccessible") from None


def sql(container: Any, database: str, query: str) -> str:
    """Execute caller-supplied SQL using credentials resolved inside PostgreSQL.

    Queries may mutate databases; this helper does not enforce read-only SQL or
    acquire operation locks. The current work identity tags the database session.

    Args:
        container: Running PostgreSQL container with mounted credential configuration.
        database: Database to connect to over in-container loopback.
        query: SQL executed with ON_ERROR_STOP and no user psql configuration.

    Returns:
        Stripped unaligned, tuples-only output.

    Raises:
        MigrationError: Credential access, SQL execution, or the bounded command fails.
    """
    from capture import application_name

    technical("Database operation: database={}; container={}; service={}; application_name={}".format(
        database, container["Id"], container["Config"]["Labels"].get(SERVICE_LABEL, "unavailable"),
        application_name()))
    # Resolve credentials in the container, never in host config or argv.
    script = """set -eu
export PGPASSWORD="$(cat "$POSTGRES_PASSWORD_FILE")"
test -n "$PGPASSWORD"
export PGAPPNAME="$3"
exec psql -X -w -h 127.0.0.1 -U "$POSTGRES_USER" -d "$1" -At -v ON_ERROR_STOP=1 -v VERBOSITY=verbose -c "$2"
"""
    return execute(
        container,
        "sh",
        "-c",
        script,
        "preflight",
        database,
        query,
        application_name(),
        step=f"Database access {database}",
    )


def storage(container: Any, directory: str) -> Tuple[str, int]:
    """Probe available filesystem bytes inside a running container.

    Args:
        container: Inspected container used for the read-only df probe.
        directory: Existing path on the filesystem to measure.

    Returns:
        Device spelling and currently available bytes; no space is reserved.

    Raises:
        MigrationError: The probe fails or its available-size field is invalid."""
    output = execute(
        container, "df", "-Pk", directory, step="Database storage capacity"
    )
    try:
        fields = output.splitlines()[-1].split()
        available = int(fields[3]) * 1024
        if available < 0:
            raise ValueError
        return fields[0], available
    except (ValueError, IndexError):
        raise MigrationError(
            "Database storage capacity is unavailable or invalid"
        ) from None


def backup_storage_directory(operation: str, backup: Path) -> Path:
    """Check backup access without creating a proposed dump destination.

    Capacity probes for a missing dump target use its nearest existing parent.
    Restore always requires the selected directory to exist.
    """
    probe = backup
    if operation == "dump":
        while not probe.exists() and not probe.is_symlink():
            parent = probe.parent
            if parent == probe:
                break
            probe = parent
    access = os.W_OK | os.X_OK if operation == "dump" else os.R_OK | os.X_OK
    if not probe.is_dir() or not os.access(probe, access):
        raise MigrationError(
            "Backup storage must be an accessible directory (or have an accessible existing parent for dump)"
        )
    return probe


def capacity_with_margin(required_bytes: int) -> int:
    """Add fixed 10% allocation headroom, rounding up to a whole byte."""
    return (required_bytes * 11 + 9) // 10


def check_storage_capacity(
    operation: str, backup: Path, services: Dict[str, Any]
) -> None:
    """Probe allocation reserves before new work, after interrupted dump recovery.

    Args:
        operation: Dump or restore phase whose storage is being probed.
        backup: Accessible backup directory on the local Docker host.
        services: Validated installation containers.

    Raises:
        MigrationError: Capacity is unavailable or fresh capture lacks its reserve.
    """
    total = 0
    capacities: Dict[str, Tuple[int, int]] = {}
    databases = SOURCES if operation == "dump" else {"osi-postgres": "postgres"}
    for name, database in databases.items():
        container = require(services, name)
        dbs = (database,) if operation == "dump" else ("postgres",)
        size = 0
        for db in dbs:
            size += int(
                sql(container, db, "SELECT pg_database_size(current_database())")
            )
            technical(f"Database accessible: {name}/{db}", flush=True)
        total += size
        data_dir = sql(container, dbs[0], "SHOW data_directory")
        device, available = storage(container, data_dir)
        # Device identity is meaningful across containers on this same Docker host.
        previous_size, previous_free = capacities.get(device, (0, available))
        capacities[device] = (previous_size + size, min(previous_free, available))
    backup_storage = backup_storage_directory(operation, backup)
    host = os.statvfs(backup_storage)
    free_backup = host.f_bavail * host.f_frsize
    host_device = (
        run(["df", "-Pk", str(backup_storage)], "Backup storage capacity")
        .splitlines()[-1]
        .split()[0]
    )
    technical(
        f"Capacity: {'allocated database bytes' if operation == 'dump' else 'maintenance database probe bytes'}={total}; backup free bytes={free_backup}",
        flush=True,
    )
    if operation == "dump":
        # Old data is already allocated. Reserve S for encrypted backup and S for
        # new data, on their actual filesystems; do not require an additional 3S.
        backup_shared = host_device in capacities
        backup_required = capacity_with_margin(total * (2 if backup_shared else 1))
        technical("Backup reserve bytes={}".format(backup_required), flush=True)
        if free_backup < backup_required:
            raise MigrationError(
                f"Insufficient disk space for backup. Needed: {backup_required / 1_000_000_000:.1f} GB, "
                f"available: {free_backup / 1_000_000_000:.1f} GB. Please free up disk space before proceeding. "
                f"Required free space: {backup_required} bytes (includes 10% headroom)."
            )
        for device, (_, available) in capacities.items():
            # Y consolidates all data onto one storage filesystem; reserve all S
            # on each candidate source filesystem until Y placement is configured.
            required = capacity_with_margin(total * (2 if device == host_device else 1))
            technical(
                f"Database filesystem: {device}; free bytes={available}; reserve bytes={required}",
                flush=True,
            )
            if available < required:
                raise MigrationError(
                    f"Insufficient database capacity for restored data. Needed: {required / 1_000_000_000:.1f} GB, "
                    f"available: {available / 1_000_000_000:.1f} GB. Please free up disk space in the partition where the docker volumes are stored. "
                    f"Required free space: {required} bytes (includes 10% headroom)."
                )
        technical(
            "Sizing estimate: allocated old data S + backup S + new data S, with 10% headroom on free reserves (~3.2S total on shared storage); "
            "reserve only unallocated backup/new data plus headroom, rounded up. Conservative estimate, not a guarantee.",
            flush=True,
        )
    else:
        technical(
            "Restore estimates use backup-derived source sizes during artifact validation.",
            flush=True,
        )


def local_daemon() -> str:
    """Check the supported host runtime and resolve the local Docker identity."""
    if sys.version_info < (3, 6) or sys.prefix != sys.base_prefix:
        raise MigrationError("Use system Python 3.6 or newer (base interpreter)")
    daemon = docker("info", "--format", "{{.ID}}", step="Docker access")
    # Only same-host Unix-socket deployments can share the host capacity probe.
    endpoint = os.environ.get("DOCKER_HOST", "")
    if os.environ.get("DOCKER_CONTEXT") or not endpoint:
        context = docker("context", "show", step="Docker context")
        endpoint = docker(
            "context",
            "inspect",
            context,
            "--format",
            "{{.Endpoints.docker.Host}}",
            step="Docker endpoint",
        )
    if not endpoint.startswith("unix://"):
        raise MigrationError("Migration requires a local Docker Unix socket")
    technical(f"Docker identity: daemon={daemon}")
    return daemon


def installed_version(services: Dict[str, Any], *, diagnostic: bool = False) -> str:
    """Read the deployed version even when the frontend is stopped.

    Container configuration is authoritative when provided. A running frontend
    can also expose an image-provided version through printenv. Dump treats an
    unavailable version as diagnostic only; restore requires a valid version.
    """
    frontend = require(services, "notification-service-frontend", running=False)
    versions = [entry.partition("=")[2] for entry in frontend["Config"].get("Env", [])
                if entry.startswith("FWS_OSI_PRODUCT_VERSION=")]
    if len(versions) > 1:
        if diagnostic:
            return "unknown"
        raise MigrationError("Duplicate installed FWS_OSI_PRODUCT_VERSION entries")
    if versions:
        return versions[0] or ("unknown" if diagnostic else "")
    if frontend["State"]["Running"] and not frontend["State"].get("Restarting"):
        try:
            return execute(frontend, "printenv", "FWS_OSI_PRODUCT_VERSION", step="Installed version") or "unknown"
        except MigrationError:
            if not diagnostic:
                raise
    elif not diagnostic:
        raise MigrationError("Cannot determine installed version")
    return "unknown"


def restore_version_eligibility(services: Dict[str, Any], version: str) -> None:
    """Retain the deployed release ceiling for every restore, including no-ops."""
    from guard import valid_version, version_at_most

    guard = require(services, "osi-postgres-migration-guard", running=False)
    ceilings = [
        entry.partition("=")[2]
        for entry in guard["Config"].get("Env", [])
        if entry.startswith("MIGRATION_TARGET_VERSION=")
    ]
    if len(ceilings) != 1 or not valid_version(ceilings[0]):
        raise MigrationError(
            "Deployed guard requires one valid MIGRATION_TARGET_VERSION; apply deployment configuration first"
        )
    if not valid_version(version):
        raise MigrationError(
            f"Malformed installed FWS_OSI_PRODUCT_VERSION: {version!r}"
        )
    if not version_at_most(version, ceilings[0]):
        raise DowngradeRequired(
            f"Installed version {version} is above {ceilings[0]}; downgrade to {ceilings[0]} and run the restore again.",
            "target", restore_fact=f"Installed version {version} is above {ceilings[0]}.",
        )


def runtime_prerequisites(*, artifacts_required: bool) -> None:
    """Check the interpreter and tools needed by the selected unfinished work."""
    if sys.version_info < (3, 6) or sys.prefix != sys.base_prefix:
        raise MigrationError("Use system Python 3.6 or newer (base interpreter)")
    executables = [("docker", "Docker")]
    if artifacts_required:
        executables.extend((("openssl", "OpenSSL"), ("df", "filesystem df")))
    for executable, label in executables:
        if shutil.which(executable) is None:
            raise MigrationError(f"Missing prerequisite: {label}")


def archive_prerequisites(operation: str, backup: Path, passphrase: Optional[Passphrase]) -> None:
    """Probe archive access and encryption without changing deployment state."""
    backup_storage_directory(operation, backup)
    if passphrase is None:
        raise MigrationError("Passphrase required for unfinished archive work")
    if isinstance(passphrase, Path):
        try:
            with passphrase.open("rb") as stream:
                if not stream.read(1):
                    raise MigrationError("Passphrase file is empty")
        except OSError:
            raise MigrationError("Passphrase file is inaccessible") from None
    if operation == "restore" and not os.access(backup, os.R_OK):
        raise MigrationError("Backup storage is inaccessible")
    run(
        ["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-iter", "600000",
         "-md", "sha256", "-salt"],
        "OpenSSL encryption capabilities", "", passphrase=passphrase,
    )


def application_credentials(services: Dict[str, Any], *, schema_required: bool = True) -> None:
    """Check current database credentials used by the required applications."""
    for name, credential in APP_CREDENTIALS.items():
        container = secret_provider(services, name) if schema_required else services[name]
        if not read_secret(container, credential):
            raise DeploymentPrerequisite(
                f"Empty application credential in {container['Config']['Labels'][SERVICE_LABEL]} {credential}; prepare secrets through restarting OPENVAS Security Intelligence and try again.",
                restore_fact=f"Empty application credential in {container['Config']['Labels'][SERVICE_LABEL]} {credential}", category="secret"
            )


def asset_management_prerequisites(services: Dict[str, Any], *, schema_required: bool) -> None:
    """Check required authentication and provided Asset logging configuration.

    Both migration-only and application startup load DatabaseConfig. Defaults
    need no override; provided values must satisfy its Go parser and validator.
    """
    backend = services["asset-management-backend"]
    provider = secret_provider(services, "asset-management-backend") if schema_required else backend
    credential = "/run/secrets/ASSET_BACKEND_CLIENT_SECRET"
    if not read_secret(provider, credential).rstrip(b"\n"):
        raise DeploymentPrerequisite("Empty required Asset Management authentication secret " + credential, category="secret")
    containers = [backend]
    if schema_required:
        containers.append(provider)
    for container in containers:
        environment = dict(entry.split("=", 1) for entry in container["Config"].get("Env", []))
        boolean = environment.get("GORM_LOGGING")
        if boolean is not None and boolean not in (
            "1", "t", "T", "TRUE", "true", "True", "0", "f", "F", "FALSE", "false", "False"
        ):
            raise DeploymentPrerequisite("Invalid Asset Management GORM_LOGGING; expected a Go boolean")
        slow = environment.get("GORM_LOGGING_SLOW_MS")
        if slow is not None:
            digits = slow.lstrip("+").lstrip("0")
            # DatabaseConfig uses required,min=0: zero fails required. The
            # packaged Linux amd64 runtime parses this field as a signed64 int.
            if (re.fullmatch(r"\+?[0-9]+", slow) is None or not digits
                    or len(digits) > 19
                    or (len(digits) == 19 and digits > "9223372036854775807")):
                raise DeploymentPrerequisite("Invalid Asset Management GORM_LOGGING_SLOW_MS; expected a positive signed64 integer")


def encryption_secrets(services: Dict[str, Any]) -> None:
    """Check capture/restore encryption inputs without retaining secret contents."""
    for name, paths in SECRETS.items():
        container = secret_provider(services, name)
        for path in paths:
            if not read_secret(container, path):
                raise DeploymentPrerequisite(
                    f"Empty application secret in {container['Config']['Labels'][SERVICE_LABEL]} {path}; prepare secrets through restarting OPENVAS Security Intelligence and try again.",
                    restore_fact=f"Empty application secret in {container['Config']['Labels'][SERVICE_LABEL]} {path}", category="secret"
                )


def database_archive_tools(services: Dict[str, Any], databases: Dict[str, str]) -> None:
    """Check PostgreSQL archive tools only for capture or unfinished restoration."""
    for name in databases:
        container = require(services, name)
        for client, tokens in (
            ("pg_dump", ("--format", "--snapshot")),
            ("pg_restore", ("--list", "--exit-on-error")),
        ):
            help_text = execute(container, client, "--help", step=f"{name} {client} capabilities")
            if not all(token in help_text for token in tokens):
                raise MigrationError(f"{name}: unsupported {client} capabilities")


def preflight(
    operation: str,
    backup: Path,
    passphrase: Optional[Passphrase],
    project: Optional[str],
    *,
    defer_dump_capacity: bool = False,
    restoration_required: bool = True,
    reconstruction_required: bool = True,
) -> PreflightResult:
    """Probe prerequisites and installation identity before workflow mutation.

    Does not stop services, change database data, or publish completion. Docker,
    secret, SQL and encryption probes still run. This is no authorization against
    concurrent deployment; callers coordinate deployment separately.

    Args:
        operation: Dump or restore, as validated by the CLI.
        backup: Existing accessible directory on the local Docker host.
        passphrase: Nonempty readable passphrase, or None when restoration is completed.
        project: Selected Compose project, or None for unambiguous discovery.
        defer_dump_capacity: Let capture check capacity after interruption recovery.
        restoration_required: Select archive, encryption, restore-tool and capacity
            prerequisites. False retains current installation/application checks
            for callers resuming later work; dump always checks its artifacts.

    Returns:
        Named Docker daemon identity, project, version provenance and services.
        Dump uses unknown when diagnostic version information is unavailable.

    Raises:
        MigrationError: Runtime, version, topology, credentials or capacity fails.
        OSError: A host storage probe is inaccessible.
        ValueError: A command response cannot be parsed."""
    artifacts_required = operation == "dump" or restoration_required
    runtime_prerequisites(artifacts_required=artifacts_required)
    daemon = local_daemon()
    project, services = discover(project)
    version = installed_version(services, diagnostic=operation == "dump")
    if operation == "restore":
        restore_version_eligibility(services, version)
    if operation == "dump":
        if "osi-postgres" in services:
            raise DowngradeRequired(
                "The dump requires the source deployment with separate PostgreSQL services; "
                "downgrade to the source deployment and start the dump again.",
                "source",
            )
        databases = SOURCES
    else:
        if any(name in services for name in SOURCES):
            raise MigrationError(
                "Unsupported destination topology: legacy database services exist"
            )
        require_initialization(services)
        require(services, "osi-postgres")
        databases = {"osi-postgres": "postgres"}
    for name, container in services.items():
        if (
            (
                name.endswith(("-migration", "-upgrade", "-db-init"))
                or name == "keycloak-sidecar"
            )
            and (container["State"]["Running"] or container["State"].get("Restarting"))
            and (operation == "dump" or name.endswith(("-upgrade", "-db-init")))
        ):
            raise MigrationError(f"Conflicting migration/bootstrap activity: {name}")
    for name in WRITERS:
        writer = require(services, name, running=False)
        if writer["Config"]["Labels"].get(WRITER_LABEL) != "true":
            raise MigrationError(f"Unsupported writer labels: {name}")
    require(services, "ingress", running=False)
    if artifacts_required:
        archive_prerequisites(operation, backup, passphrase)
    application_credentials(services, schema_required=reconstruction_required)
    if operation == "restore":
        asset_management_prerequisites(services, schema_required=reconstruction_required)
    if artifacts_required:
        encryption_secrets(services)
        database_archive_tools(services, databases)
    technical(
        f"Installation: project={project}; daemon={daemon}; version={version}",
        flush=True,
    )
    technical("Services: " + ", ".join(sorted(services)), flush=True)
    technical("Writers: " + ", ".join(WRITERS), flush=True)
    if artifacts_required and (operation != "dump" or not defer_dump_capacity):
        check_storage_capacity(operation, backup, services)
    if operation == "restore":
        technical("Preflight complete; no services or databases changed.", flush=True)
    elif not defer_dump_capacity:
        customer("Preflight complete; no services or databases changed.", flush=True)
    return PreflightResult(daemon, project, version, services)


@contextmanager
def passphrase_input(operation: str, supplied: Optional[Path]) -> Iterator[Passphrase]:
    """Keep a file input or a hidden terminal secret available to OpenSSL.

    Prompted input stays in memory. Each OpenSSL child receives a fresh pipe;
    no secret value enters argv, the environment or a plaintext temporary file.
    """
    if supplied is not None:
        yield supplied
        return
    if not sys.stdin.isatty():
        raise MigrationError("Supply --passphrase-file or use an interactive terminal")
    if operation == "restore":
        customer("Passphrase for decrypting backup needed (Note: this was set during the dump).")
    try:
        with warnings.catch_warnings():
            # getpass normally falls back to echoed stdin on terminal errors.
            # Refuse instead: every prompted secret must remain hidden.
            warnings.simplefilter("error", getpass.GetPassWarning)
            prompt("Enter passphrase: ")
            value = getpass.getpass("Enter passphrase: ")
            if not value:
                raise MigrationError("Passphrase must not be empty")
            if operation == "dump":
                prompt("Confirm passphrase: ")
                confirmation = getpass.getpass("Confirm passphrase: ")
                if value != confirmation:
                    raise MigrationError("Passphrases do not match")
    except getpass.GetPassWarning:
        raise MigrationError(
            "Hidden terminal input unavailable; supply --passphrase-file"
        ) from None
    except (EOFError, KeyboardInterrupt):
        raise MigrationError(
            "Passphrase input cancelled or ended; no changes made"
        ) from None
    yield Secret(value.encode("utf-8"))


class DiagnosticParser(argparse.ArgumentParser):
    """Keep help side-effect free and argument diagnostics best effort."""
    def prepare_error_log(self):
        """Establish only the existing best-effort file before usage guidance."""
        if diagnostics.path is None:
            def option(name):
                for index, value in enumerate(sys.argv):
                    if value == name and index + 1 < len(sys.argv):
                        return sys.argv[index + 1]
                    if value.startswith(name + '='):
                        return value.split('=', 1)[1]
                return None
            try:
                diagnostics.setup(sys.argv[1] if len(sys.argv) > 1 else 'postgres',
                                  option('--backup-dir'), option('--log-file'))
            except diagnostics.LogSetupError:
                pass

    def error(self, message):
        self.prepare_error_log()
        technical('Argument error: invalid command-line arguments', level=40)
        super().error(message)


def restore_error_text(exc: MigrationError) -> str:
    """Keep authored cause facts while shared callers retain their original advice."""
    if isinstance(exc, InitializationIncomplete):
        return "Destination database initialization has not completed successfully. The database is not ready for the restore."
    if isinstance(exc, (DowngradeRequired, DeploymentPrerequisite)):
        return exc.restore_fact
    return str(exc)


def main() -> int:
    try:
        return _main()
    finally:
        diagnostics.close()


def _main() -> int:
    """Parse command-line inputs and dispatch the authorized migration workflow.

    Preflight-only performs probes without capture or restore. Ordinary commands
    may change services, databases and durable records; restore prints exclusion
    and retry guidance before probing. Reports total wall time for dispatched work.

    Returns:
        Zero on success; one for handled preflight, storage or response failures.

    Raises:
        SystemExit: Argument parsing fails or help was requested."""
    started = time.monotonic()
    parser = DiagnosticParser(description=__doc__)
    operations = parser.add_subparsers(dest="operation")
    dump_parser = operations.add_parser(
        "dump",
        prog="backup-databases-before-upgrade.sh",
        add_help=False,
        description="Capture an encrypted PostgreSQL migration backup.",
        formatter_class=lambda prog: argparse.HelpFormatter(prog, width=176),
    )
    restore_parser = operations.add_parser(
        "restore",
        prog="restore-databases-after-upgrade.sh",
        add_help=False,
        description="Restore a PostgreSQL migration backup, or separately clear legacy database contents.",
        formatter_class=lambda prog: argparse.HelpFormatter(prog, width=176),
    )
    dump_advanced = dump_parser.add_argument_group("advanced options")
    restore_advanced = restore_parser.add_argument_group("advanced options")
    dump_parser.set_defaults(
        upgrade_finished=False,
        replace_existing=False,
        replace_completed=False,
        confirm_restore=False,
        cleanup_legacy_volumes=False,
    )
    for command in (dump_parser, restore_parser):
        advanced = restore_advanced if command is restore_parser else dump_advanced
        command.add_argument(
            "-h",
            "--help",
            action="help",
            help="Show this help and exit; omit to run the selected workflow",
        )
        advanced.add_argument(
            "--no-journal", action="store_true",
            help="Disable journal logging; retain the private diagnostic file",
        )
        advanced.add_argument(
            "--log-file", type=Path,
            help=("Create a diagnostic log at PATH (must not exist); default: dump-postgres-YYYYMMDDTHHMMSS-<32-character-id>.log in current directory"
                  if command is dump_parser else
                  "Create a diagnostic log at PATH (must not exist); default: restore-postgres-YYYYMMDDTHHMMSS-<32-character-id>.log in current directory"),
        )
        command.add_argument(
            "--backup-dir", type=Path, required=command is dump_parser,
            help=("Directory for the backup files. Must be an empty or not yet existing directory."
                  if command is dump_parser else
                  "Directory for the backup files. Must be an existing readable directory (required for restore; not used for cleanup)."),
        )
        if command is restore_parser:
            advanced.add_argument(
                "--cleanup-legacy-volumes", action="store_true",
                help="Delete the legacy docker volumes contents. After this, redoing a backup is impossible. "
                "Note: This is a completely separate mode from the restore and does not need any of its flags "
                "(default: retain legacy data)",
            )
        advanced.add_argument(
            "--deployment-tool", choices=('os-container-management', 'openvas-deployment', 'openvas-install', 'manual'),
            help="Select deployment advice tool; default: detect executable, then optionally ask",
        )
        advanced.add_argument("--source-version", default="1.6.0", help="Source deployment advice version (default: 1.6.0; advice only)")
        advanced.add_argument("--target-version", default="1.7.0", help="Target deployment advice version (default: 1.7.0; advice only)")
        advanced.add_argument(
            "--project",
            help="Select a Compose project; omit to discover the sole installation (ambiguous discovery fails)",
        )
        advanced.add_argument(
            "--preflight-only",
            action="store_true",
            help="Check prerequisites only; does not decrypt or validate the backup "
            "(default: perform the full workflow)",
        )
        advanced.add_argument(
            "--passphrase-file",
            type=Path,
            help=(
                "self chosen passphrase for encrypting the backup (default: set by prompt)"
                if command is dump_parser else
                "self chosen passphrase for decrypting the backup (default: set by prompt)"
            ),
        )
    restore_advanced.add_argument(
        "--confirm-restore", action="store_true",
        help="Acknowledge backup age and confirm restore (default: ask)",
    )
    restore_advanced.add_argument(
        "--upgrade-finished",
        action="store_true",
        help="Acknowledge upgrade has finished (default: ask for upgrade acknowledgement)",
    )
    restore_advanced.add_argument(
        "--replace-existing",
        action="store_true",
        help="Authorize database recreation for an initial or incomplete data restore "
        "(default: ask for replacement consent); durable completed phases still resume",
    )
    restore_parser.add_argument(
        "--replace-completed",
        action="store_true",
        help="Deliberately discard intermediate or final completed work and restore the selected backup again "
        "(default: resume completed phases)",
    )
    try:
        args = parser.parse_args()
    except SystemExit as error:
        if (
            error.code
            and sys.argv[1:2] == ["restore"]
            and "--cleanup-legacy-volumes" in sys.argv
        ):
            from cleanup import cleanup_command, report_targets

            report_targets(None)
            customer("Retry legacy cleanup: " + cleanup_command(), flush=True)
        raise
    if args.operation is None:
        parser.error("the following arguments are required: operation")
    if args.cleanup_legacy_volumes:
        from cleanup import cleanup_command, cleanup_legacy_volumes, report_targets

        if args.operation != "restore" or any(
            (
                args.project,
                args.backup_dir,
                args.passphrase_file,
                args.preflight_only,
                args.replace_existing,
                args.replace_completed,
                args.upgrade_finished,
                args.confirm_restore,
            )
        ):
            parser.prepare_error_log()
            report_targets(None)
            customer("Retry legacy cleanup: " + cleanup_command(), flush=True)
            parser.error(
                "--cleanup-legacy-volumes is a separate restore mode; do not combine it with restore options"
            )
    if not args.cleanup_legacy_volumes and args.backup_dir is None:
        parser.error("--backup-dir is required for dump/restore")
    if args.operation == "dump" and args.upgrade_finished:
        parser.error("--upgrade-finished applies only to restore")
    if args.operation == "dump" and (args.replace_existing or args.replace_completed):
        parser.error("replacement flags apply only to restore")
    try:
        diagnostics.setup(
            "cleanup" if args.cleanup_legacy_volumes else args.operation,
            args.backup_dir, args.log_file, journal=not args.no_journal,
        )
    except diagnostics.LogSetupError as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        return 1
    if args.cleanup_legacy_volumes:
        return cleanup_legacy_volumes()
    from deployment_advice import HostAdvice
    advice = HostAdvice(args.deployment_tool, args.source_version, args.target_version)
    if args.operation == "dump":
        customer(
            "For improved resource utilization, OPENVAS Security Intelligence\n"
            "will consolidate its databases and switch from multiple PostgreSQL\n"
            "instances to a single instance.\n\n"
            "This script will dump all data stored in the different PostgreSQL instances.\n"
            "After a successful dump, OPENVAS Security Intelligence can\n"
            f"be upgraded to version {args.target_version}.\n\n"
            "IMPORTANT:\n"
            "Any data added after the dump will be lost.\n"
            f"Therefore, only execute this script when the upgrade to {args.target_version} is available\n"
            f"and DIRECTLY BEFORE upgrading to {args.target_version}.\n\n"
            f"After the upgrade to {args.target_version}, execute IMMEDIATELY the restore script to restore the captured data.\n\n"
            "For the dump, services will be stopped and will remain stopped until you upgrade.\n"
            "The captured database content will be stored in encrypted files.\n"
            "Set a passphrase for encryption and store it in a safe place. A restore without it\n"
            "is not possible and would require repeating the dump.\n"
        )
    if args.operation == "restore":
        from restoration import DEPLOYMENT_WARNING

        customer("This script will restore the data captured by the backup before the upgrade.\n")
        customer(DEPLOYMENT_WARNING.replace("1.7.0", advice.target_version), level=logging.WARNING, flush=True)
    inputs = ExitStack()
    restore_outcome = None
    restore_execution_started = False
    try:
        destination = None
        selected_postgres = None
        restoration_required = True
        reconstruction_required = True
        if args.operation == "restore":
            from capture import StateVolume, reconcile_work
            from destination import Destination
            from restoration import (
                DEPLOYMENT_PROMPT,
                REPLACEMENT_PROMPT,
                affirmative_confirmation,
                control_identity,
                report_existing_data,
                restore_lock,
            )

            unchanged = (
                "Current deployment unchanged"
            )
            from activation import (
                RestoreOutcome,
                _completed_backup_matches,
                _report_completed_noop,
                binding,
                read_checkpoints,
                schema_topology,
                activation_topology,
                record_matches,
                read_restore_evidence,
            )
            from validation import read_manifest

            daemon = local_daemon()
            args.project, selected_services = discover(args.project)
            # Phase selection and surviving publishers share installation ownership
            # for normal execution and read-only preflight alike.
            inputs.enter_context(restore_lock(daemon, args.project))
            restore_outcome = RestoreOutcome()
            try:
                reconcile_work(selected_services, control_identity(daemon, args.project), "restore", state_only=True)
            except Exception:
                restore_outcome.safe_state_unknown = True
                raise
            restore_version_eligibility(selected_services, installed_version(selected_services))
            if any(name in selected_services for name in SOURCES):
                raise MigrationError("Unsupported destination topology: legacy database services exist")
            selected_postgres = require(selected_services, "osi-postgres", running=False)
            destination = Destination.resolve(selected_postgres)
            technical("Selected restore context: project={}; daemon={}; databases={}".format(
                args.project, daemon, ", ".join(destination.databases)))
            try:
                manifest = read_manifest(args.backup_dir, daemon, args.project)
            except MigrationError as exc:
                raise RestoreBlocker(str(exc), "Inspect and correct the reported backup or access problem before restoring.") from None
            state = StateVolume(args.project, selected_services, create=False)
            # Explicit replacement does not rely on possibly invalid completion evidence.
            prior = None if args.replace_completed else read_restore_evidence(state, "migration-complete.json")
            if prior is not None:
                same_backup = _completed_backup_matches(
                    prior, binding(manifest), args.project, daemon, destination
                )
                if same_backup and not args.replace_completed:
                    restore_outcome = RestoreOutcome()
                    restore_outcome.completion = "completed"
                    _report_completed_noop()
                    return 0
            postgres, reconstruction = (read_checkpoints(state, args.project, destination)
                                        if prior is None and not args.replace_completed else (None, None))
            same_postgres = postgres is not None and record_matches(postgres, binding(manifest), args.project)
            restoration_required = not same_postgres or args.replace_completed
            reconstruction_required = restoration_required or reconstruction is None
            restore_outcome.postgres_restored = postgres is not None
            restore_outcome.findings_reconstructed = reconstruction is not None
            require_initialization(selected_services)
            if args.upgrade_finished:
                technical("Upgrade acknowledgement authorized by --upgrade-finished", logging.INFO)
            if args.replace_completed:
                technical("Completed replacement authorized by --replace-completed", logging.INFO)
            elif args.replace_existing:
                technical("Replacement authorized by --replace-existing", logging.INFO)
            if restoration_required and not args.upgrade_finished and not args.preflight_only:
                affirmative_confirmation(
                    DEPLOYMENT_PROMPT.replace("1.7.0", advice.target_version),
                    "Restore can only run if the upgrade has finished; " + unchanged,
                    action="Finish the upgrade, then rerun restore and confirm it has finished (or supply --upgrade-finished).",
                )
            technical(f"Selected installation: project={args.project}; daemon={daemon}", flush=True)
            technical("Mapped destination databases: " + ", ".join(destination.databases), flush=True)
            has_existing_data = (report_existing_data(require(selected_services, "osi-postgres"), destination)
                                 if restoration_required and not args.preflight_only else False)
            if (prior is not None or (postgres is not None and not same_postgres)) and not args.replace_completed and not args.preflight_only:
                from restoration import COMPLETED_REPLACEMENT_PROMPT
                affirmative_confirmation(
                    COMPLETED_REPLACEMENT_PROMPT,
                    "Completed replacement was not authorized; " + unchanged,
                    action="If you intend a full replay, rerun restore and confirm replacement or supply --replace-completed. This discards completed work and subsequent writes in the mapped databases.",
                )
                args.replace_completed = True
            elif restoration_required and prior is None and not (args.replace_existing or args.replace_completed) and not args.preflight_only:
                if has_existing_data:
                    affirmative_confirmation(
                        REPLACEMENT_PROMPT,
                        "Replacement was not authorized; " + unchanged,
                        action="If you intend to replace existing data, rerun restore and confirm replacement or supply --replace-existing.",
                    )
                else:
                    technical("No nonempty application tables found; proceeding without replacement prompt", logging.INFO)
                args.replace_existing = True
        if restoration_required:
            args.passphrase_file = inputs.enter_context(
                passphrase_input(args.operation, args.passphrase_file)
            )
        from capture import phase

        if args.operation == "dump":
            customer("[1/5] Check prerequisites and available storage")
        else:
            customer("[1/9] Check prerequisites and backup compatibility")
        with phase("preflight", quiet=True):
            identity = preflight(
                args.operation,
                args.backup_dir,
                args.passphrase_file,
                args.project,
                defer_dump_capacity=not args.preflight_only,
                restoration_required=restoration_required,
                reconstruction_required=reconstruction_required,
            )
        if args.preflight_only:
            if args.operation == "restore":
                activation_topology(identity.services)
                if reconstruction_required:
                    schema_topology(identity.services)
                    from findings_history import reconstruction_prerequisites
                    fingerprints = postgres["report_encryption_fingerprints"] if not restoration_required else None
                    reconstruction_prerequisites(identity.services, control_identity(identity.daemon, identity.project), fingerprints,
                                                 restoration_required=restoration_required)
                customer("Backup capture time will be checked during actual restoration; this read-only check does not acknowledge restoration.")
                technical("Restore outcome: preflight complete; no services or databases changed; data not restored or verified", logging.INFO)
            if args.operation == "dump":
                technical("Dump outcome: preflight-only passed; no capture or source mutation attempted")
            return 0
        if args.operation == "dump":
            from capture import capture, format_duration, interruption_signals

            with interruption_signals():
                capture(
                    args.backup_dir,
                    args.passphrase_file,
                    identity.daemon,
                    identity.project,
                    identity.version,
                    identity.services,
                    advice=advice,
                )
            customer("Total time: " + format_duration(time.monotonic() - started))
        else:
            from activation import restore

            if selected_postgres is not None and (
                identity.daemon != daemon
                or identity.services["osi-postgres"]["Id"] != selected_postgres["Id"]
                or identity.services["osi-postgres"]["Config"].get("Env")
                != selected_postgres["Config"].get("Env")
            ):
                raise RestoreBlocker(
                    "Destination changed after replacement consent; no services or data changed",
                    "Inspect the destination changes, then rerun restore and review replacement consent again.",
                )
            restore_outcome = restore_outcome or RestoreOutcome()
            restore_execution_started = True
            restore(
                args.backup_dir,
                args.passphrase_file,
                identity.daemon,
                identity.project,
                identity.services,
                replace_existing=args.replace_existing,
                replace_completed=args.replace_completed,
                destination=destination,
                lock_held=True,
                outcome=restore_outcome,
                advice=advice,
                confirm_restore=args.confirm_restore,
            )
            from capture import format_duration
            customer("Total time: " + format_duration(time.monotonic() - started))
    except Exception as exc:
        diagnostics.failure(exc, "operation failure")
        if args.operation == "restore":
            technical("Restore command outcome: failed; dispatcher did not recheck final state; consult prerequisite, progress and recovery observations", logging.ERROR)
        if args.operation == "dump":
            technical("Dump command outcome: failed; source state not rechecked by dispatcher; "
                      "consult capture/recovery observations", level=40)
        preflight_failed = not restore_execution_started or (restore_outcome is not None and not restore_outcome.work_started)
        completion_settled = restore_outcome is not None and restore_outcome.completion == "completed"
        uncertain = restore_outcome is not None and (restore_outcome.safe_state_unknown or restore_outcome.completion == "unknown"
                    or restore_outcome.postgres_publication_unknown or restore_outcome.reconstruction_publication_unknown)
        customer(
            ("" if isinstance(exc, RestoreAcknowledgementRefused) else "ERROR: ")
            + (
                (restore_error_text(exc) if args.operation == "restore" else str(exc))
                if isinstance(exc, MigrationError)
                else "Unexpected failure ({}); see diagnostic log".format(type(exc).__name__)
            ),
            file=sys.stderr,
            level=40,
            flush=True,
        )
        activation_failed = restore_outcome is not None and restore_outcome.activation_failed
        deployment_recovery = (args.operation == "restore" and not completion_settled and not uncertain
                               and (isinstance(exc, DeploymentPrerequisite) or activation_failed))
        if args.operation == "restore" and completion_settled:
            customer("The migration completed; current product health was not checked.",
                     file=sys.stderr, level=logging.WARNING, flush=True)
        elif (args.operation == "restore" and not uncertain and restore_outcome is not None
              and restore_outcome.replacement_invalidation_blocked):
            state, _ = restore_outcome.guidance_parts()
            customer(state + "\n\nInvestigate why the completion record could not be updated. "
                     "If you intend a full replay, rerun restore with --replace-completed; "
                     "this discards completed work and subsequent writes in the mapped databases. "
                     "Keep the backup until the restore succeeds and do not use the product until then.",
                     file=sys.stderr, level=logging.WARNING, flush=True)
        elif args.operation == "restore" and isinstance(exc, (RestoreBlocker, BackupIntegrityError)) and not uncertain:
            state = restore_outcome.guidance_parts()[0] if restore_outcome is not None else "Restore checks did not finish."
            if preflight_failed and not isinstance(exc, RestoreAcknowledgementRefused):
                if restore_outcome is not None and (restore_outcome.postgres_restored or restore_outcome.findings_reconstructed):
                    state = "Restore preflight checks did not pass. " + state
                else:
                    state = "Restore preflight checks did not pass."
            action = ("Investigate the damaged backup and use an intact copy if available. "
                      "If you need to repeat the backup, one possible recovery is:"
                      if isinstance(exc, BackupIntegrityError) else exc.action)
            customer(("" if isinstance(exc, RestoreAcknowledgementRefused) else state + "\n\n") + action,
                     file=sys.stderr, level=logging.WARNING, flush=True)
            if isinstance(exc, (BackupIntegrityError, RestoreAcknowledgementRefused)):
                customer("1. Downgrade to OPENVAS Security Intelligence " + advice.source_version + ":", file=sys.stderr)
                advice.show("downgrade", advice.source_version, file=sys.stderr)
                customer("2. After the downgrade finishes, create a fresh backup in a new directory and wait for it to succeed."
                         if isinstance(exc, RestoreAcknowledgementRefused) else
                         "2. After the downgrade finishes, rerun the backup command and wait for it to succeed.", file=sys.stderr)
                customer("3. Only after the new backup succeeds, upgrade to OPENVAS Security Intelligence " + advice.target_version + ":", file=sys.stderr)
                advice.show("upgrade", file=sys.stderr)
                customer("4. After the upgrade finishes, rerun restore with the new backup. "
                         "Keep that backup until the restore succeeds and do not use the product until then.", file=sys.stderr)
            elif exc.retry:
                customer("Retry the restore with the same backup; the restore will resume from established completed phases. You may need the backup passphrase and replacement consent. Keep the backup until the restore succeeds and do not use the product until then.", file=sys.stderr, level=logging.WARNING, flush=True)
        elif deployment_recovery:
            state, retry = restore_outcome.guidance_parts() if restore_outcome is not None else ("Restore checks did not finish.", "The restore will resume from established completed phases.")
            if preflight_failed:
                customer("Restore prerequisite checks did not complete. Do not use OPENVAS Security Intelligence until the restore finishes successfully.", file=sys.stderr)
                if restore_outcome is not None and (restore_outcome.postgres_restored or restore_outcome.findings_reconstructed):
                    customer(state, file=sys.stderr)
            else:
                customer(state, file=sys.stderr)
            if isinstance(exc, InitializationIncomplete) or (isinstance(exc, DeploymentPrerequisite) and exc.category == "initialization"):
                investigation = "Investigate the initialization failure and correct its cause; wait for database initialization to succeed after restarting the deployment."
            elif isinstance(exc, DeploymentPrerequisite) and exc.category == "secret":
                investigation = "Investigate and correct the reported secret or credential problem; retain the matching original encryption secrets."
            else:
                investigation = "Investigate and correct the reported problem; inspect configuration, access, network and TLS where relevant."
            customer(investigation + "\nRedeploy OPENVAS Security Intelligence " + advice.target_version + " using the instructions below.", file=sys.stderr)
            advice.show("redeploy", file=sys.stderr)
            customer("When the deployment finishes, " + retry[0].lower() + retry[1:], file=sys.stderr)
        elif args.operation == "restore" and (not completion_settled or uncertain) and (not isinstance(exc, DowngradeRequired) or uncertain):
            state, action = restore_outcome.guidance_parts() if restore_outcome is not None else ("Restore checks did not finish.", "Retry the restore with the same backup.")
            if preflight_failed and not uncertain:
                if restore_outcome is not None and (restore_outcome.postgres_restored or restore_outcome.findings_reconstructed):
                    state = "Restore preflight checks did not pass. " + state
                else:
                    state = "Restore preflight checks did not pass."
            if isinstance(exc, CredentialsTransferError) and not uncertain:
                action = "Check that Docker is available, then " + action[0].lower() + action[1:]
            elif preflight_failed and not uncertain:
                action = "Investigate and resolve the reported problem before proceeding. " + action
            customer(state + "\n\n" + action, file=sys.stderr, level=logging.WARNING, flush=True)
        if isinstance(exc, DowngradeRequired) and (args.operation != "restore" or not uncertain and not completion_settled):
            version = advice.source_version if exc.advice_target == 'source' else advice.target_version
            target = sys.stderr if args.operation == "restore" else sys.stdout
            if args.operation == "restore":
                customer("Restore prerequisite checks did not complete.", file=target)
            customer('Downgrade to OPENVAS Security Intelligence {}:'.format(version), file=target)
            advice.show('downgrade', version, file=target)
        return 1
    finally:
        inputs.close()
        technical(f"Total command wall seconds={time.monotonic()-started:.3f}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
