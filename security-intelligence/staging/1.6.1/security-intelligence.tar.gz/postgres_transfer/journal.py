"""Best-effort structured journal transport using only Python's standard library."""
import socket
import struct


class Journal:
    """Send native journal entries with bounded waits for a congested receiver."""

    def __init__(self, run_id: str, operation: str) -> None:
        self.run_id = run_id
        self.operation = operation
        self.record = 0
        self.socket = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        try:
            self.socket.settimeout(0.05)
            self.socket.connect('/run/systemd/journal/socket')
        except OSError:
            self.socket.close()
            raise

    def emit(self, message: str, level: int) -> None:
        """Submit a message with its severity and invocation metadata."""
        priority = 2 if level >= 50 else 3 if level >= 40 else 4 if level >= 30 else 6 if level >= 20 else 7
        self.record += 1
        # At most 64 KiB of UTF-8 message bytes per datagram, plus metadata.
        # Split by characters so even non-ASCII text remains independently readable.
        size = 16384
        parts = max(1, (len(message) + size - 1) // size)
        for part in range(parts):
            fields = {
                'SYSLOG_IDENTIFIER': 'postgres-transfer',
                'POSTGRES_RUN_ID': self.run_id,
                'POSTGRES_OPERATION': self.operation,
                'PRIORITY': str(priority),
                'POSTGRES_RECORD': str(self.record),
                'POSTGRES_PART': str(part + 1),
                'POSTGRES_PARTS': str(parts),
                'MESSAGE': message[part * size:(part + 1) * size],
            }
            payload = bytearray()
            for key, value in fields.items():
                encoded = value.encode('utf-8', errors='replace')
                payload.extend(key.encode('ascii') + b'\n' + struct.pack('<Q', len(encoded)) + encoded + b'\n')
            self.socket.send(payload)

    def close(self) -> None:
        """Release the journal socket."""
        self.socket.close()
