"""Supported X Management Console/WST object membership for shared restoration."""

from typing import Any, Dict

from main import MigrationError, RestoreBlocker
from validation import SourceMapping, validate_inventory

class ApplianceLayoutBlocker(RestoreBlocker):
    """An appliance layout needs investigation before it can be restored."""

    def __init__(self, message: str) -> None:
        super().__init__(message, "Investigate the unsupported appliance contents and correct the source layout before retrying.")


# Membership is established by pinned-X migrations and actual archive evidence;
# the shared source owner cannot distinguish Management Console from WST.
CONTROL_TABLES = frozenset(
    [
        "auth_group",
        "auth_group_permissions",
        "auth_permission",
        "auth_user",
        "auth_user_groups",
        "auth_user_user_permissions",
        "counter",
        "django_content_type",
        "django_migrations",
        "django_session",
        "kv",
        "schedule",
        "system_management_appliance",
        "system_management_appliance_filter_options",
        "system_management_appliance_outbound",
        "system_management_appliance_registration",
        "system_management_appliance_selfcheck",
        "system_management_appliance_selfcheck_result",
        "system_management_appliance_state",
        "system_management_appliance_status",
        "system_management_appliance_support_package",
        "system_management_appliance_support_package_chunk",
        "system_management_appliance_upgrade_status",
        "task",
    ]
)
WST_TABLES = frozenset(("_sqlx_migrations", "wst_server_known_client"))


def appliance_mapping(
    metadata: Dict[str, Any], source_version: str = "1.6.0"
) -> "SourceMapping":
    """Validate inspected Management Console/WST membership without changing data.

    Args:
        metadata: Validated backup metadata with the shared source inventory.
        source_version: Configured source advice version for backup retry instructions.

    Returns:
        One appliance-management mapping with separate system-control-user and wst-user
        ownership, retaining row payloads and queue namespace unchanged.

    Raises:
        MigrationError: Concrete schemas, tables, dependencies or types are unfamiliar.
    """
    data = metadata["databases"]["management-console-backend"]
    if data.get("inventory_version") != 2:
        raise RestoreBlocker(
            "Appliance mapping requires version2 inventory",
            f"Select a compatible backup or capture a compatible backup from version {source_version} before restoring.",
        )
    try:
        validate_inventory(data)
    except MigrationError as exc:
        raise ApplianceLayoutBlocker(str(exc)) from None
    if (
        data["schemas"] != ["public"]
        or data.get("unsupported_objects")
        or data["functions"]
        or data["types"]
        or data["large_objects"]
    ):
        raise ApplianceLayoutBlocker(
            "Unsupported appliance schema/routine/type/large-object layout"
        )
    extensions = data["extensions"]
    if (
        len(extensions) != 1
        or extensions[0]["name"] != "plpgsql"
        or extensions[0].get("schema") != "pg_catalog"
    ):
        raise ApplianceLayoutBlocker(
            "Unexpected appliance extension infrastructure; only inspected plpgsql is supported"
        )
    allowed = CONTROL_TABLES | WST_TABLES
    tables = {item["name"]: item for item in data["relations"] if item["kind"] == "r"}
    if set(tables) != allowed:
        unexpected = sorted(set(tables) - allowed)
        missing = sorted(allowed - set(tables))
        raise ApplianceLayoutBlocker(
            f"Unexpected appliance table membership: unexpected={unexpected}; missing={missing}"
        )
    sequences = {
        name + "_id_seq": ("public", name, "id")
        for name in (
            "auth_group",
            "auth_group_permissions",
            "auth_permission",
            "auth_user",
            "auth_user_groups",
            "auth_user_user_permissions",
            "django_content_type",
            "django_migrations",
            "schedule",
            "task",
        )
    }
    actual_sequences = set()
    for item in data["relations"]:
        name = item["name"]
        if (
            item["schema"] != "public"
            or item["owner"] != "application-user"
            or item["extension"] is not None
            or item["parents"]
            or item["partition"]
            or item["triggers"]
        ):
            raise ApplianceLayoutBlocker(
                f"Unsupported appliance relation identity/ownership: {item['schema']}.{name}"
            )
        if item["kind"] == "r":
            if item["index_parent"] or item["sequence_owner"]:
                raise ApplianceLayoutBlocker(
                    f"Ambiguous appliance table dependency: public.{name}"
                )
        elif item["kind"] == "S":
            if (
                name not in sequences
                or tuple(item["sequence_owner"] or ()) != sequences[name]
                or item["index_parent"]
            ):
                raise ApplianceLayoutBlocker(
                    f"Ambiguous appliance sequence ownership: public.{name}"
                )
            actual_sequences.add(name)
        elif item["kind"] == "i":
            parent = item["index_parent"]
            if (
                not parent
                or parent[0] != "public"
                or parent[1] not in allowed
                or item["sequence_owner"]
            ):
                raise ApplianceLayoutBlocker(
                    f"Ambiguous appliance index ownership: public.{name}"
                )
        else:
            raise ApplianceLayoutBlocker(
                f"Unexpected appliance relation kind: public.{name}"
            )
    if actual_sequences != set(sequences):
        raise ApplianceLayoutBlocker(
            "Missing inspected appliance owned sequences"
        )
    # Application histories remain opaque; only the explicit WST data contract
    # retains its inspected column membership.
    expected_columns = {
        "wst_server_known_client": [
            "id",
            "server_port",
            "confirmed",
            "certificate_fingerprint",
        ],
    }
    for name, columns in expected_columns.items():
        if [column["name"] for column in tables[name]["columns"]] != columns:
            raise ApplianceLayoutBlocker(
                f"Unexpected appliance history/table columns: public.{name}"
            )
    return SourceMapping(
        "appliance-management",
        relation_moves={("public", "_sqlx_migrations"): "tunnel_migration_state"},
        object_owners={
            **{("public", name): "system-control-user" for name in CONTROL_TABLES},
            **{("public", name): "wst-user" for name in WST_TABLES},
        },
    )
