"""Explicit contents-only disposal of completed migration's legacy databases."""

import argparse
import fcntl
import json
import os
import re
import select
import shlex
import shutil
import signal
import stat
import subprocess
import sys
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

from guard import (
    LEGACY,
    Rejected,
    completed,
    entries,
    record,
)
from main import MigrationError, discover, docker
from diagnostics import customer, technical
from process_diagnostics import ProcessRecord


def cleanup_command() -> str:
    """Return the exact command for later cleanup using this supplied bundle."""
    return (
        shlex.quote(str(Path(__file__).resolve().parent.parent / "restore-databases-after-upgrade.sh"))
        + " --cleanup-legacy-volumes"
    )


def report_targets(project: Optional[str]) -> None:
    """List every intended target; a diagnostic fallback never authorizes deletion."""
    customer(
        "Legacy database cleanup removes contents, retaining volume objects and root directories.",
        flush=True,
    )
    if project is None:
        technical(
            "Intended fixed suffixes (unresolved project prefix; not discovered volumes):",
            flush=True,
        )
    for name in LEGACY:
        technical(f"  {project + '_' if project else '_'}{name}", flush=True)


@contextmanager
def cleanup_signals() -> Iterator[None]:
    """Report cancellation separately from restoration, preserving application state."""
    cancelled = False

    def interrupt(number: int, frame: Any) -> None:
        nonlocal cancelled
        if not cancelled:
            cancelled = True
            raise MigrationError(
                f"Legacy cleanup interrupted by signal {number}; completion and application state preserved"
            )

    previous = {n: signal.getsignal(n) for n in (signal.SIGINT, signal.SIGTERM)}
    for number in previous:
        signal.signal(number, interrupt)
    try:
        yield
    finally:
        for number, handler in previous.items():
            signal.signal(number, handler)


def validate_completion(state: Path, volumes: Path, project: str, daemon: str) -> None:
    """Require read-only bound completion; never compare current application data.

    Args:
        state: Read-only mounted migration evidence.
        volumes: Named database mount root; legacy contents need not be initialized.
        project: Sole discovered installation.
        daemon: Current local operation context, never compared to durable provenance.

    Raises:
        Rejected: Missing, malformed, unfinished or conflicting evidence.
        OSError: Required mounts or records are inaccessible.
    """
    entries(state)
    for name in LEGACY:
        entries(volumes / name)
    completion = record(state, "migration-complete.json")
    if completion is None or not completed(state, project):
        raise Rejected("Legacy cleanup requires durable Completed migration")


def mounted_cleanup(args: argparse.Namespace) -> int:
    """Validate mounted evidence then clear only direct legacy mount contents."""
    descriptor: Optional[int] = None
    try:
        descriptor = os.open(args.lease, os.O_RDWR | os.O_NOFOLLOW)
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise Rejected("Invalid cleanup operation lease")
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # The launcher holds restore_lock until this lease is acquired. A killed
        # launcher before this handshake leaves EOF and cannot authorize deletion.
        print("Legacy cleanup helper ready", flush=True)
        if sys.stdin.readline() != "cleanup\n":
            raise Rejected("Cleanup launcher disappeared before authorization")
        validate_completion(
            Path(args.state), Path(args.volumes), args.project, args.daemon
        )
        for name in LEGACY:
            directory = Path(args.volumes) / name
            for child in directory.iterdir():
                if child.is_dir() and not child.is_symlink():
                    shutil.rmtree(child)
                else:
                    child.unlink()
            if entries(directory):
                raise Rejected("Legacy contents remain after cleanup")
            print("Legacy contents cleared: " + args.project + "_" + name, flush=True)
        return 0
    except (Rejected, OSError, ValueError, KeyError) as error:
        print(f"Legacy cleanup failed: {error}", file=sys.stderr, flush=True)
        return 1
    finally:
        if descriptor is not None:
            os.close(descriptor)


@cleanup_signals()
def cleanup_installation(daemon: str, project: str, services: Dict[str, Any]) -> None:
    """Clear legacy contents under the caller's installation restore lock.

    Uses an isolated helper with read-only state/destination and exactly five
    writable legacy mounts. Does not access secrets, SQL, backup or service state.
    All failures retain completion and running applications and print retry scope.

    Args:
        daemon: Accepted local Docker daemon identity.
        project: Discovered installation identity.
        services: Current labeled containers including the guard's volume mounts.

    Raises:
        MigrationError: Ownership, completion, helper execution or cancellation fails.
    """
    report_targets(project)
    helper: Optional[str] = None
    process: "Optional[subprocess.Popen[str]]" = None
    observation = None
    try:
        if re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_.-]*", project) is None:
            raise MigrationError("Invalid discovered installation name")
        guard = services.get("osi-postgres-migration-guard")
        if guard is None:
            raise MigrationError(
                "Legacy cleanup requires the installed migration guard"
            )
        mounts: List[str] = []
        names: List[str] = []
        for name in (*LEGACY, "postgres-migration-state"):
            target = (
                "/state" if name == "postgres-migration-state" else "/volumes/" + name
            )
            selected = [
                item
                for item in guard.get("Mounts", [])
                if item.get("Destination") == target
            ]
            full = project + "_" + name
            if (
                len(selected) != 1
                or selected[0].get("Type") != "volume"
                or selected[0].get("Name") != full
            ):
                raise MigrationError(
                    "Guard mount does not identify intended owned volume: " + full
                )
            names.append(full)
            mounts.extend(
                [
                    "--mount",
                    f"type=volume,source={full},target={target},volume-nocopy"
                    + (",readonly" if name not in LEGACY else ""),
                ]
            )
        inspected = json.loads(
            docker(
                "volume",
                "inspect",
                *names,
                step="Inspect legacy cleanup volume ownership",
            )
        )
        if (
            {item.get("Name") for item in inspected} != set(names)
            or len(inspected) != len(names)
            or any(
                (item.get("Labels") or {}).get("com.docker.compose.project") != project
                for item in inspected
            )
        ):
            raise MigrationError(
                "Legacy cleanup volumes are not owned by the discovered installation"
            )
        from restoration import cleanup_lease

        lease = cleanup_lease(daemon, project)
        descriptor = os.open(lease, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        try:
            metadata = os.fstat(descriptor)
            if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != os.getuid():
                raise MigrationError("Invalid local cleanup operation lease ownership")
        finally:
            os.close(descriptor)
        helper = docker(
            "create",
            "--name",
            "osi-legacy-cleanup-" + uuid.uuid4().hex,
            "--interactive",
            "--network",
            "none",
            "--read-only",
            "--user",
            "0:0",
            "--cap-drop",
            "ALL",
            "--cap-add",
            "DAC_OVERRIDE",
            "--cap-add",
            "FOWNER",
            "--security-opt",
            "no-new-privileges:true",
            "--env",
            "PYTHONDONTWRITEBYTECODE=1",
            "--label",
            "net.greenbone.migration-operation=legacy-cleanup",
            "--label",
            "com.docker.compose.project=" + project,
            "--mount",
            f"type=bind,source={Path(__file__).resolve().parent},target=/runtime,readonly",
            "--mount",
            f"type=bind,source={lease},target=/cleanup-lease",
            *mounts,
            "--entrypoint",
            "/usr/local/bin/python3",
            guard["Config"]["Image"],
            "/runtime/cleanup.py",
            "--mounted",
            "--state",
            "/state",
            "--volumes",
            "/volumes",
            "--project",
            project,
            "--daemon",
            daemon,
            "--lease",
            "/cleanup-lease",
            step="Create isolated legacy cleanup helper",
        )
        command = ["docker", "start", "-ai", helper]
        observation = ProcessRecord(command, "Legacy cleanup helper", stdout="diagnostic")
        process = subprocess.Popen(
            command,
            universal_newlines=True,
            encoding="utf-8",
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        assert process.stdout is not None and process.stdin is not None
        observation.watch("stderr", process.stderr)
        deadline = time.monotonic() + 60
        greeting = bytearray()
        while not greeting.endswith(b"\n") and len(greeting) < 128:
            remaining = deadline - time.monotonic()
            if (
                remaining <= 0
                or not select.select([process.stdout], [], [], remaining)[0]
            ):
                raise MigrationError(
                    "Legacy cleanup helper startup timed out before deletion"
                )
            value = os.read(process.stdout.fileno(), 1)
            if not value:
                break
            greeting.extend(value)
        observation.watch("stdout", process.stdout)
        if greeting != b"Legacy cleanup helper ready\n":
            raise MigrationError(
                "Legacy cleanup helper did not acquire operation exclusion"
            )
        technical("Legacy cleanup helper acquired operation exclusion")
        customer("Clearing legacy database contents.")
        process.stdin.write("cleanup\n")
        process.stdin.flush()
        process.stdin.close()
        process.stdin = None
        process.wait()
        if process.returncode:
            raise MigrationError("Legacy cleanup helper failed (exit {}); see diagnostic log".format(process.returncode))
        technical("Legacy cleanup helper cleared the selected legacy volumes")
    except (OSError, ValueError, KeyError, MigrationError) as error:
        raise MigrationError("Legacy cleanup failed: " + str(error)) from None
    finally:
        original_failure = sys.exc_info()[0] is not None
        try:
            if helper:
                try:
                    # Stop deletion before releasing exclusion. A survivor's own
                    # lease continues to refuse conflicting restore operations.
                    docker("rm", "-f", helper, step="Stop owned legacy cleanup helper")
                except MigrationError:
                    message = f"Legacy cleanup helper could not be stopped; unresolved owned helper: {helper}"
                    customer(message, level=40, file=sys.stderr, flush=True)
                    if not original_failure:
                        raise MigrationError(message) from None
        finally:
            try:
                if process is not None and process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=10)
            finally:
                if observation is not None:
                    observation.finish(process.returncode if process is not None else None,
                                       "cleanup failed or interrupted" if original_failure else None)
                if process is not None:
                    for stream in (process.stdin, process.stdout, process.stderr):
                        if stream is not None:
                            stream.close()
                customer("Retry legacy cleanup: " + cleanup_command(), flush=True)
    customer(
        "Legacy database cleanup complete; volume identities, restored data and completion retained.",
        flush=True,
    )


def cleanup_legacy_volumes() -> int:
    """Discover the sole local installation and dispatch without restore preflight."""
    project: Optional[str] = None
    dispatched = False
    try:
        try:
            project, services = discover(None)
        except MigrationError as error:
            if str(error).startswith("Ambiguous installation;"):
                raise MigrationError(
                    "Multiple installations are unsupported in cleanup-only mode; exactly one labeled installation is required"
                ) from None
            raise
        if sys.version_info < (3, 6) or sys.prefix != sys.base_prefix:
            raise MigrationError("Use system Python 3.6 or newer (base interpreter)")
        daemon = docker(
            "info", "--format", "{{.ID}}", step="Legacy cleanup Docker access"
        )
        endpoint = os.environ.get("DOCKER_HOST", "")
        if os.environ.get("DOCKER_CONTEXT") or not endpoint:
            context = docker("context", "show", step="Docker context")
            endpoint = docker(
                "context",
                "inspect",
                context,
                "--format",
                "{{.Endpoints.docker.Host}}",
                step="Docker endpoint",
            )
        if not endpoint.startswith("unix://"):
            raise MigrationError("Legacy cleanup requires a local Docker Unix socket")
        from restoration import restore_lock

        with restore_lock(daemon, project):
            dispatched = True
            cleanup_installation(daemon, project, services)
        return 0
    except (MigrationError, OSError, ValueError, KeyError, IndexError) as error:
        customer(f"Legacy cleanup failed: {error}", level=40, file=sys.stderr)
        return 1
    finally:
        if not dispatched:
            report_targets(project)
            customer("Retry legacy cleanup: " + cleanup_command(), flush=True)


def main() -> int:
    """Internal container entrypoint; the operator uses restore-databases-after-upgrade.sh."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mounted", action="store_true", required=True)
    parser.add_argument("--state", required=True)
    parser.add_argument("--volumes", required=True)
    parser.add_argument("--project", required=True)
    parser.add_argument("--daemon", required=True)
    parser.add_argument("--lease", required=True)
    return mounted_cleanup(parser.parse_args())


if __name__ == "__main__":
    raise SystemExit(main())
