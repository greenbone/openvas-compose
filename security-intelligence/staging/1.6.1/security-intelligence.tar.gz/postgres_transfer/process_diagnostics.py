"""Bounded concurrent diagnostic collection, separate from functional streams."""
import os
import fcntl
import re
import select
import shlex
import subprocess
import threading
import time
from contextlib import contextmanager

import diagnostics
from diagnostics import redact as safe_text

HEAD = 64 * 1024
TAIL = 256 * 1024
RESPONSE_LIMIT = 64 * 1024 * 1024
# SQL errors can echo arbitrary row values and SQL literals. Preserve useful,
# fixed categories rather than retaining their data-bearing lines.
FAILURE_CATEGORIES = (
    b'permission denied', b'authentication failed', b'could not connect',
    b'connection refused', b'connection to server', b'unsupported version',
    b'invalid archive', b'input file does not appear to be a valid archive',
    b'duplicate key', b'violates foreign key constraint', b'no space left',
    b'unexpected end of file', b'could not read from input file',
    b'input file appears to be a text format dump',
    b'did not find magic string in file header', b'could not execute query',
    b'invalid input syntax', b'violates not-null constraint',
    b'value too long', b'division by zero', b'syntax error',
    b'input file is too short',
    b'oci runtime exec failed', b'executable file not found',
    b'no such container', b'no such file or directory', b'not found',
    b'cannot execute', b'cannot create', b'cannot open', b'could not open',
    b'file exists', b'is a directory', b'read-only file system',
    b'broken pipe', b'operation not permitted', b'input/output error',
    b'bad decrypt', b'error reading input file', b'error writing output file',
    b'wrong final block length', b'error reading password',
)

# Only fixed diagnostic meaning is retained; object names, values and any
# adjoining warning text are still omitted. Exit status never makes them safe.
WARNING_CATEGORIES = (
    b'no privileges could be revoked', b'no privileges were granted',
    b'there is no transaction in progress',
    b'there is already a transaction in progress',
    b'errors ignored on restore', b'deprecated key derivation used',
    b'using -iter or -pbkdf2 would be better',
)

# Only the absolute leading header of a known psql stderr stream is framed
# safely. A primary message can contain newlines and forged header/code text;
# neither its body nor later lines can be distinguished from customer data.
SQLSTATE_PATTERN = re.compile(
    rb'\A(?:ERROR|FATAL|PANIC|WARNING|NOTICE):[ \t]+([0-9A-Z]{5}):')
PSQL_HEADER_LIMIT = 64


def command_text(args):
    values = [str(value) for value in args]
    if any('psql ' in value for value in values):
        for index, value in enumerate(values):
            if 'psql ' in value:
                values[index:] = ['[SQL command arguments omitted]']
                break
    # SQL and shell programs can embed data literals or secret assignments.
    for index, value in enumerate(values):
        if index and (values[index - 1] in ('-c', '-ceu', '-ce', '-ec', '-pass') or re.search(r'(?i)^--[\w-]*(?:password|passphrase|secret|token|credential|api.key|private.key)[\w-]*$', values[index - 1])):
            values[index] = '[REDACTED argument]'
    return safe_text(' '.join(shlex.quote(value) for value in values))


class Capture:
    """Drain bounded streams; emit only fixed diagnostic categories and codes.

    Retention bounds and functional response limits remain independent. Raw
    diagnostic bytes never reach a destination, even on successful exit.
    """
    def __init__(self, kind='diagnostic', response_limit=0):
        self.kind = kind
        self.head = bytearray()
        self.tail = bytearray()
        self.total = 0
        self.response = bytearray()
        self.response_limit = response_limit
        self.failed = False
        self.codes = set()
        self.categories = set()
        self.warnings = set()
        self.overlap = b''
        self.psql_header = b''
        self.psql_header_finished = False

    def add(self, chunk):
        self.total += len(chunk)
        if self.response_limit and len(self.response) < self.response_limit:
            self.response.extend(chunk[:self.response_limit - len(self.response)])
        if self.kind in ('sql', 'psql', 'diagnostic'):
            diagnostic_chunk = self.overlap + chunk
            lowered = diagnostic_chunk.lower()
            for category in FAILURE_CATEGORIES:
                if category in lowered:
                    self.categories.add(category)
            for category in WARNING_CATEGORIES:
                if category in lowered:
                    self.warnings.add(category)
            self.overlap = diagnostic_chunk[-128:]
            if self.kind == 'psql' and not self.psql_header_finished:
                # Retain at most a short prefix, never a rolling tail or a
                # continuation line. Fragmentation cannot create a new start.
                first_line = chunk.split(b'\n', 1)[0]
                self.psql_header += first_line[:PSQL_HEADER_LIMIT - len(self.psql_header)]
                match = SQLSTATE_PATTERN.match(self.psql_header)
                if match is not None:
                    self.codes.add(match.group(1))
                if match is not None or b'\n' in chunk or len(self.psql_header) == PSQL_HEADER_LIMIT:
                    self.psql_header_finished = True
                    self.psql_header = b''
        if self.kind in ('secret', 'payload', 'sql', 'psql'):
            return
        remaining = HEAD - len(self.head)
        self.head.extend(chunk[:remaining])
        chunk = chunk[remaining:]
        if chunk:
            self.tail.extend(chunk)
            if len(self.tail) > TAIL:
                del self.tail[:-TAIL]

    def report(self, label, stream, successful=False):
        diagnostics.technical('{} {} omitted: {} stream; bytes={}; reason=unclassified or data-bearing diagnostic text'.format(label, stream, self.kind, self.total))
        if self.categories:
            diagnostics.technical('{} {} {} categories={}'.format(label, stream, 'diagnostic' if successful else 'failure', ', '.join(sorted(category.decode('ascii') for category in self.categories))))
        if self.warnings:
            diagnostics.technical('{} {} warning categories={}'.format(label, stream, ', '.join(sorted(category.decode('ascii') for category in self.warnings))), level=30)
        if self.codes:
            diagnostics.technical('{} {} SQLSTATE={}'.format(label, stream, ','.join(sorted(code.decode('ascii') for code in self.codes))))
        if self.kind == 'diagnostic':
            omitted = max(0, self.total - len(self.head) - len(self.tail))
            if omitted:
                diagnostics.technical('{} {} omitted bytes={}; diagnostic retention truncated; boundary fragments omitted'.format(label, stream, omitted))
        if self.failed:
            diagnostics.technical('{} {} diagnostic read failed; capture incomplete'.format(label, stream))


class ProcessRecord:
    """Observe a process without taking ownership of its functional pipes."""
    def __init__(self, args, label, stdout='payload', stderr='diagnostic'):
        self.label = label
        self.started = time.monotonic()
        self.kinds = {'stdout': stdout, 'stderr': stderr}
        self.captures = {}
        self.readers = []
        self.stopped = threading.Event()
        self.finished = False
        self.stop_deadline = None
        diagnostics.technical('Command {}: {}'.format(label, command_text(args)))

    def watch(self, stream, pipe, response_limit=0):
        capture = Capture(self.kinds[stream], response_limit)
        self.captures[stream] = capture

        def drain():
            try:
                while True:
                    if self.stop_deadline is not None and time.monotonic() >= self.stop_deadline:
                        capture.failed = True
                        break
                    ready = select.select([pipe], [], [], 0.1)[0]
                    if not ready:
                        if self.stopped.is_set():
                            break
                        continue
                    chunk = os.read(pipe.fileno(), 65536)
                    if not chunk:
                        break
                    capture.add(chunk)
            except (OSError, ValueError):
                capture.failed = True
        reader = threading.Thread(target=drain, name='postgres-diagnostic-' + stream)
        reader.start()
        self.readers.append(reader)
        return capture

    def finish(self, returncode=None, outcome=None):
        if self.finished:
            return
        self.finished = True
        self.stop_deadline = time.monotonic() + 1
        self.stopped.set()
        for reader in self.readers:
            reader.join()
        for name, capture in self.captures.items():
            if capture.failed:
                diagnostics.technical('{} {} diagnostic read failed; capture incomplete'.format(self.label, name), level=30)
                diagnostics.incomplete('Diagnostic read failed')
        diagnostics.technical('Command {}: exit={}; outcome={}; duration seconds={:.3f}'.format(
            self.label, returncode, outcome or ('success' if returncode == 0 else 'failure'), time.monotonic() - self.started))
        if returncode != 0 or outcome:
            for name in ('stdout', 'stderr'):
                capture = self.captures.get(name)
                if capture is not None:
                    capture.report(self.label, name)
                elif self.kinds[name] in ('secret', 'payload', 'sql', 'psql'):
                    diagnostics.technical('{} {} omitted: {} stream; bytes=unavailable; reason=caller-owned functional stream'.format(self.label, name, self.kinds[name]))
        else:
            # Successful stdout is functional/routine output. Short-lived
            # clients can still emit useful warnings, or private text, on stderr.
            capture = self.captures.get('stderr')
            if capture is not None and capture.total and capture.kind in ('diagnostic', 'sql', 'psql'):
                capture.report(self.label, 'stderr', successful=True)


def failure_outcome(error, process):
    """Describe what interrupted an owned child, preserving already-exited work."""
    if process is None:
        return 'launch failure'
    if process.poll() is not None:
        return None
    if isinstance(error, subprocess.TimeoutExpired):
        return 'timeout'
    if isinstance(error, (KeyboardInterrupt, SystemExit)) or getattr(error, 'command_outcome', None) == 'cancellation':
        return 'cancellation'
    return 'interrupted'


@contextmanager
def observed_process(args, label, stdout_kind='payload', stderr_kind='diagnostic', **options):
    """Launch and reap owned work, draining only diagnostic pipes continuously.

    Payload stdout remains caller-owned. stderr DEVNULL is replaced by a bounded
    reader; diagnostic stdout DEVNULL is likewise captured. Never compete with
    communicate() for watched streams.
    """
    record = ProcessRecord(args, label, stdout_kind, stderr_kind)
    process = None
    try:
        options['stderr'] = subprocess.PIPE
        watch_stdout = stdout_kind == 'diagnostic' and options.get('stdout') == subprocess.DEVNULL
        if watch_stdout:
            options['stdout'] = subprocess.PIPE
        process = subprocess.Popen(args, **options)
        record.watch('stderr', process.stderr)
        if watch_stdout:
            record.watch('stdout', process.stdout)
        yield process
    except BaseException as error:
        outcome = failure_outcome(error, process)
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()
        elif process is not None:
            outcome = None
            diagnostics.technical('Command {}: enclosing operation failed after this command exited'.format(label))
        record.finish(process.returncode if process else None, outcome)
        raise
    finally:
        if process is not None:
            if process.poll() is None:
                process.kill()
            process.wait()
        record.finish(process.returncode if process else None)
        if process is not None:
            for pipe in (process.stdin, process.stdout, process.stderr):
                if pipe is not None:
                    pipe.close()


def run_command(args, label, data=None, timeout=60, env=None, stdout_kind='diagnostic',
                stderr_kind='diagnostic', response_limit=RESPONSE_LIMIT, opener=None, stdout_target=subprocess.PIPE):
    """Return bounded functional stdout, separately retaining failure diagnostics."""
    record = ProcessRecord(args, label, stdout_kind, stderr_kind)
    process = None
    writer = None
    context = None
    cancelled = threading.Event()
    try:
        options = dict(stdin=subprocess.PIPE if data is not None else None,
                       stdout=stdout_target, stderr=subprocess.PIPE, env=env)
        if opener is None:
            process = subprocess.Popen(args, **options)
        else:
            context = opener(**options)
            process = context.__enter__()
        output = record.watch('stdout', process.stdout, response_limit) if stdout_target == subprocess.PIPE else None
        record.watch('stderr', process.stderr)
        if data is not None:
            payload = data.encode('utf-8') if isinstance(data, str) else data
            descriptor = process.stdin.fileno()
            fcntl.fcntl(descriptor, fcntl.F_SETFL, fcntl.fcntl(descriptor, fcntl.F_GETFL) | os.O_NONBLOCK)
            def feed():
                offset = 0
                try:
                    while offset < len(payload) and not cancelled.is_set():
                        if not select.select([], [descriptor], [], 0.1)[1]:
                            continue
                        try:
                            offset += os.write(descriptor, payload[offset:offset + 65536])
                        except BlockingIOError:
                            continue
                except (BrokenPipeError, OSError):
                    pass
                finally:
                    process.stdin.close()
            writer = threading.Thread(target=feed, name='postgres-command-input')
            writer.start()
        process.wait(timeout=timeout)
        record.finish(process.returncode)
        if process.returncode == 0 and output is not None and output.failed:
            raise ValueError("Command response incomplete")
        if process.returncode == 0 and output is not None and output.total > response_limit:
            diagnostics.technical('{} functional response exceeded {} byte limit'.format(label, response_limit))
            raise ValueError('Command response exceeds supported {} byte limit'.format(response_limit))
        return subprocess.CompletedProcess(args, process.returncode, bytes(output.response) if output is not None else None, b'')
    except BaseException as error:
        outcome = failure_outcome(error, process)
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()
        record.finish(process.returncode if process else None, outcome)
        raise
    finally:
        cancelled.set()
        if writer is not None:
            writer.join()
        if context is not None:
            context.__exit__(None, None, None)
        elif process is not None:
            for pipe in (process.stdin, process.stdout, process.stderr):
                if pipe is not None:
                    pipe.close()
