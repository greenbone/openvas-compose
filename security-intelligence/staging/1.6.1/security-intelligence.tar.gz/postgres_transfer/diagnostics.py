"""Private diagnostic records and explicit customer-message routing.

File failures are observational: they must never interrupt migration recovery.
"""
import logging
import errno
import os
import re
from pathlib import Path
import sys
import threading
import time
import uuid
from datetime import datetime


class LogSetupError(Exception):
    """The diagnostic destination cannot be safely established."""


_lock = threading.RLock()
_logger = logging.getLogger('postgres-transfer')
_logger.setLevel(logging.DEBUG)
_logger.propagate = False
_handler = None
_failed = False
_incomplete = False
path = None
_journal = None
_journal_failed = False


def redact(value):
    """Filter credential patterns without matching actual secret values."""
    text = str(value)
    text = re.sub(r'(?i)(\b[a-z][a-z0-9+.-]{0,32}://[^\s:/]+:)[^\s@]+@', r'\1[REDACTED]@', text)
    return re.sub(r'''(?ix)((?:\b[\w.-]{0,128}(?:password|passphrase|secret|token|credential|encryption.key|api.key|private.key)[\w.-]{0,128})\s*[=:]\s*)(?:"[^"\n]*"|'[^'\n]*'|[^\s;,]+)''', r'\1[REDACTED]', text)


def incomplete(reason):
    """Warn once when diagnostics become incomplete without changing the result."""
    global _incomplete
    with _lock:
        if _incomplete:
            return
        _incomplete = True
        message = reason + '; diagnostics are incomplete.'
        technical(message, logging.WARNING)
        try:
            print('WARNING: ' + message, file=sys.stderr, flush=True)
        except OSError:
            pass


class _PrivateHandler(logging.StreamHandler):
    def handleError(self, record):
        global _failed
        _failed = True
        incomplete('Diagnostic logging failed')


def technical(message, level=logging.DEBUG, flush=True):
    with _lock:
        if _handler is not None and not _failed:
            _logger.log(level, redact(message))
        if _journal is not None and not _journal_failed:
            try:
                _journal.emit(redact(message), level)
            except OSError:
                journal_failure()


def failure(error, context):
    """Record exception identities and locations without payloads or source text.

    Callers supply an authored operation label; exception messages, arguments,
    locals and source lines are never formatted, including for chained errors.
    """
    seen = set()
    current = error
    for chain in range(16):
        if current is None or id(current) in seen:
            break
        seen.add(id(current))
        technical('Python failure: {}; exception={}; chain={}'.format(
            context, type(current).__name__, chain), logging.ERROR)
        if isinstance(current, OSError) and isinstance(current.errno, int):
            technical('Filesystem failure: errno={}; category={}'.format(
                current.errno, errno.errorcode.get(current.errno, 'unknown')), logging.ERROR)
        trace = current.__traceback__
        frames = 0
        while trace is not None and frames < 100:
            code = trace.tb_frame.f_code
            technical('Python location: module={}; function={}; line={}'.format(
                code.co_filename, code.co_name, trace.tb_lineno), logging.ERROR)
            trace = trace.tb_next
            frames += 1
        if trace is not None:
            technical('Python locations omitted: frame limit reached', logging.ERROR)
        current = current.__cause__ or current.__context__
    if current is not None:
        technical('Python exception chain omitted: repeated or bounded context', logging.ERROR)


def journal_failure():
    """Disable only the journal destination and report its first failure."""
    global _journal_failed
    if _journal_failed:
        return
    _journal_failed = True
    message = 'Journal logging unavailable or failed; journal diagnostics are incomplete.'
    technical(message, logging.WARNING)
    try:
        print('WARNING: ' + message, file=sys.stderr, flush=True)
    except OSError:
        pass


def customer(message='', level=logging.INFO, file=None, flush=True, sep=' ', end='\n'):
    """Emit the same safe content to the terminal and diagnostic file."""
    safe = redact(message)
    technical(safe, level)
    print(safe, file=file, flush=flush, end=end)


def prompt(message):
    """Record prompt text; the input/getpass caller owns terminal presentation."""
    technical(message, logging.INFO)


def setup(operation, backup=None, explicit=None, journal=False):
    """Exclusively create a private destination outside resolved backup paths."""
    global _handler, _failed, _incomplete, path, _journal, _journal_failed
    with _lock:
        run_id = uuid.uuid4().hex
        # Cleanup retains the restore wrapper's documented default filename.
        filename_operation = 'restore' if operation == 'cleanup' else operation
        try:
            candidate = Path(explicit) if explicit is not None else Path.cwd() / (
                '{}-postgres-{}-{}.log'.format(filename_operation, datetime.utcnow().strftime('%Y%m%dT%H%M%S'), run_id))
            candidate = candidate.absolute()
            resolved = candidate.resolve()
            target = Path(backup).resolve() if backup is not None else None
        except (OSError, RuntimeError):
            raise LogSetupError(
                'Cannot determine the current directory or resolve the diagnostic/backup path; '
                'run from an existing directory or choose --log-file /absolute/path'
            ) from None
        if target is not None:
            if resolved == target or target in resolved.parents:
                raise LogSetupError('Diagnostic log must be outside the backup directory; choose another --log-file PATH')
        descriptor = None
        try:
            descriptor = os.open(str(candidate), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.fchmod(descriptor, 0o600)
            stream = os.fdopen(descriptor, 'w', encoding='utf-8')
            descriptor = None
        except OSError:
            if descriptor is not None:
                os.close(descriptor)
            raise LogSetupError('Cannot create diagnostic log {} (it must not exist); choose a new writable --log-file PATH'.format(candidate)) from None
        _failed = False
        _incomplete = False
        path = resolved
        _handler = _PrivateHandler(stream)
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s',
                                      datefmt='%Y-%m-%dT%H:%M:%SZ')
        formatter.converter = time.gmtime
        _handler.setFormatter(formatter)
        _logger.addHandler(_handler)
        identity = 'Invocation: {}; operation: {}'.format(run_id, operation)
        technical(identity, logging.INFO)
        if _failed:
            close()
            raise LogSetupError('Cannot write diagnostic log; choose a writable --log-file PATH')
        _journal_failed = False
        if journal:
            from journal import Journal
            try:
                _journal = Journal(run_id, operation)
                _journal.emit(identity, logging.INFO)
            except OSError:
                journal_failure()
        customer('Diagnostic log: {}'.format(path))
        if _failed:
            close()
            raise LogSetupError('Cannot write diagnostic log; choose a writable --log-file PATH')
        return path


def close():
    global _handler, path, _journal
    with _lock:
        if _handler is not None:
            _logger.removeHandler(_handler)
            try:
                _handler.stream.close()
            except OSError:
                _handler.handleError(None)
            _handler = None
        if _journal is not None:
            try:
                _journal.close()
            except OSError:
                journal_failure()
            finally:
                _journal = None
        path = None
