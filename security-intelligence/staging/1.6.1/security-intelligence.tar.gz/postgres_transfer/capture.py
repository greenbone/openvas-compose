"""Point-in-time encrypted capture. Only encrypted backup data reaches disk."""

import fcntl
import hashlib
import json
import os
import re
import selectors
import signal
import subprocess
import threading
import time
import uuid
from datetime import datetime, timezone
from contextlib import ExitStack, contextmanager
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple

from main import (
    SECRETS,
    SOURCES,
    WRITERS,
    MigrationError,
    MigrationCancelled,
    check_storage_capacity,
    discover,
    docker,
    read_secret,
    secret_provider,
    sql,
)
from passphrase import Passphrase, openssl_process, openssl_run
from diagnostics import customer, technical, failure
from process_diagnostics import observed_process, run_command

WARNING = (
    "This backup captures the database state while services are stopped. "
    "Writers and ingress remain stopped after a successful dump. "
    "Any changes made after capture "
    "are not included in this backup and will be lost when you migrate using it."
)
HEADER = "service\tdatabase\tfile\tbytes\tsha256\tpostgres_version\tformat\tcipher\tkdf\titerations\tdigest"
ENCRYPTION = ["-aes-256-cbc", "-pbkdf2", "-iter", "600000", "-md", "sha256", "-salt"]


# Timing boundary: production uses 30 seconds; controlled command drivers can
# inject shorter waits without replacing clocks or changing cleanup deadlines.
PROGRESS_INTERVAL = 30

_WORK_ID: Optional[str] = None
_WORK_OPERATION = "dump"
_RECOVERING = False
_CANCELLED = False


def format_duration(seconds: float) -> str:
    """Format elapsed time in whole seconds for operator-facing output."""
    total = int(seconds)
    hours, remainder = divmod(total, 3600)
    minutes, seconds_part = divmod(remainder, 60)
    if hours:
        return f"{hours}h {minutes:02d}m {seconds_part:02d}s"
    if minutes:
        return f"{minutes}m {seconds_part:02d}s"
    return f"{seconds_part}s"


@contextmanager
def work_identity(operation: str, work_id: str) -> Iterator[None]:
    """Attribute external work for one installation operation and its recovery."""
    global _WORK_ID, _WORK_OPERATION
    previous = _WORK_ID, _WORK_OPERATION
    _WORK_ID, _WORK_OPERATION = work_id, operation
    technical("Recovery attribution: operation={}; recovery_id={}; application_name={}".format(
        operation, work_id, application_name()))
    try:
        yield
    finally:
        _WORK_ID, _WORK_OPERATION = previous


def dump_control_identity(daemon: str, project: str) -> str:
    """Bind pre-journal helpers to one daemon/project dump operation, never restore."""
    return hashlib.sha256(
        json.dumps(["dump-control", daemon, project], separators=(",", ":")).encode()
    ).hexdigest()[:32]


def work_environment() -> Dict[str, str]:
    """Mark owned processes without changing the parent command's environment."""
    environment = dict(os.environ)
    if _WORK_ID is not None:
        environment[
            "OSI_DUMP_CAPTURE_ID" if _WORK_OPERATION == "dump" else "OSI_RESTORE_ID"
        ] = _WORK_ID
    return environment


def application_name() -> str:
    """Identify dump attempts or the stable installation restore operation."""
    return "osi-migration-" + _WORK_OPERATION + "-" + (_WORK_ID or "unbound")


def reconcile_work(
    services: Dict[str, Any],
    capture_id: str,
    operation: str = "dump",
    *,
    state_only: bool = False,
) -> None:
    """Stop tagged host/container work and database clients before source recovery."""
    if len(capture_id) != 32 or any(c not in "0123456789abcdef" for c in capture_id):
        raise MigrationError("Invalid interrupted dump identity; recovery refused")
    marker_name = "OSI_DUMP_CAPTURE_ID" if operation == "dump" else "OSI_RESTORE_ID"
    marker = f"{marker_name}={capture_id}".encode()
    def exited(pid: int) -> bool:
        # A killed orphan may remain as a zombie until its reaper runs. Linux can
        # deny environ access for that zombie; it can no longer publish or write.
        deadline = time.monotonic() + 1
        while True:
            try:
                status = (Path("/proc") / str(pid) / "stat").read_text()
                if status.rsplit(")", 1)[1].split()[0] == "Z":
                    return True
            except (FileNotFoundError, ProcessLookupError):
                return True
            if time.monotonic() >= deadline:
                return False
            time.sleep(.01)

    processes = []
    for entry in Path("/proc").glob("[0-9]*/environ"):
        try:
            owned = marker in entry.read_bytes().split(b"\0")
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        pid = int(entry.parent.name)
        if not owned or pid == os.getpid():
            continue
        try:
            if entry.stat().st_uid != os.getuid():
                raise MigrationError("Interrupted migration process has unexpected ownership")
            processes.append(pid)
            os.kill(pid, signal.SIGTERM)
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            if not exited(pid):
                raise MigrationError("Cannot stop attributed migration process; recovery refused") from None
    for pid in processes:
        try:
            path = Path("/proc") / str(pid) / "environ"
            if marker in path.read_bytes().split(b"\0"):
                os.kill(pid, signal.SIGKILL)
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            if not exited(pid):
                raise MigrationError("Cannot stop attributed migration process; recovery refused") from None
    # Client processes and state helpers can outlive docker exec/run and the
    # command lock. Restore uses a stable installation identity, not its journal.
    helper_ids = docker(
        "ps",
        "-aq",
        "--filter",
        f"label=net.greenbone.migration-work={capture_id}",
        step="Discover surviving capture state helpers",
    ).splitlines()
    if helper_ids:
        try:
            docker("rm", "-f", *helper_ids, step="Stop surviving migration state helpers")
        except MigrationError:
            # --rm helpers can disappear between discovery and removal. The
            # bounded absence check, rather than the Docker response, proves stop.
            pass
        deadline = time.monotonic() + 10
        while docker(
            "ps", "-aq", "--filter",
            f"label=net.greenbone.migration-work={capture_id}",
            step="Verify migration state helpers stopped",
        ).splitlines():
            if time.monotonic() >= deadline:
                raise MigrationError("Surviving migration state helpers remain; recovery refused")
            time.sleep(.05)
    appname = "osi-migration-" + operation + "-" + capture_id
    script = r"""set -eu
marker="PGAPPNAME=$1"
owned_clients() {
    for entry in /proc/[0-9]*/environ; do
        test -r "$entry" || continue
        if tr '\000' '\n' < "$entry" 2>/dev/null | grep -Fxq "$marker"; then
            process=${entry%/environ}; process=${process##*/}
            printf '%s\n' "$process"
        fi
    done
}
for process in $(owned_clients); do kill -TERM "$process" 2>/dev/null || true; done
# A blocked FIFO shell or a client ignoring TERM must not outlive replacement.
for process in $(owned_clients); do kill -KILL "$process" 2>/dev/null || true; done
attempt=0
while test -n "$(owned_clients)"; do
    attempt=$((attempt + 1))
    test "$attempt" -lt 50 || exit 1
    sleep .1
done
"""
    # Dump keeps its small recovery journal. Restore can reconcile every client
    # with only installation identity, including before any journal publication.
    databases = (
        {}
        if state_only
        else (SOURCES if operation == "dump" else {"osi-postgres": "postgres"})
    )
    database_filter = "datname=current_database() AND " if operation == "dump" else ""
    for service, database in databases.items():
        docker(
            "exec",
            "--user",
            "0",
            services[service]["Id"],
            "sh",
            "-ceu",
            script,
            "reconcile",
            appname,
            step=f"Reconcile surviving capture clients {database}",
        )
        sql(
            services[service],
            database,
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE "
            + database_filter
            + f"application_name='{appname}' AND pid<>pg_backend_pid()",
        )
        deadline = time.monotonic() + 10
        while int(sql(
            services[service], database,
            "SELECT count(*) FROM pg_stat_activity WHERE " + database_filter
            + f"application_name='{appname}' AND pid<>pg_backend_pid()",
        )):
            if time.monotonic() >= deadline:
                raise MigrationError(f"Surviving database work remains: {database}")
            time.sleep(.05)
        if operation == "restore":
            docker(
                "exec",
                services[service]["Id"],
                "rm",
                "-f",
                f"/tmp/osi-restore-{capture_id}.list",
                step="Remove interrupted restore object-list FIFO",
            )
    limit = time.monotonic() + 10
    while True:
        alive = False
        for pid in processes:
            try:
                if marker in (Path("/proc") / str(pid) / "environ").read_bytes().split(
                    b"\0"
                ):
                    alive = True
            except (FileNotFoundError, ProcessLookupError):
                continue
            except PermissionError:
                if not exited(pid):
                    raise MigrationError("Cannot verify attributed migration process stopped") from None
        if not alive:
            break
        if time.monotonic() >= limit:
            raise MigrationError(
                "Surviving host migration work could not be stopped; retry recovery"
            )
        time.sleep(0.05)


def recover_journal(
    state: "StateVolume", services: Dict[str, Any], installation: str, project: str
) -> None:
    """Recover an unfinished attempt under the kernel installation lock."""
    global _WORK_ID
    journal = state.read("dump-journal.json")
    if journal is None:
        return
    if (
        type(journal.get("schema")) is not int
        or journal.get("schema") != 1
        or journal.get("installation") != installation
        or journal.get("project") != project
        or journal.get("operation") != "dump"
        or not isinstance(journal.get("originally_running"), list)
        or any(
            name not in ["ingress", *WRITERS] for name in journal["originally_running"]
        )
    ):
        raise MigrationError("Invalid interrupted dump journal; recovery refused")
    capture_id = journal.get("capture_id")
    if not isinstance(capture_id, str):
        raise MigrationError(
            "Interrupted dump lacks a work identity; manual reconciliation required"
        )
    _WORK_ID = capture_id
    customer(
        "Interrupted dump detected; reconciling surviving work before source recovery.",
        level=30,
        flush=True,
    )
    technical("Interrupted dump recovery intent: recovery_id={}; application_name={}".format(
        capture_id, application_name()))
    try:
        with phase("reconcile interrupted dump work"):
            reconcile_work(services, capture_id)
        stopped_observed = True
        with phase("recover recorded original source services; ingress last"):
            for name in ["ingress", *WRITERS]:
                if name not in journal["originally_running"] and (
                    services[name]["State"]["Running"]
                    or services[name]["State"].get("Restarting")
                ):
                    stopped_observed = False
                    docker(
                        "stop",
                        services[name]["Id"],
                        step=f"Recover initially stopped {name}",
                    )
            restart(services, journal["originally_running"])
        technical("Dump intent: remove source recovery journal")
        state.remove("dump-journal.json")
        technical("Dump observation: source recovery journal removal helper completed")
    except BaseException as recovery_error:
        failure(recovery_error, "interrupted dump recovery failure")
        technical("Interrupted dump recovery outcome: failed; recovery=unknown", level=40)
        raise
    technical("Interrupted dump recovery outcome: recovery={}; originally running services readiness confirmed".format(
        "confirmed" if stopped_observed else "unknown"))
    customer(
        "Interrupted dump recovered. Existing artifacts retained; retry captures from scratch in an empty output directory.",
        flush=True,
    )


@contextmanager
def recovery_protection() -> Iterator[None]:
    """Complete recorded source recovery before honoring a new cancellation."""
    global _RECOVERING
    _RECOVERING = True
    try:
        yield
    finally:
        _RECOVERING = False


@contextmanager
def interruption_signals() -> Iterator[None]:
    """Convert termination into recoverable failure and protect cleanup from repeats."""
    global _CANCELLED
    _CANCELLED = False
    interrupted = False
    deferred = 0

    def interrupt(number: int, frame: Any) -> None:
        global _CANCELLED
        nonlocal interrupted, deferred
        _CANCELLED = True
        if interrupted or _RECOVERING:
            deferred += 1
            return
        interrupted = True
        raise MigrationCancelled(
            f"Dump interrupted by signal {number}; recovering original source services"
        )

    previous = {
        number: signal.getsignal(number) for number in (signal.SIGINT, signal.SIGTERM)
    }
    for number in previous:
        signal.signal(number, interrupt)
    try:
        yield
    finally:
        for number, handler in previous.items():
            signal.signal(number, handler)
        if deferred:
            customer(
                f"Source recovery deferred {deferred} repeated interrupt(s).",
                level=30,
                flush=True,
            )


@contextmanager
def phase(name: str, customer_name: Optional[str] = None, quiet: bool = False) -> Iterator[None]:
    """Report elapsed progress without rescanning data or timing pipeline stages."""
    visible = customer_name or name
    started = time.monotonic()
    technical(f"Phase: {name}")
    if quiet:
        try:
            yield
        except BaseException:
            technical(f"FAILED phase: {name}", level=40)
            raise
        else:
            technical(f"Phase complete: {name}; elapsed seconds={time.monotonic()-started:.3f}")
        return
    customer(f"Phase: {visible}", flush=True)
    finished = threading.Event()

    def heartbeat() -> None:
        while not finished.wait(PROGRESS_INTERVAL):
            try:
                customer(
                    f"Phase still running: {visible}; elapsed seconds={time.monotonic()-started:.3f}",
                    flush=True,
                )
            except OSError:
                # Progress output cannot replace an operation's error or prevent
                # cleanup when the operator's output stream has closed.
                return

    worker = threading.Thread(target=heartbeat, name="migration-phase-progress")
    worker.start()
    try:
        try:
            yield
        finally:
            # Wake immediately and join before the terminal label, including
            # cancellation/failure. No worker outlives this synchronous phase.
            finished.set()
            worker.join()
    except BaseException:
        technical(f"FAILED phase: {name}; elapsed seconds={time.monotonic()-started:.3f}", level=40)
        customer(f"FAILED phase: {visible}", level=40)
        raise
    else:
        technical(f"Phase complete: {name}; elapsed seconds={time.monotonic()-started:.3f}")
        customer(f"Phase complete: {visible}")


def checksum(path: Path) -> str:
    """Hash an encrypted artifact in bounded chunks."""
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while True:
            data = stream.read(1024 * 1024)
            if not data:
                break
            digest.update(data)
    return digest.hexdigest()


def durable(path: Path, data: bytes) -> None:
    """Publish a small record atomically after syncing file and directory."""
    temporary = path.with_name(path.name + ".partial")
    with temporary.open("wb") as stream:
        os.chmod(temporary, 0o600)
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


class StateVolume:
    """Persistent installation state, readable by a guard without Docker access."""

    def __init__(
        self, project: str, services: Dict[str, Any], *, create: bool = True
    ) -> None:
        """Select installation state storage and create or inspect its named volume.

        Use under the operation's installation lock. The guard's /state mount must
        match the project-derived name; selection alone does not validate authorization
        records. Uses the deployment's PostgreSQL image.

        Args:
            project: Selected Compose installation.
            services: Discovered services supplying guard mount and PostgreSQL image.
            create: Create the named volume when True; otherwise require it to exist.

        Raises:
            MigrationError: Volume identity, topology, or Docker volume operation fails.
        """
        self.volume: str = f"{project}_postgres-migration-state"
        guard = services.get("osi-postgres-migration-guard")
        if guard is not None:
            mounts = [
                mount
                for mount in guard.get("Mounts", [])
                if mount.get("Destination") == "/state"
            ]
            if len(mounts) != 1 or mounts[0].get("Type") != "volume":
                raise MigrationError(
                    "Guard must mount one named migration state volume at /state"
                )
            if mounts[0].get("Name") != self.volume:
                raise MigrationError(
                    "Guard state volume differs from the project-derived migration state volume"
                )
        if (
            not isinstance(self.volume, str)
            or re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_.-]*", self.volume) is None
        ):
            raise MigrationError("Invalid named migration state volume")
        postgres = services.get("osi-postgres", services.get("keycloak-postgres"))
        if postgres is None:
            raise MigrationError("Missing PostgreSQL image for durable state")
        self.image: str = postgres["Config"]["Image"]
        if create:
            docker(
                "volume",
                "create",
                "--label",
                f"com.docker.compose.project={project}",
                self.volume,
                step="Create durable migration state",
            )
        else:
            docker(
                "volume",
                "inspect",
                self.volume,
                step="Read authorized migration state volume",
            )

    def write(self, name: str, value: Dict[str, Any]) -> None:
        # Atomic same-volume rename, sync before publishing. No secret payloads.
        """Atomically publish JSON after syncing its partial file and final rename.

        Args:
            name: Trusted internal record basename; this helper does not sanitize paths.
            value: Nonsecret serializable state. Caller holds the operation lock and
                supplies the attempt work identity for recovery attribution.

        Raises:
            MigrationError: The state container command exits unsuccessfully.
            OSError: The helper cannot launch.
            subprocess.TimeoutExpired: The helper exceeds 60 seconds."""
        command = (
            'umask 077; cat > "/state/$1.partial" && sync && '
            'mv "/state/$1.partial" "/state/$1" && sync'
        )
        self.command(command, name, json.dumps(value))

    def publish_dump_success(self, value: Dict[str, Any]) -> None:
        """Atomically link validated first success without replacing earlier evidence.

        A delayed helper may publish only after the artifacts have been completed.
        Unique staging and no-overwrite linking make competing helpers harmless;
        publication never accesses restoration completion.
        """
        from guard import dump_success_identity, Rejected
        try:
            expected = dump_success_identity(value, value["project"])
        except (Rejected, KeyError):
            raise MigrationError("Invalid completed dump evidence") from None
        name = "dump-ready.json"
        existing = self.read(name)
        if existing is None:
            temporary = ".dump-success-" + uuid.uuid4().hex
            command = (
                'umask 077; cat > "/state/' + temporary + '" && sync && '
                'if ! ln -T "/state/' + temporary + '" "/state/$1"; then '
                'test -e "/state/$1" || test -L "/state/$1"; fi; '
                'rm -f "/state/' + temporary + '"; sync'
            )
            self.command(command, name, json.dumps(value))
            existing = self.read(name)
        try:
            if existing is None or dump_success_identity(existing, value["project"])["installation"] != expected["installation"]:
                raise Rejected("Wrong installation")
        except Rejected:
            raise MigrationError("Invalid existing completed dump evidence") from None

    def remove(self, name: str) -> None:
        """Remove a trusted record and sync the state volume under the caller's lock.

        Args:
            name: Internal record basename. Missing records are tolerated.

        Raises:
            MigrationError: The removal helper exits unsuccessfully.
            OSError: The helper cannot launch.
            subprocess.TimeoutExpired: The helper exceeds 60 seconds."""
        self.command('rm -f "/state/$1" && sync', name)

    def read(self, name: str) -> Optional[Dict[str, Any]]:
        """Read JSON state without changing its contents or validating its contract.

        Args:
            name: Trusted internal record basename; callers validate identity and phase
                under their operation lock before acting on the returned record.

        Returns:
            A JSON object, or None only for an absent record. Empty, linked or
            oversized records fail closed.

        Raises:
            MigrationError: Duplicate fields, a non-object root, or helper exit failure.
            ValueError: Record contents are invalid JSON.
            OSError: The helper cannot launch.
            subprocess.TimeoutExpired: The helper exceeds 60 seconds."""
        output = self.command(
            'if [ -e "/state/$1" ] || [ -L "/state/$1" ]; then '
            'test ! -L "/state/$1"; test -f "/state/$1"; test -s "/state/$1"; '
            'test "$(wc -c < "/state/$1")" -lt 65536; '
            'test -n "$(tr -d \'[:space:]\' < "/state/$1")"; cat "/state/$1"; fi', name
        )
        if not output:
            return None

        def unique_fields(pairs: List[Tuple[str, Any]]) -> Dict[str, Any]:
            value = dict(pairs)
            if len(value) != len(pairs):
                raise MigrationError("Duplicate fields in durable migration record")
            return value

        value: Any = json.loads(output, object_pairs_hook=unique_fields)
        if not isinstance(value, dict):
            raise MigrationError("Invalid durable migration record")
        return value

    def command(self, command: str, name: str, data: Optional[str] = None) -> str:
        """Run a trusted shell operation in a network-isolated root state helper.

        Args:
            command: Internal shell script; may mutate the named state volume.
            name: Trusted basename passed as a positional argument, not shell code.
            data: Optional stdin payload. Current work identity attributes the helper.

        Returns:
            Stripped stdout. The caller owns locking and record-contract validation.

        Raises:
            MigrationError: The helper exits unsuccessfully.
            OSError: The helper cannot launch.
            subprocess.TimeoutExpired: The helper exceeds 60 seconds."""
        result = run_command(
            [
                "docker",
                "run",
                *(
                    ["--label", f"net.greenbone.migration-work={_WORK_ID}"]
                    if _WORK_ID
                    else []
                ),
                "--rm",
                "-i",
                "--user",
                "0",
                "--network",
                "none",
                "--entrypoint",
                "sh",
                "-v",
                f"{self.volume}:/state",
                self.image,
                "-ceu",
                command,
                "state",
                name,
            ],
            "Durable migration state " + name,
            data=data,
            stdout_kind="payload",
            env=work_environment(),
            timeout=60,
        )
        if result.returncode:
            raise MigrationError("Durable migration state update failed")
        return result.stdout.decode("utf-8").strip()


class Snapshot:
    """Keep the exporting transaction alive; metadata queries use that transaction."""

    def __init__(self, container: Any, database: str) -> None:
        """Open a read-only repeatable-read exporter and retain its snapshot token.

        Caller must close the session in a finally block and keep it alive until the
        archive using token is finished. This is one database's snapshot, not a lock
        across databases or a substitute for stopping product writers.

        Args:
            container: Running PostgreSQL container with mounted credential configuration.
            database: Database whose inventory and dump must share this snapshot.

        Raises:
            OSError: The exporter cannot launch.
            MigrationError: Snapshot export yields no response or its process fails."""
        self.database: str = database
        technical("Snapshot identity: container={}; database={}; application_name={}".format(
            container["Id"], database, application_name()))
        script = (
            'export PGPASSWORD="$(cat "$POSTGRES_PASSWORD_FILE")"; '
            f"export PGAPPNAME={application_name()}; "
            'exec psql -X -w -qAt -h 127.0.0.1 -U "$POSTGRES_USER" '
            '-d "$1" -v ON_ERROR_STOP=1 -v VERBOSITY=verbose'
        )
        self._session = observed_process(
            [
                "docker",
                "exec",
                "-i",
                "--env",
                f"PGAPPNAME={application_name()}",
                container["Id"],
                "sh",
                "-ceu",
                script,
                "snapshot",
                database,
            ],
            "Snapshot session " + database,
            stderr_kind="psql",
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            universal_newlines=True,
            encoding="utf-8",
            bufsize=1,
            env=work_environment(),
        )
        self.process = self._session.__enter__()
        try:
            self.token = self.query(
                "BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY; "
                "SET LOCAL quote_all_identifiers=on; SET LOCAL search_path=pg_catalog; "
                "SELECT pg_export_snapshot()",
                label="export snapshot",
            )
        except BaseException:
            self.close()
            raise

    def query(self, query: str, label: str = "inventory query") -> str:
        """Query the existing exporter transaction and read one nonempty output line.

        Args:
            query: Trusted SQL producing one output line; caller keeps the exporter open.

        Returns:
            Stripped response. Long queries report progress without an overall deadline.

        Raises:
            MigrationError: The exporter dies or returns no output.
            OSError: Exporter pipes cannot be written or read."""
        started = time.monotonic()
        technical("SQL operation {}: started; database={}".format(label, self.database))
        try:
            assert self.process.stdin is not None and self.process.stdout is not None
            self.process.stdin.write(query + ";\n")
            self.process.stdin.flush()
            # Exact counts may take a long time; report that work without a deadline.
            with selectors.DefaultSelector() as selector:
                selector.register(self.process.stdout, selectors.EVENT_READ)
                while not selector.select(30):
                    if self.process.poll() is not None:
                        raise MigrationError(f"Snapshot/inventory failed: {self.database}")
                    technical("Database inspection still running", flush=True)
            line = self.process.stdout.readline().strip()
            if not line:
                raise MigrationError(f"Snapshot/inventory failed: {self.database}")
            return line
        except BaseException:
            technical("SQL operation {}: failed; database={}; duration seconds={:.3f}".format(
                label, self.database, time.monotonic() - started), level=40)
            raise
        finally:
            technical("SQL operation {}: finished; database={}; duration seconds={:.3f}".format(
                label, self.database, time.monotonic() - started))

    def close(self) -> None:
        """Roll back and reap the exporter, terminating it after a 15-second wait.

        Releases the snapshot; callers must finish snapshot-dependent work first.
        Broken input pipes are tolerated and stdout closes even on a wait failure.

        Raises:
            OSError: Pipe cleanup or process termination fails.
            subprocess.TimeoutExpired: The terminated process still does not exit."""
        started = time.monotonic()
        try:
            if self.process.stdin:
                try:
                    self.process.stdin.write("ROLLBACK;\n\\q\n")
                    self.process.stdin.close()
                except BrokenPipeError:
                    pass
            try:
                self.process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self.process.terminate()
                self.process.wait(timeout=15)
        finally:
            self._session.__exit__(None, None, None)
            technical("SQL operation release snapshot: database={}; duration seconds={:.3f}".format(
                self.database, time.monotonic() - started))


def identifier(value: str) -> str:
    """Quote an SQL identifier, including embedded double quotes."""
    return '"' + value.replace('"', '""') + '"'


def inventory(snapshot: Snapshot) -> Dict[str, Any]:
    """Reflect definitions and counts without copying application row payloads."""
    query = """SELECT json_build_object(
      'inventory_version',2,
      'schemas',(SELECT coalesce(json_agg(nspname ORDER BY nspname),'[]') FROM pg_namespace WHERE nspname NOT LIKE 'pg_%' AND nspname <> 'information_schema'),
      'relations',(SELECT coalesce(json_agg(json_build_object('schema',n.nspname,'name',c.relname,'kind',c.relkind,'partition',c.relispartition,
        'row_type',(SELECT t.typname FROM pg_type t WHERE t.oid=c.reltype),'array_type',(SELECT a.typname FROM pg_type t JOIN pg_type a ON a.oid=t.typarray WHERE t.oid=c.reltype),
        'owner',pg_get_userbyid(c.relowner),'extension',(SELECT e.extname FROM pg_depend d JOIN pg_extension e ON e.oid=d.refobjid WHERE d.classid='pg_class'::regclass AND d.objid=c.oid AND d.deptype='e'),
        'index_parent',(SELECT json_build_array(pn.nspname,p.relname) FROM pg_index i JOIN pg_class p ON p.oid=i.indrelid JOIN pg_namespace pn ON pn.oid=p.relnamespace WHERE i.indexrelid=c.oid),
        'sequence_owner',(SELECT json_build_array(pn.nspname,p.relname,a.attname) FROM pg_depend d JOIN pg_class p ON p.oid=d.refobjid JOIN pg_namespace pn ON pn.oid=p.relnamespace JOIN pg_attribute a ON a.attrelid=p.oid AND a.attnum=d.refobjsubid WHERE c.relkind='S' AND d.classid='pg_class'::regclass AND d.objid=c.oid AND d.refclassid='pg_class'::regclass AND d.deptype IN ('a','i')),
        'parents',(SELECT coalesce(json_agg(json_build_array(pn.nspname,p.relname) ORDER BY pn.nspname,p.relname),'[]') FROM pg_inherits i JOIN pg_class p ON p.oid=i.inhparent JOIN pg_namespace pn ON pn.oid=p.relnamespace WHERE i.inhrelid=c.oid),
        'sequence_definition',(SELECT json_build_object('type',format_type(s.seqtypid,NULL),'start',s.seqstart,'increment',s.seqincrement,'min',s.seqmin,'max',s.seqmax,'cache',s.seqcache,'cycle',s.seqcycle) FROM pg_sequence s WHERE s.seqrelid=c.oid),
        'columns',(SELECT coalesce(json_agg(json_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'not_null',a.attnotnull,'identity',a.attidentity,'generated',a.attgenerated,'default',pg_get_expr(d.adbin,d.adrelid)) ORDER BY a.attnum),'[]') FROM pg_attribute a LEFT JOIN pg_attrdef d ON d.adrelid=a.attrelid AND d.adnum=a.attnum WHERE a.attrelid=c.oid AND a.attnum>0 AND NOT a.attisdropped),
        'constraints',(SELECT coalesce(json_agg(json_build_object('name',conname,'definition',pg_get_constraintdef(oid)) ORDER BY conname),'[]') FROM pg_constraint WHERE conrelid=c.oid),
        'indexes',(SELECT coalesce(json_agg(pg_get_indexdef(indexrelid) ORDER BY pg_get_indexdef(indexrelid)),'[]') FROM pg_index WHERE indrelid=c.oid),
        'triggers',(SELECT coalesce(json_agg(json_build_object('name',tgname,'definition',pg_get_triggerdef(oid)) ORDER BY tgname),'[]') FROM pg_trigger WHERE tgrelid=c.oid AND NOT tgisinternal),
        'view',CASE WHEN c.relkind IN ('v','m') THEN pg_get_viewdef(c.oid,true) ELSE NULL END) ORDER BY n.nspname,c.relname),'[]') FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname NOT LIKE 'pg_%' AND n.nspname <> 'information_schema' AND c.relkind IN ('r','p','S','v','m','f','i','I')),
      'functions',(SELECT coalesce(json_agg(json_build_object('schema',n.nspname,'name',p.proname,'owner',pg_get_userbyid(p.proowner),
        'extension',(SELECT e.extname FROM pg_depend d JOIN pg_extension e ON e.oid=d.refobjid WHERE d.classid='pg_proc'::regclass AND d.objid=p.oid AND d.deptype='e'),
        'arguments',(SELECT coalesce(json_agg(json_build_array(tn.nspname,t.typname) ORDER BY argument.ordinality),'[]') FROM unnest(p.proargtypes::oid[]) WITH ORDINALITY argument(oid,ordinality) JOIN pg_type t ON t.oid=argument.oid JOIN pg_namespace tn ON tn.oid=t.typnamespace),
        'identity',pg_get_function_identity_arguments(p.oid),'definition',pg_get_functiondef(p.oid)) ORDER BY n.nspname,p.proname,p.oid),'[]') FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname NOT LIKE 'pg_%' AND n.nspname <> 'information_schema' AND p.prokind IN ('f','p')),
      'types',(SELECT coalesce(json_agg(json_build_object('schema',n.nspname,'name',t.typname,'kind',t.typtype,'owner',pg_get_userbyid(t.typowner),
        'extension',(SELECT e.extname FROM pg_depend d JOIN pg_extension e ON e.oid=d.refobjid WHERE d.classid='pg_type'::regclass AND d.objid=t.oid AND d.deptype='e'),
        'array_type',(SELECT a.typname FROM pg_type a WHERE a.oid=t.typarray),
        'range',(SELECT json_build_object('subtype',format_type(r.rngsubtype,NULL),'collation',r.rngcollation::regcollation::text,'opclass',(SELECT quote_ident(n.nspname)||'.'||quote_ident(o.opcname) FROM pg_opclass o JOIN pg_namespace n ON n.oid=o.opcnamespace WHERE o.oid=r.rngsubopc),'canonical',r.rngcanonical::regproc::text,'subdiff',r.rngsubdiff::regproc::text) FROM pg_range r WHERE r.rngtypid=t.oid OR r.rngmultitypid=t.oid),
        'composite_columns',(SELECT json_agg(json_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod)) ORDER BY a.attnum) FROM pg_attribute a WHERE a.attrelid=t.typrelid AND a.attnum>0 AND NOT a.attisdropped),'base_type',format_type(t.typbasetype,t.typtypmod),'not_null',t.typnotnull,'default',t.typdefault,'enum',(SELECT json_agg(e.enumlabel ORDER BY e.enumsortorder) FROM pg_enum e WHERE e.enumtypid=t.oid),'constraints',(SELECT json_agg(pg_get_constraintdef(c.oid) ORDER BY c.conname) FROM pg_constraint c WHERE c.contypid=t.oid)) ORDER BY n.nspname,t.typname),'[]') FROM pg_type t JOIN pg_namespace n ON n.oid=t.typnamespace WHERE n.nspname NOT LIKE 'pg_%' AND n.nspname <> 'information_schema' AND (t.typtype IN ('d','e','r','m') OR (t.typtype='c' AND EXISTS(SELECT FROM pg_class c WHERE c.oid=t.typrelid AND c.relkind='c')))),
      'extensions',(SELECT coalesce(json_agg(json_build_object('name',extname,'version',extversion,'schema',(SELECT nspname FROM pg_namespace WHERE oid=extnamespace),'owner',pg_get_userbyid(extowner)) ORDER BY extname),'[]') FROM pg_extension),
      'unsupported_objects',(SELECT coalesce(json_agg(json_build_object('schema',u.schema,'name',u.name,'kind',u.kind)),'[]') FROM (
        SELECT n.nspname AS schema,p.proname AS name,'aggregate' AS kind FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE p.prokind='a'
        UNION ALL SELECT n.nspname,o.oprname,'operator' FROM pg_operator o JOIN pg_namespace n ON n.oid=o.oprnamespace WHERE NOT EXISTS(SELECT FROM pg_depend d WHERE d.classid='pg_operator'::regclass AND d.objid=o.oid AND d.deptype='e')
        UNION ALL SELECT n.nspname,c.collname,'collation' FROM pg_collation c JOIN pg_namespace n ON n.oid=c.collnamespace WHERE NOT EXISTS(SELECT FROM pg_depend d WHERE d.classid='pg_collation'::regclass AND d.objid=c.oid AND d.deptype='e')
        UNION ALL SELECT n.nspname,c.conname,'conversion' FROM pg_conversion c JOIN pg_namespace n ON n.oid=c.connamespace WHERE NOT EXISTS(SELECT FROM pg_depend d WHERE d.classid='pg_conversion'::regclass AND d.objid=c.oid AND d.deptype='e')
        UNION ALL SELECT n.nspname,t.typname,'base type' FROM pg_type t JOIN pg_namespace n ON n.oid=t.typnamespace WHERE t.typtype='b' AND t.typelem=0 AND NOT EXISTS(SELECT FROM pg_depend d WHERE d.classid='pg_type'::regclass AND d.objid=t.oid AND d.deptype='e')
        UNION ALL SELECT n.nspname,c.relname,'foreign table' FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE c.relkind='f'
        UNION ALL SELECT n.nspname,c.relname||'.'||r.rulename,'rule' FROM pg_rewrite r JOIN pg_class c ON c.oid=r.ev_class JOIN pg_namespace n ON n.oid=c.relnamespace WHERE r.rulename <> '_RETURN'
      ) u WHERE u.schema NOT LIKE 'pg_%' AND u.schema <> 'information_schema'),
      'large_objects',(SELECT count(*) FROM pg_largeobject_metadata),
      'database_bytes',pg_database_size(current_database()), 'postgres_version',current_setting('server_version'))"""
    data: Dict[str, Any] = json.loads(snapshot.query(query, label="reflect database structure"))
    for relation in data["relations"]:
        qualified = identifier(relation["schema"]) + "." + identifier(relation["name"])
        if relation["kind"] in ("r", "p", "m"):
            relation["rows"] = int(
                snapshot.query(f"SELECT count(*) FROM ONLY {qualified}", label="count captured relation")
            )
        elif relation["kind"] == "S":
            relation["sequence"] = json.loads(
                snapshot.query(
                    f"SELECT json_build_object('last_value',last_value,'is_called',is_called) FROM {qualified}",
                    label="inspect captured sequence",
                )
            )
    # Routine OIDs/order can change on restore; identities are input types.
    data["functions"].sort(
        key=lambda f: (f["schema"], f["name"], json.dumps(f["arguments"]))
    )
    return data


def encrypt_metadata(path: Path, passphrase: Passphrase, value: Dict[str, Any]) -> None:
    """Encrypt reflected metadata directly from memory into its final artifact."""
    with path.open("xb") as output:
        os.chmod(path, 0o600)
        result = openssl_run(
            passphrase,
            ["enc", *ENCRYPTION],
            diagnostic_label="Encrypt metadata",
            input=json.dumps(value, sort_keys=True).encode(),
            stdout=output,
            stderr=subprocess.DEVNULL,
            check=False,
            env=work_environment(),
        )
        output.flush()
        os.fsync(output.fileno())
    if result.returncode:
        raise MigrationError("Metadata encryption failed")


def archive(
    container: Any,
    database: str,
    snapshot: Snapshot,
    path: Path,
    passphrase: Passphrase,
) -> None:
    """Stream one snapshot-bound compressed dump through OpenSSL."""
    with ExitStack() as processes:
        script = (
            'export PGPASSWORD="$(cat "$POSTGRES_PASSWORD_FILE")"; '
            f"export PGAPPNAME={application_name()}; "
            'exec pg_dump -w -h 127.0.0.1 -U "$POSTGRES_USER" -d "$1" '
            '--format=custom --compress=6 --snapshot="$2"'
        )
        producer = processes.enter_context(observed_process(
            [
                "docker",
                "exec",
                "--env",
                f"PGAPPNAME={application_name()}",
                container["Id"],
                "sh",
                "-ceu",
                script,
                "dump",
                database,
                snapshot.token,
            ],
            "Dump archive " + database,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            env=work_environment(),
        ))
        try:
            with path.open("xb") as output:
                os.chmod(path, 0o600)
                consumer = processes.enter_context(
                    openssl_process(
                        passphrase,
                        ["enc", *ENCRYPTION],
                        diagnostic_label="Encrypt archive " + database,
                        stdin=producer.stdout,
                        stdout=output,
                        stderr=subprocess.DEVNULL,
                        env=work_environment(),
                    )
                )
                assert producer.stdout is not None
                producer.stdout.close()
                status = consumer.wait()
                source_status = producer.wait()
                output.flush()
                os.fsync(output.fileno())
            if status or source_status:
                raise MigrationError(
                    f"Dump/compression/encryption pipeline failed: {database}"
                )
        finally:
            if producer.poll() is None:
                producer.terminate()
                producer.wait()


def inspect_archive(container: Any, path: Path, passphrase: Passphrase) -> str:
    """List archive contents while consuming the entire single decryption stream.

    pg_restore can finish listing before it reads data blocks. Keep draining
    OpenSSL after that point, checking both exits. This detects format/header
    failures and cipher termination errors, not every damaged data block.
    """
    from process_diagnostics import observed_process

    with ExitStack() as processes:
        decrypt = processes.enter_context(
            openssl_process(
                passphrase,
                ["enc", "-d", *ENCRYPTION, "-in", str(path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                env=work_environment(),
                diagnostic_label="decrypt archive inventory " + path.name,
            )
        )
        inspector = None
        contents = bytearray()
        overflow = threading.Event()
        read_failed = threading.Event()
        try:
            inspector = processes.enter_context(observed_process(
                ["docker", "exec", "-i", "--env", "PGAPPNAME=" + application_name(),
                 container["Id"], "pg_restore", "--list"],
                "inspect archive inventory " + path.name,
                stderr_kind="sql",
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                env=work_environment(),
            ))
            assert inspector.stdout is not None and inspector.stdin is not None
            assert decrypt.stdout is not None

            def drain_listing() -> None:
                assert inspector is not None and inspector.stdout is not None
                try:
                    while True:
                        chunk = inspector.stdout.read(65536)
                        if not chunk:
                            break
                        if len(contents) + len(chunk) <= 64 * 1024 * 1024:
                            contents.extend(chunk)
                        else:
                            overflow.set()
                except OSError:
                    read_failed.set()

            reader = threading.Thread(target=drain_listing)
            reader.start()
            accepting = True
            try:
                while True:
                    chunk = decrypt.stdout.read(65536)
                    if not chunk:
                        break
                    if accepting:
                        try:
                            inspector.stdin.write(chunk)
                            inspector.stdin.flush()
                        except BrokenPipeError:
                            accepting = False
                try:
                    inspector.stdin.close()
                except BrokenPipeError:
                    pass
                source_status = decrypt.wait()
                status = inspector.wait()
                reader.join()
                if overflow.is_set():
                    raise MigrationError(
                        f"Archive object listing exceeds supported 64 MiB limit: {path.name}"
                    )
                if source_status or status or read_failed.is_set():
                    raise MigrationError(
                        f"Encrypted archive decryption/inventory inspection failed: {path.name}"
                    )
                return contents.decode("utf-8", errors="strict")
            finally:
                if inspector.poll() is None:
                    inspector.terminate()
                    inspector.wait()
                reader.join()
        finally:
            if inspector is not None and inspector.stdout is not None:
                inspector.stdout.close()


def check_stopped(project: str, names: List[str]) -> None:
    """Reject writer or ingress restart during capture."""
    _, services = discover(project)
    for name in names:
        if services[name]["State"]["Running"] or services[name]["State"].get(
            "Restarting"
        ):
            raise MigrationError(f"Failed to stop service: {name}")


def restart(services: Dict[str, Any], originally_running: List[str]) -> None:
    """Recover the original writer group, await readiness, then reopen ingress."""
    # Healthchecks can depend on other writers (for example Keycloak). Start
    # the writer group first, await readiness, then reopen ingress.
    writers = [name for name in originally_running if name != "ingress"]
    for name in writers:
        docker("start", services[name]["Id"], step=f"Restart {name}")
    for name in writers + ["ingress"] * ("ingress" in originally_running):
        if name == "ingress":
            docker("start", services[name]["Id"], step="Restart ingress last")
        limit = time.monotonic() + 180
        while True:
            current = json.loads(
                docker("inspect", services[name]["Id"], step=f"Readiness {name}")
            )[0]
            healthy = current["State"].get("Health", {}).get("Status", "healthy")
            if (
                current["State"]["Running"]
                and not current["State"].get("Restarting")
                and healthy == "healthy"
            ):
                technical("Source recovery observation: service={}; container={}; running=true; readiness={}".format(
                    name, services[name]["Id"], healthy))
                break
            if time.monotonic() > limit:
                raise MigrationError(f"Source recovery readiness failed: {name}")
            time.sleep(1)


def create_dump_directory(backup: Path) -> None:
    """Create missing directories privately without changing existing permissions."""
    missing = []
    directory = backup
    while not directory.exists() and not directory.is_symlink():
        missing.append(directory)
        directory = directory.parent
    for directory in reversed(missing):
        try:
            directory.mkdir(mode=0o700)
        except FileExistsError:
            if not directory.is_dir():
                raise MigrationError("Backup destination is not a directory") from None
        else:
            directory.chmod(0o700)
    if not backup.is_dir():
        raise MigrationError("Backup destination is not a directory")


def capture(
    backup: Path,
    passphrase: Passphrase,
    daemon: str,
    project: str,
    version: str,
    services: Dict[str, Any],
    advice=None,
) -> None:
    """Capture five encrypted archives and metadata; leave writers stopped on success."""
    from guard import installation_identity

    global _WORK_ID
    if not Path("/proc/self/environ").is_file():
        raise MigrationError(
            "Dump recovery requires Linux /proc process attribution on the deployment host"
        )
    started = time.monotonic()
    installation = installation_identity(project)
    local_identity = hashlib.sha256(
        json.dumps([daemon, project], separators=(",", ":")).encode()
    ).hexdigest()
    lockpath = Path("/tmp") / f"osi-migration-dump-{local_identity}.lock"
    descriptor = os.open(lockpath, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise MigrationError(
                "Another dump is active for this installation"
            ) from None
        control = dump_control_identity(daemon, project)
        with work_identity("dump", control), recovery_protection():
            reconcile_work(services, control, "dump", state_only=True)
            state = StateVolume(project, services)
            recover_journal(state, services, local_identity, project)
        if _CANCELLED:
            raise MigrationError(
                "Dump cancelled during recovery; recorded original source recovery finished"
            )
        _, services = discover(project)
        create_dump_directory(backup)
        with phase("fresh capture storage capacity", quiet=True):
            check_storage_capacity("dump", backup, services)
        if any(backup.iterdir()):
            raise MigrationError(
                "Backup directory must be empty; preserve existing complete backups"
            )
        existing = state.read("dump-ready.json")
        if existing is not None:
            from guard import dump_success_identity, Rejected
            try:
                identity = dump_success_identity(existing, project)
            except Rejected:
                raise MigrationError("Invalid completed dump evidence") from None
            if identity["installation"] != installation:
                raise MigrationError("Completed dump belongs to another installation")
        names = ["ingress", *WRITERS]
        originally_running = [
            name for name in names if services[name]["State"]["Running"]
        ]
        _WORK_ID = uuid.uuid4().hex
        technical("Recovery attribution: operation=dump; recovery_id={}; application_name={}".format(
            _WORK_ID, application_name()))
        journal = {
            "capture_id": _WORK_ID,
            "schema": 1,
            "operation": "dump",
            "installation": local_identity,
            "project": project,
            "originally_running": originally_running,
        }
        try:
            with work_identity("dump", control):
                technical("Dump intent: publish source recovery journal")
                state.write("dump-journal.json", journal)
                technical("Dump observation: source recovery journal publication helper completed")
        except BaseException as primary:
            failure(primary, "dump journal publication failure")
            with recovery_protection():
                try:
                    reconcile_work(services, control, "dump", state_only=True)
                except (MigrationError, OSError) as cleanup_error:
                    failure(cleanup_error, "dump state-helper recovery failure")
                    technical("Dump outcome: failed before source stopping; state-helper cleanup=unknown", level=40)
                    customer(
                        "Dump state-helper cleanup failed; restart the product before another dump.",
                        level=40,
                        flush=True,
                    )
            technical("Dump outcome: failed before source stopping; source state not rechecked; "
                      "recovery journal publication outcome may be unknown", level=40)
            raise
        downtime = time.monotonic()
        recovered = False
        recovery_status = "unknown"
        try:
            customer("[2/5] Stop services")
            technical("Dump intent: stop source services; originally running=" + ", ".join(originally_running))
            with phase("stop ingress and source writers", quiet=True):
                for name in originally_running:
                    docker("stop", services[name]["Id"], step=f"Stop {name}")
                check_stopped(project, names)
                for service, database in SOURCES.items():
                    clients = int(
                        sql(
                            services[service],
                            database,
                            "SELECT count(*) FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid() AND backend_type='client backend'",
                        )
                    )
                    if clients:
                        raise MigrationError(
                            f"Unexpected database clients remain: {database}"
                        )
            technical("Dump observation: writers and ingress stopped; active database clients=0")
            _, services = discover(project)
            fingerprints = {
                name: {
                    path: hashlib.sha256(
                        read_secret(secret_provider(services, name), path)
                    ).hexdigest()
                    for path in paths
                }
                for name, paths in SECRETS.items()
            }
            metadata: Dict[str, Any] = {
                "schema": 2,
                "installation": installation,
                "daemon": daemon,
                "project": project,
                "source_version": version,
                "capture_id": _WORK_ID,
                "secrets": fingerprints,
                "databases": {},
            }
            rows = []
            customer("[3/5] Capture, encrypt and validate databases")
            customer("  Databases to dump: " + ", ".join(SOURCES.values()))
            metadata["capture_started_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            for number, (service, database) in enumerate(SOURCES.items(), 1):
                database_started = time.monotonic()
                customer(f"  Database {number}/{len(SOURCES)}")
                customer(f"  Starting dump: {database} ({service})")
                snapshot = Snapshot(services[service], database)
                progress_done = threading.Event()

                def report_database_progress() -> None:
                    while not progress_done.wait(PROGRESS_INTERVAL):
                        try:
                            elapsed = format_duration(time.monotonic() - database_started)
                            customer(f"  Dump in progress: {database} ({elapsed} elapsed)")
                        except OSError:
                            return

                progress_worker = threading.Thread(target=report_database_progress)
                progress_worker.start()
                try:
                    with phase(f"inventory {database}", quiet=True):
                        reflected = inventory(snapshot)
                        metadata["databases"][database] = reflected
                    filename = database + ".dump.enc"
                    with phase(f"dump/compression/encryption {database}", quiet=True):
                        archive(
                            services[service],
                            database,
                            snapshot,
                            backup / filename,
                            passphrase,
                        )
                    with phase(f"validation/checksum {database}", quiet=True):
                        inspect_archive(
                            services[service], backup / filename, passphrase
                        )
                        rows.append(
                            "\t".join(
                                [
                                    service,
                                    database,
                                    filename,
                                    str((backup / filename).stat().st_size),
                                    checksum(backup / filename),
                                    reflected["postgres_version"],
                                    "custom",
                                    "aes-256-cbc",
                                    "pbkdf2",
                                    "600000",
                                    "sha256",
                                ]
                            )
                        )
                finally:
                    try:
                        snapshot.close()
                    finally:
                        progress_done.set()
                        progress_worker.join()
                check_stopped(project, names)
                duration = format_duration(time.monotonic() - database_started)
                customer(f"  Dump complete: {database} ({service}) — {duration}")
            customer("[4/5] Encrypt and validate metadata")
            with phase("metadata encryption and validation", quiet=True):
                filename = "metadata.json.enc"
                encrypt_metadata(backup / filename, passphrase, metadata)
                decrypted = openssl_run(
                    passphrase,
                    ["enc", "-d", *ENCRYPTION, "-in", str(backup / filename)],
                    diagnostic_label="Validate encrypted metadata",
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    check=False,
                    env=work_environment(),
                )
                if decrypted.returncode or json.loads(decrypted.stdout) != metadata:
                    raise MigrationError("Encrypted metadata validation failed")
                manifest = (
                    "# osi-postgres-backup\t2\n"
                    + "# installation\t"
                    + installation
                    + "\n"
                    + "# capture\t"
                    + metadata["capture_id"]
                    + "\n"
                    + f"# metadata\t{filename}\t{(backup / filename).stat().st_size}\t{checksum(backup / filename)}\n"
                    + HEADER
                    + "\n"
                    + "\n".join(rows)
                    + "\n"
                ).encode()
            check_stopped(project, names)
            customer("[5/5] Register successful dump to unblock upgrade")
            with phase("publish complete backup and dump readiness", quiet=True):
                technical("Dump intent: publish complete backup manifest; path={}".format(backup / "manifest.tsv"))
                durable(backup / "manifest.tsv", manifest)
                technical("Dump observation: durable complete backup manifest publication returned")
                record = {
                    "schema": 2,
                    "migration": "security-intelligence-postgres",
                    "installation": installation,
                    "daemon": daemon,
                    "project": project,
                    "capture_id": metadata["capture_id"],
                    "source_version": version,
                    "manifest_sha256": checksum(backup / "manifest.tsv"),
                    "backup": str(backup.resolve()),
                    "phase": "dump-ready",
                }
                technical("Dump intent: publish or retain successful-dump evidence")
                state.publish_dump_success(record)
                technical("Dump observation: successful-dump evidence validated")
                technical("Dump intent: remove source recovery journal")
                state.remove("dump-journal.json")
                technical("Dump observation: source recovery journal removal helper completed")
        except BaseException as primary:
            failure(primary, "dump primary failure")
            if isinstance(primary, MigrationError):
                technical("Dump primary error: " + str(primary), level=40)
            technical("Dump recovery intent: reconcile owned work and restore original source states")
            try:
                reconcile_work(services, _WORK_ID)
                if not recovered:
                    with phase("recover originally running source services after failure"):
                        _, services = discover(project)
                        stopped_observed = True
                        for name in names:
                            if name not in originally_running and (
                                services[name]["State"]["Running"]
                                or services[name]["State"].get("Restarting")
                            ):
                                stopped_observed = False
                                docker(
                                    "stop",
                                    services[name]["Id"],
                                    step=f"Recover initially stopped {name}",
                                )
                        restart(services, originally_running)
                        recovered = True
                        recovery_status = "confirmed" if stopped_observed else "unknown"
                        technical("Dump recovery: originally running services readiness confirmed; "
                                  "original stopped states={}".format(recovery_status))
                technical("Dump intent: remove source recovery journal")
                state.remove("dump-journal.json")
                technical("Dump observation: source recovery journal removal helper completed")
            except BaseException as recovery_error:
                failure(recovery_error, "dump recovery failure")
                if isinstance(recovery_error, MigrationError):
                    technical("Dump recovery error: " + str(recovery_error), level=40)
                technical("Dump outcome: failed; recovery=unknown", level=40)
                raise
            technical("Dump outcome: failed; recovery={}".format(recovery_status), level=40)
            raise
        finally:
            label = "Actual downtime" if recovered else "Downtime continuing; elapsed"
            technical(f"{label} seconds={time.monotonic() - downtime:.3f}", flush=True)
            technical(f"Total dump wall seconds={time.monotonic()-started:.3f}", flush=True)
        technical("Dump outcome: successful capture; writers and ingress observed stopped before publication; "
                  "backup complete; successful-dump evidence validated; source services remain stopped")
        # Final reporting cannot send a completed dump back through source recovery.
        from deployment_advice import HostAdvice
        advice = advice or HostAdvice()
        customer("The dump was successful.\n"
                 "Next step: upgrade to OPENVAS Security Intelligence {}.".format(advice.target_version))
        advice.show('upgrade')
        customer("Execute the restore script directly after the upgrade.\n"
                 "IMPORTANT: Any data in the upgraded product will be replaced by the restored data.\n"
                 "Therefore, OPENVAS Security Intelligence should not be used before the restore is complete.\n\n"
                 "Complete migration backup: " + str(backup / "manifest.tsv"), flush=True)
    finally:
        _WORK_ID = None
        os.close(descriptor)
