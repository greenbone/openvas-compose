"""Resolve the deployed destination once for every restore operation."""

from collections import OrderedDict
from typing import TYPE_CHECKING, Any, Dict, Tuple

from main import MigrationError

if TYPE_CHECKING:
    from validation import SourceMapping

# Service -> deployed database setting, role setting, logical ownership identity.
SERVICE_SETTINGS = {
    "asset_management": (
        "VULNERABILITY_MANAGEMENT_DB_NAME",
        "ASSET_MANAGEMENT_DB_USER",
        "report-user",
    ),
    "vulnerability_intelligence": (
        "VULNERABILITY_MANAGEMENT_DB_NAME",
        "VULNERABILITY_INTELLIGENCE_DB_USER",
        "view-user",
    ),
    "management_console": (
        "MANAGEMENT_CONSOLE_DB_NAME",
        "MANAGEMENT_CONSOLE_DB_USER",
        "system-control-user",
    ),
    "websocket_tunnel": (
        "MANAGEMENT_CONSOLE_DB_NAME",
        "MANAGEMENT_CONSOLE_WST_DB_USER",
        "wst-user",
    ),
    "notification": (
        "NOTIFICATION_SERVICE_DB_NAME",
        "NOTIFICATION_SERVICE_DB_USER",
        "notification-user",
    ),
    "keycloak": ("KEYCLOAK_DB_NAME", "KEYCLOAK_DB_USER", "keycloak-user"),
}
SERVICE_ORDER = (
    "asset_management",
    "vulnerability_intelligence",
    "management_console",
    "websocket_tunnel",
    "notification",
    "keycloak",
)
PROVISION = "/run/secrets/osi-postgres-provision"


class ServiceDestination:
    """One service's resolved database and application role."""

    database: str
    role: str

    __slots__ = ("database", "role")

    def __init__(self, database: str, role: str) -> None:
        object.__setattr__(self, "database", database)
        object.__setattr__(self, "role", role)

    def __setattr__(self, name: str, value: Any) -> None:
        raise AttributeError("cannot assign to immutable record")

    def __delattr__(self, name: str) -> None:
        raise AttributeError("cannot delete from immutable record")

    def __eq__(self, other: Any) -> bool:
        if type(other) is not type(self):
            return NotImplemented
        return (
            self.database,
            self.role,
        ) == (
            other.database,
            other.role,
        )

    def __hash__(self) -> int:
        return hash(
            (
                self.database,
                self.role,
            )
        )

    def __repr__(self) -> str:
        return (
            "ServiceDestination(database={self.database!r}, role={self.role!r})".format(
                self=self
            )
        )


class Destination:
    """Immutable identifiers shared by reset, provisioning and data mapping."""

    asset_management: "ServiceDestination"
    vulnerability_intelligence: "ServiceDestination"
    management_console: "ServiceDestination"
    websocket_tunnel: "ServiceDestination"
    notification: "ServiceDestination"
    keycloak: "ServiceDestination"

    __slots__ = (
        "asset_management",
        "vulnerability_intelligence",
        "management_console",
        "websocket_tunnel",
        "notification",
        "keycloak",
    )

    def __init__(
        self,
        asset_management: "ServiceDestination",
        vulnerability_intelligence: "ServiceDestination",
        management_console: "ServiceDestination",
        websocket_tunnel: "ServiceDestination",
        notification: "ServiceDestination",
        keycloak: "ServiceDestination",
    ) -> None:
        object.__setattr__(self, "asset_management", asset_management)
        object.__setattr__(
            self, "vulnerability_intelligence", vulnerability_intelligence
        )
        object.__setattr__(self, "management_console", management_console)
        object.__setattr__(self, "websocket_tunnel", websocket_tunnel)
        object.__setattr__(self, "notification", notification)
        object.__setattr__(self, "keycloak", keycloak)

    def __setattr__(self, name: str, value: Any) -> None:
        raise AttributeError("cannot assign to immutable record")

    def __delattr__(self, name: str) -> None:
        raise AttributeError("cannot delete from immutable record")

    def __eq__(self, other: Any) -> bool:
        if type(other) is not type(self):
            return NotImplemented
        return (
            self.asset_management,
            self.vulnerability_intelligence,
            self.management_console,
            self.websocket_tunnel,
            self.notification,
            self.keycloak,
        ) == (
            other.asset_management,
            other.vulnerability_intelligence,
            other.management_console,
            other.websocket_tunnel,
            other.notification,
            other.keycloak,
        )

    def __hash__(self) -> int:
        return hash(
            (
                self.asset_management,
                self.vulnerability_intelligence,
                self.management_console,
                self.websocket_tunnel,
                self.notification,
                self.keycloak,
            )
        )

    def __repr__(self) -> str:
        return "Destination(asset_management={self.asset_management!r}, vulnerability_intelligence={self.vulnerability_intelligence!r}, management_console={self.management_console!r}, websocket_tunnel={self.websocket_tunnel!r}, notification={self.notification!r}, keycloak={self.keycloak!r})".format(
            self=self
        )

    @property
    def services(self) -> "Dict[str, ServiceDestination]":
        """Return the explicit service relationships in provisioning order."""
        return OrderedDict((name, getattr(self, name)) for name in SERVICE_ORDER)

    @property
    def databases(self) -> Tuple[str, ...]:
        """Derive distinct databases for reset and the provisioning shell ABI."""
        return tuple(
            OrderedDict.fromkeys(entry.database for entry in self.services.values())
        )

    @property
    def roles(self) -> Tuple[str, ...]:
        """Derive the shell provisioning role arguments from named services."""
        return tuple(entry.role for entry in self.services.values())

    @classmethod
    def resolve(cls, container: Dict[str, Any]) -> "Destination":
        """Read the selected container's inspected environment without defaults."""
        environment: Dict[str, str] = {}
        required = {
            setting
            for settings in SERVICE_SETTINGS.values()
            for setting in settings[:2]
        } | {"POSTGRES_USER", "POSTGRES_DB"}
        for entry in container["Config"].get("Env", []):
            name, separator, value = entry.partition("=")
            if name in required and separator:
                if name in environment:
                    raise MigrationError(f"Duplicate destination setting: {name}")
                environment[name] = value
        for name in required:
            value = environment.get(name, "")
            if not value or "\x00" in value or len(value.encode("utf-8")) > 63:
                raise MigrationError(f"Missing or invalid destination setting: {name}")
        destination = cls(
            **{
                service: ServiceDestination(environment[database], environment[role])
                for service, (database, role, _) in SERVICE_SETTINGS.items()
            }
        )
        databases, roles = destination.databases, destination.roles
        if (
            len(set(databases)) != 4
            or len(set(roles)) != 6
            or any(
                name
                in {"postgres", "template0", "template1", environment["POSTGRES_DB"]}
                or name.startswith("pg_")
                or "=" in name
                or name.startswith(("postgres://", "postgresql://"))
                for name in databases
            )
            or any(
                name == environment["POSTGRES_USER"] or name.startswith("pg_")
                for name in roles
            )
        ):
            raise MigrationError(
                "Unsafe destination mapping: application identifiers overlap"
            )
        return destination

    @property
    def database_roles(self) -> Dict[str, Tuple[str, ...]]:
        """Group the six service roles into the four supported databases."""
        return {
            database: tuple(
                entry.role
                for entry in self.services.values()
                if entry.database == database
            )
            for database in self.databases
        }

    def record(self) -> Dict[str, Dict[str, str]]:
        """Serialize named relationships; JSON object order has no identity meaning."""
        return {
            service: {"database": entry.database, "role": entry.role}
            for service, entry in self.services.items()
        }

    def matches_record(self, record: Dict[str, Any]) -> bool:
        """Require the exact resolved mapping in every recovery identity."""
        return bool(record.get("destination_mapping") == self.record())

    def mappings(
        self, mappings: "Dict[str, SourceMapping]"
    ) -> "Dict[str, SourceMapping]":
        """Resolve logical application mappings without guessing object ownership."""
        from validation import SourceMapping

        databases = {
            "vulnerability-management": self.asset_management.database,
            "appliance-management": self.management_console.database,
            "notification": self.notification.database,
            "keycloak": self.keycloak.database,
        }
        roles = {
            logical_role: self.services[service].role
            for service, (_, _, logical_role) in SERVICE_SETTINGS.items()
        }
        return {
            source: SourceMapping(
                schema_moves=mapping.schema_moves,
                relation_moves=mapping.relation_moves,
                target=databases[mapping.target],
                owner=roles[mapping.owner] if mapping.owner else None,
                object_owners={
                    key: roles[owner] for key, owner in mapping.object_owners.items()
                },
            )
            for source, mapping in mappings.items()
        }

    def targets(self) -> Dict[str, str]:
        """Return the supported source-to-resolved-database assignment."""
        return {
            "asset-management-backend": self.asset_management.database,
            "vulnerability-intelligence-backend": self.vulnerability_intelligence.database,
            "management-console-backend": self.management_console.database,
            "notification-service": self.notification.database,
            "keycloak": self.keycloak.database,
        }
