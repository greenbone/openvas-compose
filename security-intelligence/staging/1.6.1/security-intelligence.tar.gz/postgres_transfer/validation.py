"""Read-only validation of trusted backup artifacts and source expectations."""

import copy
import hashlib
import json
import os
import re
import stat
import subprocess
from datetime import datetime, timezone
from contextlib import ExitStack
from pathlib import Path
from typing import Any, Dict, List, Match, Optional, Set, Tuple

from diagnostics import technical
from guard import installation_identity

from capture import (
    ENCRYPTION,
    HEADER,
    checksum,
    inspect_archive,
    phase,
    work_environment,
)
from main import (
    SECRETS,
    SOURCES,
    MigrationError,
    BackupIntegrityError,
    capacity_with_margin,
    read_secret,
    require,
    secret_provider,
    sql,
    storage,
)
from passphrase import Passphrase, openssl_process


class Backup:
    """Trusted shared-restore input, normally produced by validate_backup.

    Public validation includes all five bounded TOCs. Controlled/real database
    fixtures may construct this object directly after establishing equivalent
    trusted metadata/artifacts; omitted TOCs then receive one inspection before
    their stream restore. Direct construction is not a public validation bypass.
    """

    manifest: Dict[str, Any]
    metadata: Dict[str, Any]
    tocs: Dict[str, str]

    __slots__ = ("manifest", "metadata", "tocs")

    def __init__(
        self,
        manifest: Dict[str, Any],
        metadata: Dict[str, Any],
        tocs: Optional[Dict[str, str]] = None,
    ) -> None:
        object.__setattr__(self, "manifest", manifest)
        object.__setattr__(self, "metadata", metadata)
        object.__setattr__(self, "tocs", {} if tocs is None else tocs)

    def __setattr__(self, name: str, value: Any) -> None:
        raise AttributeError("cannot assign to immutable record")

    def __delattr__(self, name: str) -> None:
        raise AttributeError("cannot delete from immutable record")

    def __eq__(self, other: Any) -> bool:
        if type(other) is not type(self):
            return NotImplemented
        return (
            self.manifest,
            self.metadata,
            self.tocs,
        ) == (
            other.manifest,
            other.metadata,
            other.tocs,
        )

    def __hash__(self) -> int:
        return hash(
            (
                self.manifest,
                self.metadata,
                self.tocs,
            )
        )

    def __repr__(self) -> str:
        return "Backup(manifest={self.manifest!r}, metadata={self.metadata!r}, tocs={self.tocs!r})".format(
            self=self
        )


def fail(condition: bool, message: str) -> None:
    """Raise an operator-safe MigrationError when a contract check fails.

    Args:
        condition: Evaluated validation result.
        message: Safe diagnostic, excluding secret values and subprocess output.

    Raises:
        MigrationError: The condition is false."""
    if not condition:
        raise MigrationError(message)


def artifact_reference(name: str, size: str, digest: str) -> None:
    """Check a manifest artifact reference without opening its ciphertext.

    Args:
        name: Safe basename relative to the backup directory.
        size: Positive encrypted byte count as decimal text.
        digest: Lowercase SHA-256 checksum text.

    Raises:
        MigrationError: Path, size or digest syntax is unsupported.
    """
    fail(
        bool(name)
        and Path(name).name == name
        and name not in (".", "..")
        and "\\" not in name,
        "Unsafe backup artifact basename",
    )
    fail(
        size.isdecimal() and int(size) > 16, f"Invalid encrypted artifact size: {name}"
    )
    fail(
        bool(re.fullmatch(r"[0-9a-f]{64}", digest)),
        f"Invalid encrypted artifact checksum format: {name}",
    )


def artifact(backup: Path, name: str, size: str, digest: str) -> Path:
    """Validate a referenced ciphertext file without decrypting or changing it.

    Args:
        backup: Backup directory.
        name: Single safe artifact basename; symlinks are rejected.
        size: Declared positive encrypted byte count as decimal text.
        digest: Declared lowercase SHA-256 hex digest.

    Returns:
        Validated path. The caller must prevent subsequent artifact replacement.

    Raises:
        MigrationError: Path, file kind, size, checksum or envelope disagrees.
        OSError: File hashing or reading fails."""
    artifact_reference(name, size, digest)
    path = backup / name
    try:
        info = path.lstat()
    except OSError:
        raise MigrationError(f"Missing backup artifact: {name}") from None
    fail(stat.S_ISREG(info.st_mode), f"Backup artifact must be a regular file: {name}")
    if info.st_size != int(size):
        raise BackupIntegrityError(f"Encrypted artifact size mismatch: {name}")
    if checksum(path) != digest:
        raise BackupIntegrityError(f"Encrypted artifact checksum mismatch: {name}")
    with path.open("rb") as stream:
        fail(stream.read(8) == b"Salted__", f"Unsupported encrypted envelope: {name}")
    return path


def read_manifest(backup: Path, daemon: str, project: str) -> Dict[str, Any]:
    """Read bounded manifest structure without opening referenced ciphertext.

    Reject unsupported mappings, paths, encryption parameters or installation
    binding before callers may mutate services. Returned fields are validated
    references, not decrypted payloads; files must remain unchanged afterwards.

    Args:
        backup: Completed encrypted backup directory retained by the operator.
        daemon: Current local operation context; durable identity is project-only.
        project: Selected isolated Compose installation.

    Returns:
        Manifest fields and artifact references bound to this installation.

    Raises:
        MigrationError: Manifest structure checks fail.
        OSError: The manifest is inaccessible.
    """
    path = backup / "manifest.tsv"
    try:
        descriptor = os.open(str(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(descriptor, "rb") as stream:
            fail(stat.S_ISREG(os.fstat(stream.fileno()).st_mode),
                 "Complete migration backup manifest must be a regular file")
            content = stream.read(65536)
        fail(len(content) < 65536, "Complete migration backup manifest is too large")
        lines = content.decode("utf-8").splitlines()
    except OSError:
        raise MigrationError(
            "Complete migration backup manifest is missing or inaccessible"
        ) from None
    fail(
        len(lines) == 10
        and lines[0] == "# osi-postgres-backup\t2"
        and lines[4] == HEADER,
        "Incomplete or unsupported Complete migration backup manifest",
    )
    installation = installation_identity(project)
    fail(
        lines[1] == "# installation\t" + installation,
        "Backup belongs to a different installation",
    )
    capture = lines[2].split("\t")
    fail(
        len(capture) == 2
        and capture[0] == "# capture"
        and bool(re.fullmatch("[0-9a-f]{32}", capture[1])),
        "Invalid backup capture identifier",
    )
    metadata = lines[3].split("\t")
    fail(
        len(metadata) == 4
        and metadata[0] == "# metadata"
        and metadata[1] == "metadata.json.enc",
        "Missing or incorrect encrypted metadata reference",
    )
    rows = [line.split("\t") for line in lines[5:]]
    fail(all(len(row) == 11 for row in rows), "Invalid backup archive fields")
    fail(
        {(row[0], row[1]) for row in rows} == set(SOURCES.items()),
        "Backup requires the exact five source archive mappings",
    )
    fail(len({row[0] for row in rows}) == 5, "Duplicate source archive mapping")
    for row in rows:
        fail(row[2] == row[1] + ".dump.enc", "Incorrect source archive basename")
        fail(
            row[6:] == ["custom", "aes-256-cbc", "pbkdf2", "600000", "sha256"],
            "Unsupported archive format or encryption parameters",
        )
        fail(
            bool(re.fullmatch(r"\d+\.\d+(?:\.[0-9]+)?(?:[ -].*)?", row[5])),
            "Invalid source PostgreSQL version format",
        )
        artifact_reference(row[2], row[3], row[4])
    artifact_reference(metadata[1], metadata[2], metadata[3])
    return {
        "installation": installation,
        "capture_id": capture[1],
        "archives": rows,
        "metadata": metadata[1],
        "metadata_artifact": metadata[1:],
        "sha256": hashlib.sha256(content).hexdigest(),
    }


def validate_backup(
    backup: Path,
    passphrase: Passphrase,
    daemon: str,
    project: str,
    services: Dict[str, Any],
    *,
    check_capacity: bool = True,
    manifest: Optional[Dict[str, Any]] = None,
) -> Backup:
    """Validate metadata first, then all archive hashes, secrets and inspection.

    Drain each decrypted archive before any destructive work and retain only its
    bounded object TOC in memory. Public restore checks installation-level dump success before
    calling this artifact-validation seam. No payload plaintext is staged. The
    returned Backup is trusted by the shared restore API; preserve its files afterwards.
    check_capacity=False defers allocation checks for completed no-op retries;
    callers must run validate_capacity before an actual data reset. Validation
    failures raise MigrationError without changing services or database data.

    Args:
        backup: Completed backup directory; its files must remain unchanged.
        passphrase: Protected operator passphrase file.
        daemon: Current local operation context; durable identity is project-only.
        project: Selected isolated Compose installation.
        services: Preflight-discovered target service containers.
        check_capacity: Whether to reserve new allocation immediately.
        manifest: Structurally validated manifest with installation compatibility checked;
            omitted only by shared-API callers doing their own compatibility checks.

    Returns:
        Validated manifest, metadata and five bounded object TOCs.

    Raises:
        MigrationError: Artifact, metadata, secret, archive or capacity checks fail.
        OSError: Backup files or required subprocesses are inaccessible.
    """
    if manifest is None:
        manifest = read_manifest(backup, daemon, project)
    with phase("validate encrypted metadata size and checksum", "check encrypted metadata", quiet=True):
        artifact(backup, *manifest["metadata_artifact"])
    with phase("decrypt and validate source metadata", "validate backup metadata", quiet=True):
        metadata = decrypt_metadata(backup / manifest["metadata"], passphrase)
        validate_metadata(metadata, manifest, daemon, project)
    with phase("validate all archive ciphertext sizes and checksums", "check encrypted archives", quiet=True):
        for row in manifest["archives"]:
            artifact(backup, row[2], row[3], row[4])
    with phase("compare application encryption keys and salts", "check backup compatibility", quiet=True):
        for service, paths in SECRETS.items():
            container = secret_provider(services, service)
            for path in paths:
                fail(
                    hashlib.sha256(read_secret(container, path)).hexdigest()
                    == metadata["secrets"][service][path],
                    f"Application encryption secret mismatch: {service} {path}; migration only works if the new version has the same secrets as the old one. Make sure you are restoring the data to the same installation where you dumped it from.",
                )
    with phase("streamed archive decryption and inventory inspection", "validate encrypted database archives", quiet=True):
        container = require(services, "osi-postgres")
        tocs = {
            row[1]: inspect_archive(container, backup / row[2], passphrase)
            for row in manifest["archives"]
        }
    if check_capacity:
        validate_capacity(metadata, container)
    return Backup(manifest, metadata, tocs)


def validate_capacity(metadata: Dict[str, Any], container: Any) -> None:
    """Reserve new allocation only for an actual destructive data attempt."""
    from main import RestoreBlocker

    with phase("backup-derived destination capacity", "check restore storage capacity", quiet=True):
        source_bytes = sum(d["database_bytes"] for d in metadata["databases"].values())
        required = capacity_with_margin(source_bytes)
        try:
            directory = sql(container, "postgres", "SHOW data_directory")
            device, available = storage(container, directory)
        except (ValueError, IndexError):
            raise RestoreBlocker(
                "Destination database storage capacity is unavailable",
                "Investigate access to the destination database filesystem and restore capacity reporting before retrying.",
            ) from None
        if not device or available < 0:
            raise RestoreBlocker(
                "Destination database storage capacity is unavailable",
                "Investigate access to the destination database filesystem and restore capacity reporting before retrying.",
            )
        technical(
            f"Restore capacity: source database bytes={source_bytes}; destination filesystem={device}; free bytes={available}; new-data reserve bytes={required}",
            flush=True,
        )
        technical(
            "Sizing estimate reserves new data plus 10% headroom, rounded up, in addition to retained old data/backups; does not credit target deletion and is not a space guarantee.",
            flush=True,
        )
        if available < required:
            raise RestoreBlocker(
                f"Insufficient database capacity for restored data. Needed: {required / 1_000_000_000:.1f} GB, "
                f"available: {available / 1_000_000_000:.1f} GB. Storage: {device} ({directory}). "
                f"Required free space: {required} bytes (includes 10% headroom).",
                f"Free space on the filesystem {device} containing {directory} before retrying.",
                retry=True,
            )


def unique_object(pairs: List[Tuple[str, Any]]) -> Dict[str, Any]:
    """Build a JSON object while rejecting duplicate field names.

    Args:
        pairs: JSON decoder's ordered key/value pairs.

    Returns:
        A new dictionary preserving values.

    Raises:
        MigrationError: A field occurs more than once."""
    result: Dict[str, Any] = {}
    for key, value in pairs:
        fail(key not in result, "Duplicate encrypted metadata field")
        result[key] = value
    return result


def decrypt_metadata(path: Path, passphrase: Passphrase) -> Dict[str, Any]:
    """Decrypt object metadata into at most 64 MiB of memory, never a disk file.

    Reject failed decryption, duplicate JSON keys and non-object roots; always
    reap the producer. Structural and installation checks belong to the caller.

    Args:
        path: Encrypted metadata file already bound by the manifest.
        passphrase: Protected operator passphrase file.

    Returns:
        Decrypted JSON object for subsequent structural validation.

    Raises:
        MigrationError: Decryption, JSON structure or memory bounds fail.
        OSError: The decryption process cannot start.
    """
    with ExitStack() as processes:
        process = processes.enter_context(
            openssl_process(
                passphrase,
                ["enc", "-d", *ENCRYPTION, "-in", str(path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                env=work_environment(),
                diagnostic_label="decrypt backup metadata",
            )
        )
        output = bytearray()
        assert process.stdout is not None
        while True:
            chunk = process.stdout.read(65536)
            if not chunk:
                break
            fail(
                len(output) + len(chunk) <= 64 * 1024 * 1024,
                "Encrypted metadata exceeds supported 64 MiB object-inventory size",
            )
            output.extend(chunk)
        fail(
            process.wait() == 0,
            "Encrypted metadata decryption failed; check passphrase",
        )
        try:
            value = json.loads(output, object_pairs_hook=unique_object)
        except (ValueError, UnicodeError):
            raise MigrationError("Corrupt encrypted metadata JSON") from None
        if not isinstance(value, dict):
            raise MigrationError("Invalid encrypted metadata structure")
        return value


def backup_capture_time(metadata: Dict[str, Any]) -> datetime:
    """Read the required UTC capture time without interpreting filesystem ages."""
    value = metadata.get("capture_started_at")
    try:
        if not isinstance(value, str) or not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z", value):
            raise ValueError
        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except ValueError:
        from main import RestoreBlocker
        raise RestoreBlocker(
            "The backup capture time is missing or cannot be read. Restoration was refused.",
            "Create and successfully finish a fresh backup in a new directory before restoring. Keep the selected backup unchanged.",
        ) from None


def validate_metadata(
    metadata: Dict[str, Any], manifest: Dict[str, Any], daemon: str, project: str
) -> None:
    """Validate decrypted metadata structure and its manifest/installation binding.

    Read-only: does not prove source truth, actual destination secret equality, or
    restorability. validate_backup performs those additional artifact/secret probes.

    Args:
        metadata: Decrypted object including all five source inventories.
        manifest: Previously validated manifest with matching archive references.
        daemon: Current local operation context; never compared to backup provenance.
        project: Selected Compose installation.

    Raises:
        MigrationError: Metadata structure, provenance, bindings or inventories fail."""
    backup_capture_time(metadata)
    fail(
        set(metadata)
        == {
            "schema",
            "installation",
            "daemon",
            "project",
            "source_version",
            "capture_id",
            "capture_started_at",
            "secrets",
            "databases",
        },
        "Invalid encrypted metadata fields",
    )
    fail(
        type(metadata["schema"]) is int and metadata["schema"] == 2,
        "Unsupported encrypted metadata version",
    )
    fail(
        metadata["installation"] == manifest["installation"]
        and metadata["capture_id"] == manifest["capture_id"]
        and isinstance(metadata["daemon"], str) and bool(metadata["daemon"])
        and metadata["project"] == project,
        "Encrypted metadata installation/capture mismatch",
    )
    fail(
        isinstance(metadata["source_version"], str)
        and bool(metadata["source_version"].strip()),
        "Invalid encrypted metadata source version",
    )
    fail(
        isinstance(metadata["secrets"], dict)
        and set(metadata["secrets"]) == set(SECRETS),
        "Invalid application secret fingerprint inventory",
    )
    for service, paths in SECRETS.items():
        values = metadata["secrets"][service]
        fail(
            isinstance(values, dict) and set(values) == set(paths),
            "Invalid application secret fingerprint paths",
        )
        fail(
            all(
                isinstance(v, str) and re.fullmatch("[0-9a-f]{64}", v)
                for v in values.values()
            ),
            "Invalid application secret fingerprint",
        )
    databases = metadata["databases"]
    fail(
        isinstance(databases, dict) and set(databases) == set(SOURCES.values()),
        "Invalid source database metadata mapping",
    )
    for row in manifest["archives"]:
        data = databases[row[1]]
        fail(isinstance(data, dict), "Invalid reflected source inventory")
        fail(
            data.get("postgres_version") == row[5],
            "Archive/metadata PostgreSQL version mismatch",
        )
        for key in ("database_bytes", "large_objects"):
            fail(
                type(data.get(key)) is int and data[key] >= 0,
                "Invalid reflected source inventory sizes",
            )
        for key in ("schemas", "relations", "functions", "types", "extensions"):
            fail(
                isinstance(data.get(key), list),
                "Invalid reflected source inventory structure",
            )
        fail(
            all(
                isinstance(s, str)
                and s
                and "\x00" not in s
                and not s.startswith("pg_")
                and s != "information_schema"
                for s in data["schemas"]
            )
            and len(set(data["schemas"])) == len(data["schemas"]),
            "Invalid reflected schema inventory",
        )
        validate_inventory(data)


def named_object(value: Any, schemas: List[str], label: str) -> None:
    """Require a reflected object's nonempty name and allowed schema.

    Args:
        value: Candidate reflected catalog object; remains unchanged.
        schemas: Supported inventory schema names.
        label: Operator-safe object-category label for failure diagnostics.

    Raises:
        MigrationError: The candidate identity is malformed or outside the schemas."""
    fail(
        isinstance(value, dict)
        and isinstance(value.get("schema"), str)
        and value["schema"] in schemas
        and isinstance(value.get("name"), str)
        and bool(value["name"])
        and "\x00" not in value["name"],
        f"Invalid reflected {label} identity",
    )


def validate_inventory(data: Dict[str, Any]) -> None:
    """Reject ambiguous reflected catalog shapes before mapping or restoration.

    Require the supported inventory capability and typed object identities,
    ownership, dependencies, counts and sequence state. This validates metadata
    structure, not source truth or row content equality; callers must bind it to
    the encrypted capture and later compare the reflected destination.

    Args:
        data: Decrypted reflected inventory for one captured database.

    Raises:
        MigrationError: Required capability or catalog structure is unsupported.
    """
    schemas = data["schemas"]
    relations: Set[Tuple[str, str]] = set()
    for relation in data["relations"]:
        named_object(relation, schemas, "relation")
        identity = (relation["schema"], relation["name"])
        fail(identity not in relations, "Duplicate reflected relation identity")
        relations.add(identity)
        fail(
            relation.get("kind") in ("r", "p", "S", "v", "m", "f", "i", "I"),
            "Unsupported reflected relation kind",
        )
        for key in ("parents", "columns", "constraints", "indexes", "triggers"):
            fail(
                isinstance(relation.get(key), list),
                "Invalid reflected relation structure",
            )
        fail(
            type(relation.get("partition")) is bool,
            "Invalid reflected partition status",
        )
        fail(
            all(
                isinstance(p, list)
                and len(p) == 2
                and all(isinstance(v, str) and v for v in p)
                for p in relation["parents"]
            ),
            "Invalid reflected relation dependencies",
        )
        if data.get("inventory_version") == 2:
            for key, length in (("index_parent", 2), ("sequence_owner", 3)):
                fail(
                    key in relation
                    and (
                        relation[key] is None
                        or isinstance(relation[key], list)
                        and len(relation[key]) == length
                        and all(isinstance(v, str) and v for v in relation[key])
                    ),
                    "Invalid version2 relation dependency",
                )
            for key in ("row_type", "array_type"):
                fail(
                    key in relation
                    and (
                        relation[key] is None
                        or isinstance(relation[key], str)
                        and bool(relation[key])
                    ),
                    "Invalid version2 implicit type identity",
                )
        for column in relation["columns"]:
            fail(
                isinstance(column, dict)
                and isinstance(column.get("name"), str)
                and bool(column["name"])
                and isinstance(column.get("type"), str)
                and type(column.get("not_null")) is bool
                and column.get("identity") in ("", "a", "d")
                and column.get("generated") in ("", "s", "v")
                and (
                    column.get("default") is None or isinstance(column["default"], str)
                ),
                "Invalid reflected column structure",
            )
        for group in ("constraints", "triggers"):
            fail(
                all(
                    isinstance(v, dict)
                    and isinstance(v.get("name"), str)
                    and isinstance(v.get("definition"), str)
                    for v in relation[group]
                ),
                "Invalid reflected definitions",
            )
        fail(
            all(isinstance(v, str) for v in relation["indexes"]),
            "Invalid reflected index definitions",
        )
        fail(
            relation.get("view") is None or isinstance(relation["view"], str),
            "Invalid reflected view definition",
        )
        if relation["kind"] in ("r", "p", "m"):
            fail(
                type(relation.get("rows")) is int and relation["rows"] >= 0,
                "Invalid reflected exact row count",
            )
        if relation["kind"] == "S":
            state = relation.get("sequence")
            definition = relation.get("sequence_definition")
            fail(
                isinstance(state, dict)
                and set(state) == {"last_value", "is_called"}
                and type(state["last_value"]) is int
                and type(state["is_called"]) is bool,
                "Invalid reflected sequence state",
            )
            fail(
                isinstance(definition, dict)
                and set(definition)
                == {"type", "start", "increment", "min", "max", "cache", "cycle"}
                and isinstance(definition["type"], str)
                and type(definition["cycle"]) is bool
                and all(
                    type(definition[k]) is int
                    for k in ("start", "increment", "min", "max", "cache")
                ),
                "Invalid reflected sequence definition",
            )
    for function in data["functions"]:
        named_object(function, schemas, "routine")
        fail(
            isinstance(function.get("identity"), str)
            and isinstance(function.get("definition"), str),
            "Unsupported reflected routine definition",
        )
    for typ in data["types"]:
        named_object(typ, schemas, "type")
        fail(
            typ.get("kind") in ("d", "e", "r", "m", "c"),
            "Unsupported reflected type kind",
        )
        fail(
            isinstance(typ.get("base_type"), str)
            and type(typ.get("not_null")) is bool
            and "default" in typ
            and (typ["default"] is None or isinstance(typ["default"], str)),
            "Invalid reflected type definition",
        )
        for key in ("enum", "constraints"):
            fail(
                key in typ
                and (
                    typ[key] is None
                    or isinstance(typ[key], list)
                    and all(isinstance(v, str) for v in typ[key])
                ),
                "Invalid reflected type values/constraints",
            )
        if data.get("inventory_version") == 2:
            fail(
                "range" in typ and "composite_columns" in typ and "array_type" in typ,
                "Incomplete version2 type inventory",
            )
            if typ["kind"] in ("r", "m"):
                fail(
                    isinstance(typ["range"], dict)
                    and set(typ["range"])
                    == {"subtype", "collation", "opclass", "canonical", "subdiff"}
                    and all(isinstance(v, str) for v in typ["range"].values()),
                    "Invalid reflected range definition",
                )
            if typ["kind"] == "c":
                fail(
                    isinstance(typ["composite_columns"], list)
                    and all(
                        isinstance(v, dict)
                        and isinstance(v.get("name"), str)
                        and isinstance(v.get("type"), str)
                        for v in typ["composite_columns"]
                    ),
                    "Invalid reflected composite type definition",
                )
    names = set()
    for extension in data["extensions"]:
        fail(
            isinstance(extension, dict)
            and isinstance(extension.get("name"), str)
            and bool(extension["name"])
            and isinstance(extension.get("version"), str)
            and bool(extension["version"]),
            "Invalid extension inventory",
        )
        fail(extension["name"] not in names, "Duplicate extension inventory")
        names.add(extension["name"])

    if data.get("inventory_version") == 2:
        fail(
            isinstance(data.get("unsupported_objects"), list),
            "Incomplete version2 unsupported-object inventory",
        )
        for category in ("relations", "functions", "types"):
            for value in data[category]:
                fail(
                    isinstance(value.get("owner"), str)
                    and bool(value["owner"])
                    and "extension" in value
                    and (
                        value["extension"] is None
                        or isinstance(value["extension"], str)
                        and value["extension"] in names
                    ),
                    "Invalid version2 object ownership/extension membership",
                )


class SourceMapping:
    """Release-specific object placement; concrete memberships belong to tickets07/08.

    Missing owner means every non-extension object needs explicit ownership.
    Moves change schemas only, never object names, queue data or row payloads.
    Indexes and owned sequences follow their reflected parent table.
    """

    target: str
    owner: Optional[str]
    schema_moves: Dict[str, str]
    relation_moves: Dict[Tuple[str, str], str]
    object_owners: Dict[Tuple[str, str], str]

    __slots__ = ("target", "owner", "schema_moves", "relation_moves", "object_owners")

    def __init__(
        self,
        target: str,
        owner: Optional[str] = None,
        schema_moves: Optional[Dict[str, str]] = None,
        relation_moves: Optional[Dict[Tuple[str, str], str]] = None,
        object_owners: Optional[Dict[Tuple[str, str], str]] = None,
    ) -> None:
        object.__setattr__(self, "target", target)
        object.__setattr__(self, "owner", owner)
        object.__setattr__(
            self, "schema_moves", {} if schema_moves is None else schema_moves
        )
        object.__setattr__(
            self, "relation_moves", {} if relation_moves is None else relation_moves
        )
        object.__setattr__(
            self, "object_owners", {} if object_owners is None else object_owners
        )

    def __setattr__(self, name: str, value: Any) -> None:
        raise AttributeError("cannot assign to immutable record")

    def __delattr__(self, name: str) -> None:
        raise AttributeError("cannot delete from immutable record")

    def __eq__(self, other: Any) -> bool:
        if type(other) is not type(self):
            return NotImplemented
        return (
            self.target,
            self.owner,
            self.schema_moves,
            self.relation_moves,
            self.object_owners,
        ) == (
            other.target,
            other.owner,
            other.schema_moves,
            other.relation_moves,
            other.object_owners,
        )

    def __hash__(self) -> int:
        return hash(
            (
                self.target,
                self.owner,
                self.schema_moves,
                self.relation_moves,
                self.object_owners,
            )
        )

    def __repr__(self) -> str:
        return "SourceMapping(target={self.target!r}, owner={self.owner!r}, schema_moves={self.schema_moves!r}, relation_moves={self.relation_moves!r}, object_owners={self.object_owners!r})".format(
            self=self
        )


SOURCE_TARGETS = {
    "asset-management-backend": "vulnerability-management",
    "vulnerability-intelligence-backend": "vulnerability-management",
    "management-console-backend": "appliance-management",
    "notification-service": "notification",
    "keycloak": "keycloak",
}


# Match qualified PostgreSQL identifiers while respecting quoted spelling.
IDENTIFIER = r'"(?:[^"]|"")+"|[^\W\d][\w$]*'
QUALIFIED = re.compile(
    r"(?<![\w$])(" + IDENTIFIER + r")\s*\.\s*(" + IDENTIFIER + r")(?![\w$])"
)
SQL_TOKEN = re.compile(r"'(?:[^']|'')*'|" + QUALIFIED.pattern)


def unquote(value: str) -> str:
    """Decode a PostgreSQL identifier token, folding unquoted names to lowercase.

    Args:
        value: Identifier token accepted by the module's identifier expression.

    Returns:
        Decoded name; this helper is not a general SQL parser."""
    return value[1:-1].replace('""', '"') if value.startswith('"') else value.lower()


def rewrite_definition(
    value: str, placements: Dict[Tuple[str, str], str], schema_moves: Dict[str, str]
) -> str:
    """Rewrite mapped qualified catalog references without executing SQL.

    Args:
        value: Reflected SQL definition text.
        placements: Explicit object identities mapped to destination schemas.
        schema_moves: Fallback schema replacements.

    Returns:
        Rewritten text. Ordinary SQL string literals remain unchanged; literals cast
        to regclass/regtype may contain rewritten references. No arbitrary SQL
        semantic-equivalence guarantee is provided."""
    from capture import identifier

    def qualified(match: Match[str]) -> str:
        schema, name = unquote(match[1]), unquote(match[2])
        destination = placements.get((schema, name), schema_moves.get(schema, schema))
        if destination == schema:
            return match[0]
        return identifier(destination) + "." + match[2]

    def token(match: Match[str]) -> str:
        if match[0].startswith("'"):
            # SQL literals are not identifiers. Only regclass/regtype constants
            # represent catalog references; never rewrite ordinary function data.
            suffix = value[match.end() :]
            if re.match(r"\s*::\s*(?:pg_catalog\.)?(?:regclass|regtype)\b", suffix):
                inner = match[0][1:-1].replace("''", "'")
                return "'" + QUALIFIED.sub(qualified, inner).replace("'", "''") + "'"
            return match[0]
        result = QUALIFIED.fullmatch(match[0])
        assert result is not None
        return qualified(result)

    return SQL_TOKEN.sub(token, value)


def transformed(
    value: Any, placements: Dict[Tuple[str, str], str], schema_moves: Dict[str, str]
) -> Any:
    """Copy reflected definitions while applying catalog-reference replacements.

    Args:
        value: Reflected string, list, dictionary or scalar.
        placements: Object-specific destination schemas.
        schema_moves: Fallback schema replacements.

    Returns:
        Transformed containers without mutating input. Identity, ownership, extension,
        enum and kind fields are copied unchanged for the mapping caller to handle."""
    if isinstance(value, str):
        return rewrite_definition(value, placements, schema_moves)
    if isinstance(value, list):
        return [transformed(v, placements, schema_moves) for v in value]
    if isinstance(value, dict):
        return {
            k: (
                copy.deepcopy(v)
                if k in ("name", "schema", "owner", "extension", "enum", "kind")
                else transformed(v, placements, schema_moves)
            )
            for k, v in value.items()
        }
    return value


def transform_expectations(
    metadata: Dict[str, Any],
    mappings: "Dict[str, SourceMapping]",
    *,
    require_owners: bool = True,
    targets: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """Merge transformed reflected inventories, rejecting ambiguous namespaces.

    This validates mapping inputs before data deletion. The output retains all
    structural definitions, ONLY row counts and sequence state for later checks.
    It does not authorize an unfamiliar concrete layout or perform SQL changes.
    """
    fail(
        set(mappings) == set(SOURCES.values()),
        "Require all five concrete source mappings",
    )
    source_targets = SOURCE_TARGETS if targets is None else targets
    fail(
        set(source_targets) == set(SOURCES.values())
        and len(set(source_targets.values())) == 4,
        "Require five sources and four resolved destination databases",
    )
    result: Dict[str, Any] = {}
    namespaces: Dict[Tuple[Any, ...], Tuple[Dict[str, Any], str]] = {}
    for source, mapping in mappings.items():
        fail(
            mapping.target == source_targets[source],
            "Unsupported source/target database mapping",
        )
        data = metadata["databases"][source]
        validate_inventory(data)
        fail(
            data.get("inventory_version") == 2,
            "Source inventory lacks version2 ownership/dependency/signature capability; recapture X with the updated dump command",
        )
        fail(
            not data.get("unsupported_objects"),
            "Unsupported source objects require an inspected release-specific mapping",
        )
        identities = {(r["schema"], r["name"]) for r in data["relations"]}
        object_identities = identities | {
            (v["schema"], v["name"])
            for key in ("functions", "types")
            for v in data[key]
        }
        fail(
            set(mapping.schema_moves) <= set(data["schemas"])
            and set(mapping.relation_moves) <= identities
            and set(mapping.object_owners) <= object_identities,
            "Mapping refers to absent source objects or schemas",
        )
        fail(
            all(
                isinstance(s, str) and s and "\x00" not in s
                for s in [
                    *mapping.schema_moves.values(),
                    *mapping.relation_moves.values(),
                ]
            ),
            "Invalid mapped schema name",
        )
        fail(
            mapping.owner is None
            or isinstance(mapping.owner, str)
            and bool(mapping.owner),
            "Invalid destination owner",
        )
        fail(
            all(isinstance(s, str) and s for s in mapping.object_owners.values()),
            "Invalid mapped object owner",
        )
        placements = {
            identity: mapping.relation_moves.get(
                identity, mapping.schema_moves.get(identity[0], identity[0])
            )
            for identity in identities
        }
        owners = dict(mapping.object_owners)
        for relation in data["relations"]:
            identity = (relation["schema"], relation["name"])
            parent = relation.get("index_parent") or relation.get("sequence_owner")
            if parent:
                parent_id = tuple(parent[:2])
                fail(
                    parent_id in identities, "Ambiguous reflected index/sequence parent"
                )
                fail(
                    identity not in mapping.relation_moves
                    or placements[identity] == placements[parent_id],
                    "Index/owned sequence mapping conflicts with parent placement",
                )
                placements[identity] = placements[parent_id]
                if parent_id in owners:
                    fail(
                        identity not in owners or owners[identity] == owners[parent_id],
                        "Index/sequence owner conflicts with parent",
                    )
                    owners[identity] = owners[parent_id]
        destination = result.setdefault(
            mapping.target,
            {
                "schemas": [],
                "relations": [],
                "functions": [],
                "types": [],
                "extensions": [],
                "large_objects": 0,
                "database_bytes": 0,
                "inventory_version": 2,
            },
        )
        fail(
            not (destination["large_objects"] and data["large_objects"]),
            "Ambiguous large-object OIDs while merging sources; an inspected mapping is required",
        )
        destination["large_objects"] += data["large_objects"]
        destination["database_bytes"] += data["database_bytes"]
        destination["schemas"] = sorted(
            set(destination["schemas"])
            | {mapping.schema_moves.get(s, s) for s in data["schemas"]}
            | set(placements.values())
        )
        for category in ("relations", "functions", "types", "extensions"):
            for original in data[category]:
                item = transformed(
                    copy.deepcopy(original), placements, mapping.schema_moves
                )
                if category == "extensions":
                    fail(
                        "schema" in original and "owner" in original,
                        "Incomplete version2 extension inventory",
                    )
                    item["schema"] = mapping.schema_moves.get(
                        original["schema"], original["schema"]
                    )
                    identity_key: Tuple[Any, ...] = (
                        mapping.target,
                        "extension",
                        item["name"],
                    )
                else:
                    identity = (original["schema"], original["name"])
                    fail(
                        "owner" in original and "extension" in original,
                        "Incomplete version2 object ownership inventory",
                    )
                    item["schema"] = placements.get(
                        identity, mapping.schema_moves.get(identity[0], identity[0])
                    )
                    if not original["extension"]:
                        owner = owners.get(identity, mapping.owner)
                        fail(
                            not require_owners or owner is not None,
                            f"Ambiguous application ownership: {source} {identity[0]}.{identity[1]}",
                        )
                        if owner is not None:
                            item["owner"] = owner
                    if category == "functions":
                        arguments = original.get("arguments")
                        fail(
                            isinstance(arguments, list)
                            and all(
                                isinstance(v, list)
                                and len(v) == 2
                                and all(isinstance(t, str) for t in v)
                                for v in arguments
                            ),
                            "Incomplete version2 routine argument-type inventory",
                        )
                        item["arguments"] = [
                            [
                                placements.get(
                                    tuple(v), mapping.schema_moves.get(v[0], v[0])
                                ),
                                v[1],
                            ]
                            for v in arguments
                        ]
                        identity_key = (
                            mapping.target,
                            "routine",
                            item["schema"],
                            item["name"],
                            tuple(tuple(v) for v in item["arguments"]),
                        )
                    else:
                        identity_key = (
                            mapping.target,
                            "relation" if category == "relations" else "type",
                            item["schema"],
                            item["name"],
                        )
                    if category == "relations":
                        for parent_key in ("parents",):
                            item[parent_key] = [
                                [
                                    placements.get(
                                        tuple(p), mapping.schema_moves.get(p[0], p[0])
                                    ),
                                    p[1],
                                ]
                                for p in original[parent_key]
                            ]
                        for parent_key in ("index_parent", "sequence_owner"):
                            if original.get(parent_key):
                                p = original[parent_key]
                                item[parent_key] = [
                                    placements.get(
                                        tuple(p[:2]),
                                        mapping.schema_moves.get(p[0], p[0]),
                                    ),
                                    *p[1:],
                                ]
                previous = namespaces.get(identity_key)
                if previous:
                    old, old_source = previous
                    comparison = {k: v for k, v in item.items() if k != "owner"}
                    old_comparison = {k: v for k, v in old.items() if k != "owner"}
                    shared = (
                        category == "extensions"
                        or item.get("extension")
                        and item.get("extension") == old.get("extension")
                    )
                    fail(
                        bool(shared) and comparison == old_comparison,
                        f'Unexpected destination object collision: {mapping.target} {item.get("schema", "")}.{item["name"]}; sources {old_source}, {source}',
                    )
                    continue
                namespaces[identity_key] = (item, source)
                if category == "relations" and item["kind"] in (
                    "r",
                    "p",
                    "v",
                    "m",
                    "f",
                ):
                    fail(
                        original.get("row_type") == original["name"],
                        "Incomplete version2 implicit relation row-type inventory",
                    )
                    for type_name in (original["row_type"], original.get("array_type")):
                        if type_name:
                            key = (mapping.target, "type", item["schema"], type_name)
                            fail(
                                key not in namespaces,
                                f'Unexpected destination implicit relation type collision: {item["schema"]}.{type_name}',
                            )
                            namespaces[key] = (item, source)
                if category == "types" and item.get("array_type"):
                    key = (mapping.target, "type", item["schema"], item["array_type"])
                    fail(
                        key not in namespaces,
                        "Unexpected destination implicit array type collision",
                    )
                    namespaces[key] = (item, source)
                destination[category].append(item)
    fail(
        set(result) == set(source_targets.values()),
        "Require all four destination expectation inventories",
    )
    for destination in result.values():
        for category in ("relations", "types"):
            destination[category].sort(key=lambda item: (item["schema"], item["name"]))
        destination["functions"].sort(
            key=lambda item: (
                item["schema"],
                item["name"],
                json.dumps(item["arguments"]),
            )
        )
        destination["extensions"].sort(key=lambda item: item["name"])
    return result
