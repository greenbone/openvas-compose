"""Attributed, isolated execution of the packaged Findings history command."""
import json
import os
from pathlib import Path
import re
import tempfile
import time
import uuid
from contextlib import contextmanager
from typing import Any, Callable, Dict, Iterator, List, Optional, Tuple

from main import CredentialsTransferError, DeploymentPrerequisite, MigrationError, docker

JOB = 'asset-management-backend-migration'
COMMAND = '/bin/build-findings-revisions'
REPAIR_COMMAND = '/bin/repair-orphan-evidence'
STARTUP = '/bin/startup.sh'
# Keep repair's output off functional stdout. Status framing is authored here;
# arbitrary backend diagnostics are interpreted only through the allowlist below.
REPAIR_SEQUENCE = '''printf '%s\\n' 'OSI repair @TOKEN@ start' >&2
/bin/repair-orphan-evidence --apply >&2
repair_status=$?
printf '\\nOSI repair @TOKEN@ exit %s\\n' "$repair_status" >&2
[ "$repair_status" -eq 0 ] || exit "$repair_status"
exec "$@"
'''
PROGRESS_INTERVAL = 30
DATABASE_ENV = (
    'DB_HOST', 'DB_PORT', 'DB_USERNAME', 'DB_NAME', 'DB_MIGRATION_STATE_SCHEMA',
    'DB_SSL_MODE', 'GORM_LOGGING', 'GORM_LOGGING_SLOW_MS',
    'PGSSLROOTCERT', 'PGSSLCERT', 'PGSSLKEY', 'PGSSLCRL',
)


class HelperConfig:
    """Current inspected schema-job configuration, retained for this invocation only."""
    def __init__(self, image: str, user: str, network: str,
                 environment: Dict[str, str], mounts: List[str], work_id: str) -> None:
        self.image = image
        self.user = user
        self.network = network
        self.environment = environment
        self.mounts = mounts
        self.work_id = work_id
        self.target_probe_deferred = False


def prepare_helper(services: Dict[str, Any], work_id: str) -> HelperConfig:
    """Reject checkable unsupported helper inputs before protected mutation."""
    def require(condition: bool, detail: str) -> None:
        if not condition:
            raise DeploymentPrerequisite('Unsupported Findings history helper configuration: ' + detail)

    require(JOB in services, 'missing Asset Management schema job')
    job = services[JOB]
    image = job.get('Image', '')
    user = job.get('Config', {}).get('User', '')
    require(isinstance(image, str) and re.fullmatch(r'sha256:[0-9a-f]{64}', image) is not None,
            'schema job must expose an exact image ID')
    require(isinstance(user, str) and re.fullmatch(r'[0-9]+(?::[0-9]+)?', user) is not None,
            'schema job must configure a numeric runtime user')
    source = {}
    for entry in job.get('Config', {}).get('Env', []):
        key, separator, value = entry.partition('=')
        require(bool(separator) and key not in source, 'invalid or duplicate schema-job environment')
        source[key] = value
    for key in ('DB_HOST', 'DB_NAME', 'DB_USERNAME'):
        require(bool(source.get(key)), 'missing ' + key)
    from destination import Destination
    destination = Destination.resolve(services['osi-postgres']).asset_management
    require(source['DB_NAME'] == destination.database and source['DB_USERNAME'] == destination.role,
            'schema-job database and role must match the selected Asset Management destination')
    require(source.get('DB_PORT', '5432').isdigit()
            and 1 <= int(source.get('DB_PORT', '5432')) <= 65535, 'invalid DB_PORT')
    require(source.get('DB_SSL_MODE', 'disable') in
            ('disable', 'allow', 'prefer', 'require', 'verify-ca', 'verify-full'), 'invalid DB_SSL_MODE')
    environment = {key: source[key] for key in DATABASE_ENV if key in source}
    environment['DB_SCHEMA'] = 'application'
    environment['PGAPPNAME'] = 'osi-migration-restore-' + work_id
    require(all('\n' not in value and '\r' not in value and '\0' not in value
                for value in environment.values()), 'multiline database environment is unsupported')
    networks = job.get('NetworkSettings', {}).get('Networks', {})
    postgres_networks = services.get('osi-postgres', {}).get('NetworkSettings', {}).get('Networks', {})
    shared = sorted(set(networks) & set(postgres_networks))
    require(bool(shared), 'schema job and PostgreSQL require a shared network')
    mounts = []
    for key in ('PGSSLROOTCERT', 'PGSSLCERT', 'PGSSLKEY', 'PGSSLCRL'):
        path = source.get(key)
        if not path:
            continue
        require(Path(path).is_absolute(), key + ' must be an absolute mounted path')
        candidates = [mount for mount in job.get('Mounts', [])
                      if path == mount.get('Destination') or
                      path.startswith(mount.get('Destination', '').rstrip('/') + '/')]
        require(bool(candidates), key + ' requires an inspectable TLS mount')
        mount = max(candidates, key=lambda item: len(item['Destination']))
        require(mount.get('Destination') not in ('/', '/run', '/run/secrets'),
                'TLS access must not mount unrelated application secrets')
        require(mount.get('Type') in ('bind', 'volume'), 'unsupported TLS mount type')
        origin = mount.get('Name') if mount['Type'] == 'volume' else mount.get('Source')
        require(bool(origin) and ',' not in origin and ',' not in mount['Destination'], 'unsupported TLS mount path')
        option = 'type={},src={},dst={},readonly'.format(mount['Type'], origin, mount['Destination'])
        if option not in mounts:
            mounts.append(option)
    return HelperConfig(image, user, shared[0], environment, mounts, work_id)


@contextmanager
def created_helper(config: HelperConfig, arguments: List[str], *,
                   entrypoint: str = STARTUP, command: str = COMMAND) -> Iterator[str]:
    """Create stopped attributed work; only this live caller can subsequently start it.

    A daemon-side delayed create may leave a stopped labelled orphan after an
    interrupted request. Installation reconciliation removes it on the next run.
    No subprocess combines create with start or survives to start it later.
    """
    name = 'osi-findings-' + uuid.uuid4().hex
    descriptor, filename = tempfile.mkstemp(prefix='osi-findings-env-')
    try:
        with os.fdopen(descriptor, 'w') as stream:
            for key, value in sorted(config.environment.items()):
                stream.write(key + '=' + value + '\n')
        args = ['create', '--name', name, '--restart=no', '--cap-drop=ALL',
                '--label', 'net.greenbone.migration-work=' + config.work_id,
                '--user', config.user, '--network', config.network,
                '--env-file', filename, '--entrypoint', entrypoint]
        for mount in config.mounts:
            args.extend(['--mount', mount])
        docker(*args, config.image, command, *arguments,
               step='Create stopped Findings history helper')
        yield name
    finally:
        try:
            Path(filename).unlink()
        except FileNotFoundError:
            pass
        try:
            docker('rm', '-f', name, step='Remove Findings history helper')
        except MigrationError:
            # An interrupted daemon-side create may not yet be discoverable.
            # The stable label allows the next locked invocation to remove it.
            # Successful execution must still fail if a known container survives.
            remaining = docker('ps', '-aq', '--filter', 'name=^/' + name + '$',
                               step='Check Findings history helper removal')
            if remaining:
                raise


def probe_command(config: HelperConfig) -> None:
    """Probe packaging through startup without needing application credentials."""
    for command, label in ((COMMAND, 'Findings history'), (REPAIR_COMMAND, 'Orphan evidence repair')):
        with created_helper(config, ['--help'], command=command) as name:
            docker('start', '--attach', name, step=label + ' command availability')
            observed = json.loads(docker('inspect', name, step='Inspect ' + label + ' command outcome'))
            if (len(observed) != 1 or observed[0].get('State', {}).get('Running') is not False
                    or observed[0].get('State', {}).get('ExitCode') != 0):
                raise MigrationError(label + ' command availability: command did not exit successfully')


SECRET_NAMES = ('DB_PASSWORD', 'TASK_REPORT_CRYPTO_V1_PASSWORD', 'TASK_REPORT_CRYPTO_V1_SALT')
RESULT_LIMIT = 48 * 1024


def reconstruction_prerequisites(services: Dict[str, Any], work_id: str,
                                 fingerprints: Optional[Dict[str, str]], *,
                                 restoration_required: bool = False) -> Tuple[HelperConfig, Dict[str, bytes]]:
    """Check unfinished reconstruction inputs before service/data/marker mutation.

    Help establishes packaging only. Restored-schema, privilege and transaction
    compatibility remain authoritative checks of the normal reconstruction run.
    """
    import hashlib
    from main import read_secret
    config = prepare_helper(services, work_id)
    secrets = {name: read_secret(services[JOB], '/run/secrets/' + name) for name in SECRET_NAMES}
    effective = {name: value.rstrip(b'\n') for name, value in secrets.items()}
    if any(not value for value in effective.values()):
        raise DeploymentPrerequisite('Required Findings history reconstruction secret is empty after startup newline handling', category='secret')
    if any(b'\0' in value for value in effective.values()):
        raise DeploymentPrerequisite('Findings history secrets must not contain NUL bytes', category='secret')
    # Go's string validator counts Unicode code points, treating each invalid
    # UTF-8 byte as one RuneError. Preserve that behavior for existing byte salts.
    salt_length = len(effective['TASK_REPORT_CRYPTO_V1_SALT'].decode('utf-8', errors='surrogateescape'))
    if salt_length < 32:
        raise DeploymentPrerequisite('Findings history report-encryption salt must contain at least 32 characters after startup newline handling', category='secret')
    for name in SECRET_NAMES[1:]:
        if fingerprints is not None and fingerprints.get(name) != hashlib.sha256(secrets[name]).hexdigest():
            raise DeploymentPrerequisite('Report-encryption secret fingerprint mismatch before Findings history reconstruction: ' + name, category='secret')
    if restoration_required:
        from main import sql
        from restoration import literal
        databases = json.loads(sql(services['osi-postgres'], 'postgres',
                                   'SELECT json_agg(datname) FROM pg_database'))
        if not isinstance(databases, list) or not all(isinstance(name, str) for name in databases):
            raise DeploymentPrerequisite('Unable to observe the destination database catalog for Findings history preflight')

        def connect_allowed(database: str) -> bool:
            value = sql(services['osi-postgres'], 'postgres',
                        "SELECT has_database_privilege(" + literal(config.environment['DB_USERNAME'])
                        + ", " + literal(database) + ", 'CONNECT')")
            if value not in ('t', 'f'):
                raise DeploymentPrerequisite('Unable to observe configured application CONNECT privilege')
            return value == 't'

        target_missing = config.environment['DB_NAME'] not in databases
        if target_missing or not connect_allowed(config.environment['DB_NAME']):
            # An interrupted full restore may leave a dropped database, or a
            # created database between PUBLIC revocation and application grants.
            # Observe that state through trusted maintenance access; never infer
            # it from a failed application connection or grant extra privileges.
            config.target_probe_deferred = True
            maintenance_connect = connect_allowed('postgres')
            if maintenance_connect:
                probe_database(services, config, secrets['DB_PASSWORD'], database='postgres')
            from diagnostics import customer
            reason = 'is absent' if target_missing else 'lacks its application CONNECT grant'
            customer('Findings history target database ' + reason + ' during full-restoration preflight; '
                     'its connection check is deferred until verified PostgreSQL restoration. '
                     + ('Configured application credentials, network and TLS were checked through the maintenance database.'
                        if maintenance_connect else
                        'The application role lacks maintenance CONNECT; target authentication, network and TLS have not yet been validated.'))
    if not config.target_probe_deferred:
        probe_database(services, config, secrets['DB_PASSWORD'])
    probe_command(config)
    return config, secrets


def copy_secrets(name: str, config: HelperConfig, secrets: Dict[str, bytes]) -> None:
    """Copy only required secrets into stopped helper storage, preserving runtime UID."""
    import io
    import tarfile
    from capture import work_environment
    from process_diagnostics import run_command
    owner = config.user.split(':')
    uid, gid = int(owner[0]), int(owner[1]) if len(owner) > 1 else int(owner[0])
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w') as archive:
        directory = tarfile.TarInfo('secrets')
        directory.type = tarfile.DIRTYPE
        directory.uid, directory.gid, directory.mode = uid, gid, 0o500
        archive.addfile(directory)
        if not set(secrets) <= set(SECRET_NAMES):
            raise MigrationError('Unsupported helper secret names')
        for key in secrets:
            entry = tarfile.TarInfo('secrets/' + key)
            entry.uid, entry.gid, entry.mode = uid, gid, 0o400
            entry.size = len(secrets[key])
            archive.addfile(entry, io.BytesIO(secrets[key]))
    # Stdin tar headers already carry the runtime UID/GID. Docker 20.10's -a
    # instead looks up the container user in the daemon host's account database.
    result = run_command(['docker', 'cp', '-', name + ':/run'],
                         'Transfer required Findings history secrets to stopped helper',
                         data=buffer.getvalue(), env=work_environment(), stdout_kind='secret')
    if result.returncode:
        raise CredentialsTransferError('Could not provide the required credentials to the Findings history migration service.')


def probe_database(services: Dict[str, Any], config: HelperConfig, password: bytes, *,
                   database: Optional[str] = None) -> None:
    """Check configured application authentication/network/TLS with installed psql.

    Reuse the PostgreSQL image already required for state readers, without any
    additional image dependency. This read-only connection is distinct from the
    packaged command's later schema, privilege, source and transaction checks.
    """
    image = services['osi-postgres'].get('Image', '')
    if not isinstance(image, str) or re.fullmatch(r'sha256:[0-9a-f]{64}', image) is None:
        raise DeploymentPrerequisite('Installed PostgreSQL image ID unavailable for application connection probe')
    source = config.environment
    environment = {key: value for key, value in source.items() if key.startswith('PGSSL') or key == 'PGAPPNAME'}
    environment.update(PGHOST=source['DB_HOST'], PGPORT=source.get('DB_PORT', '5432'),
                       PGUSER=source['DB_USERNAME'], PGDATABASE=database or source['DB_NAME'],
                       PGSSLMODE=source.get('DB_SSL_MODE', 'disable'), PGCONNECT_TIMEOUT='15')
    reader = HelperConfig(image, config.user, config.network, environment, config.mounts, config.work_id)
    script = 'PGPASSWORD=$(cat /run/secrets/DB_PASSWORD); export PGPASSWORD; exec psql -X -v ON_ERROR_STOP=1 -At -c "SELECT 1"'
    try:
        with created_helper(reader, [script], entrypoint='/bin/sh', command='-ceu') as name:
            copy_secrets(name, reader, {'DB_PASSWORD': password})
            output = docker('start', '--attach', name, step='Findings history database connection prerequisite')
            observed = json.loads(docker('inspect', name, step='Inspect Findings history database connection probe'))
            if (output.strip() != '1' or len(observed) != 1
                    or observed[0].get('State', {}).get('Running') is not False
                    or observed[0].get('State', {}).get('ExitCode') != 0):
                raise MigrationError('Configured Findings history database connection probe did not succeed')
    except (MigrationError, ValueError) as error:
        raise DeploymentPrerequisite('Configured Findings history database connection prerequisite failed; '
                                     'check the schema-job database role/password, host, network and TLS settings',
                                     restore_fact='Configured Findings history database connection prerequisite failed') from error


class ProgressReporter:
    """Log safe progress events and sample terminal output without delaying reads."""
    SUBSTEPS = {
        'Preparation': (
            'initializing command and database connection',
            'checking prerequisites and acquiring locks',
            'inventorying retained evidence',
            'checking report identities',
            'creating isolated workspace',
        ),
        'Replay': ('reconstructing daily states', 'counting reconstructed rows'),
        'Validation': (
            'fingerprinting source tables',
            'checking history invariants in pg_temp',
            'comparing normalized history in pg_temp',
            'checking history invariants in application',
            'comparing normalized history in application',
            'fingerprinting published history',
        ),
        'Publication': ('publishing reconstructed history and read models',),
        'Finalization': ('saving completion manifest and committing',),
    }

    def __init__(self, clock: Callable[[], float] = time.monotonic) -> None:
        self.clock = clock
        self.started = self.last_report = clock()

    def report(self, line: bytes) -> None:
        """Retain each event; emit at most one sample per interval, starting at 30s."""
        from capture import format_duration
        from diagnostics import customer, technical
        fields = line.decode('utf-8', errors='replace').split(' | ')
        if len(fields) < 5:
            return
        phase = re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ (Preparation|Replay|Validation|Publication|Finalization)', fields[0])
        if phase is None or re.fullmatch(r'(?:progress=unknown|[0-9]+\.[0-9]+% \([0-9]+ from [0-9]+\))', fields[2]) is None:
            return
        name = phase.group(1)
        # Backend detail fields may contain customer data. Only known, fixed
        # substep descriptions and strictly numeric progress/timing are retained.
        step = fields[1] if fields[1] in self.SUBSTEPS[name] else 'unrecognized substep'
        step_elapsed = fields[4] if re.fullmatch(r'step elapsed=[0-9.hms]+', fields[4]) else 'step elapsed=unknown'
        remaining = fields[3] if re.fullmatch(
            r'step remaining=(?:[0-9.hms]+(?: \(estimate\))?|unknown(?: \(waiting for measurable progress\))?)',
            fields[3],
        ) else 'step remaining=unknown'
        technical('Findings history progress: {0} | {1} | {2} | {3} | {4}'.format(
            fields[0], step, fields[2], remaining, step_elapsed))
        now = self.clock()
        if now - self.last_report < PROGRESS_INTERVAL:
            return
        self.last_report = now
        progress = fields[2].replace(' from ', ' of ')
        if progress == 'progress=unknown':
            progress = 'progress unknown'
        customer('  Reconstruction in progress: {0} — {1}; {2}; {3} elapsed total'.format(
            name.lower(), step, progress, format_duration(now - self.started)), flush=True)

    def finish(self) -> None:
        """Report completion only after the caller confirms the successful result."""
        from capture import format_duration
        from diagnostics import customer
        customer('  Reconstruction completed; {0} elapsed total'.format(
            format_duration(self.clock() - self.started)), flush=True)


class RepairDiagnostics:
    """Recognize bounded, complete repair records; never retain arbitrary text.

    These records explain execution, not authorize it: the shell's exit-status
    gate alone decides whether reconstruction starts.
    """
    TABLES = ('observation', 'host_detail_entry', 'log_entry')
    REFUSALS = (
        r'refusing repair: existing reconstruction manifest with ([0-9]{1,19}) orphan evidence rows',
        r'refusing repair: ([0-9]{1,19}) orphan observations are linked to finding history',
        r'apply the datapoint evidence cascade migration before repair: missing constraint on (observation|host_detail_entry|log_entry)',
    )

    def __init__(self, token: str) -> None:
        # Backend errors may contain newlines and marker-like strings. Match
        # only this invocation's unpredictable wrapper framing.
        self.marker = ('OSI repair ' + token + ' ').encode('ascii')
        self.started = False
        self.exit_status = None  # type: Optional[int]
        self.reasons = []  # type: List[str]
        self.counts_reported = False

    @staticmethod
    def valid_count(value: Any) -> bool:
        return type(value) is int and 0 <= value <= 9223372036854775807

    def report(self, line: bytes) -> None:
        from diagnostics import customer, technical
        from validation import unique_object
        if line == self.marker + b'start' and not self.started:
            self.started = True
            customer('  Orphan evidence repair started.', flush=True)
            return
        if not self.started or self.exit_status is not None:
            return
        status = re.fullmatch(re.escape(self.marker) + rb'exit ([0-9]{1,3})', line)
        if status is not None and int(status.group(1)) <= 255:
            self.exit_status = int(status.group(1))
            technical('Orphan evidence repair exit status: ' + str(self.exit_status))
            if self.exit_status == 0:
                customer('  Orphan evidence repair succeeded.', flush=True)
            return
        try:
            text = line.decode('ascii')
        except UnicodeError:
            return
        for index, pattern in enumerate(self.REFUSALS):
            match = re.fullmatch(pattern, text)
            if match is not None:
                if index < 2 and not self.valid_count(int(match.group(1))):
                    return
                if text not in self.reasons and len(self.reasons) < len(self.REFUSALS):
                    self.reasons.append(text)
                    technical('Orphan evidence repair: ' + text)
                return
        if self.counts_reported:
            return
        try:
            value = json.loads(text, object_pairs_hook=unique_object)
        except (ValueError, MigrationError, RecursionError):
            return
        if (not isinstance(value, dict)
                or set(value) != {'orphanRows', 'linkedOrphanObservations', 'applied'}
                or type(value['applied']) is not bool
                or not self.valid_count(value['linkedOrphanObservations'])):
            return
        counts = value['orphanRows']
        if (not isinstance(counts, dict) or set(counts) != set(self.TABLES)
                or not all(self.valid_count(counts[key]) for key in self.TABLES)):
            return
        self.counts_reported = True
        technical('Orphan evidence repair counts: ' + ', '.join(
            key + '=' + str(counts[key]) for key in self.TABLES)
            + '; linked orphan observations=' + str(value['linkedOrphanObservations']))

    def failure(self, returncode: int) -> str:
        status = self.exit_status if self.exit_status is not None else returncode
        detail = '; '.join(self.reasons)
        return 'Orphan evidence repair failed (exit status {}).{}'.format(
            status, ' ' + detail if detail else '')


def run_reconstruction(config: HelperConfig, secrets: Dict[str, bytes]) -> Dict[str, Any]:
    """Run the normal validating command, streaming safe progress without a deadline."""
    import selectors
    import subprocess
    from capture import work_environment
    from guard import FINDINGS_FROM, FINDINGS_THROUGH, valid_findings_result
    from process_diagnostics import Capture, ProcessRecord, failure_outcome
    from validation import unique_object
    token = uuid.uuid4().hex
    with created_helper(config, ['-c', REPAIR_SEQUENCE.replace('@TOKEN@', token), 'osi-repair-findings', COMMAND,
                                 '--from', FINDINGS_FROM, '--through', FINDINGS_THROUGH],
                        command='/bin/sh') as name:
        copy_secrets(name, config, secrets)
        args = ['docker', 'start', '--attach', name]
        record = ProcessRecord(args, 'Findings history reconstruction', stdout='payload', stderr='sql')
        diagnostic = Capture('sql')
        record.captures['stderr'] = diagnostic
        process = None
        output, pending = bytearray(), bytearray()
        discard_line = False
        progress = ProgressReporter()
        repair = RepairDiagnostics(token)
        try:
            process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       env=work_environment())
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ, 'stdout')
                selector.register(process.stderr, selectors.EVENT_READ, 'stderr')
                while selector.get_map():
                    for key, _ in selector.select(timeout=1):
                        chunk = os.read(key.fileobj.fileno(), 65536)
                        if not chunk:
                            selector.unregister(key.fileobj)
                            continue
                        if key.data == 'stdout':
                            if len(output) + len(chunk) > RESULT_LIMIT:
                                raise MigrationError('Findings history reconstruction result exceeds supported size')
                            output.extend(chunk)
                        else:
                            diagnostic.add(chunk)
                            for part in chunk.splitlines(keepends=True):
                                if not discard_line:
                                    pending.extend(part)
                                    if len(pending) > 4096:
                                        pending.clear()
                                        discard_line = True
                                if part.endswith(b'\n'):
                                    if not discard_line:
                                        line = bytes(pending).rstrip(b'\n')
                                        repair.report(line)
                                        if repair.exit_status == 0:
                                            progress.report(line.rstrip(b'\r'))
                                    pending.clear()
                                    discard_line = False
            process.wait()
            record.finish(process.returncode)
            observed = json.loads(docker('inspect', name, step='Inspect Findings history reconstruction outcome'))
            if (process.returncode != 0 or len(observed) != 1
                    or observed[0].get('State', {}).get('Running') is not False
                    or observed[0].get('State', {}).get('ExitCode') != 0):
                if repair.exit_status != 0:
                    raise MigrationError(repair.failure(process.returncode))
                raise MigrationError('Findings history reconstruction failed.')
            try:
                def invalid_constant(value: str) -> None:
                    raise ValueError('Non-finite JSON constant')
                result = json.loads(output.decode('utf-8'), object_pairs_hook=unique_object,
                                    parse_constant=invalid_constant)
                if not valid_findings_result(result) or len(json.dumps(result).encode()) > RESULT_LIMIT:
                    raise ValueError
            except (ValueError, UnicodeError, MigrationError):
                raise MigrationError('Could not confirm that Findings history reconstruction completed successfully.') from None
            progress.finish()
            return result
        except BaseException as error:
            outcome = failure_outcome(error, process)
            if process is not None and process.poll() is None:
                process.kill()
                process.wait()
            record.finish(process.returncode if process else None, outcome)
            raise
        finally:
            if process is not None:
                if process.poll() is None:
                    process.kill()
                process.wait()
                process.stdout.close()
                process.stderr.close()
