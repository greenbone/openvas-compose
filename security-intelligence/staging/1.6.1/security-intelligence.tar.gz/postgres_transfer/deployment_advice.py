"""Advisory deployment commands, independent of migration authorization."""

import shlex
import shutil
import sys
from typing import Optional

EXECUTABLES = (('os-container-management', 'os-cli'), ('openvas-deployment', 'openvas-deployment'),
               ('openvas-install', 'openvas-install-cli'))
SELECTION_PROMPT = 'Select deployment tool [1: OS Container Management, 2: openvas-deployment, 3: openvas-install, any other key: other]: '


def render(tool: str, action: str, version: str) -> str:
    """Return commands for the operator to run separately, never execute them."""
    version = shlex.quote(version)
    if tool == 'os-container-management':
        return 'OS Container Management:\n  os-cli container-management upgrade-product security-intelligence --version ' + version
    if tool == 'openvas-deployment':
        download = ('Download the selected version first, and wait for success:'
                    if action == 'upgrade' else
                    'If this version is not downloaded, download it first and wait for success:')
        return ('openvas-deployment: Run from the original deployment working directory\n'
                '(replace <deployment-working-directory> below with the actual one)\n'
                '  cd "<deployment-working-directory>"\n'
                + download + '\n'
                '  openvas-deployment --product security-intelligence --update --version ' + version + '\n'
                'After the download succeeds:\n'
                '  openvas-deployment --product security-intelligence --run --version ' + version)
    if tool == 'openvas-install':
        if action == 'redeploy':
            return ('openvas-install: Check installer-persisted status first:\n'
                    '  openvas-install-cli product list\n'
                    'Choose the applicable alternative (these are alternatives, not one sequence):\n'
                    'If status is Running, restart using the installer recorded version:\n'
                    '  openvas-install-cli product restart security_intelligence\n'
                    'If status is Failed/Stopped, start the selected version:\n'
                    '  openvas-install-cli product start security_intelligence --version ' + version)
        if action == 'downgrade':
            return ('openvas-install:\n'
                    '  (openvas-install-cli product delete security_intelligence --preserve-user-data --preserve-images)\n'
                    'Only after deletion completes successfully:\n'
                    '  openvas-install-cli product start security_intelligence --version ' + version)
        return 'openvas-install:\n  openvas-install-cli product update security_intelligence --version ' + version
    deployment_action = action if action == 'redeploy' else action + ' to'
    return 'Use your deployment procedure to {} OPENVAS Security Intelligence {}.'.format(deployment_action, version)


class HostAdvice:
    """Select a tool lazily, only when an actionable recommendation is printed."""

    def __init__(self, tool: Optional[str] = None, source_version: str = '1.6.0',
                 target_version: str = '1.7.0') -> None:
        self.tool = tool
        self.source_version = source_version
        self.target_version = target_version

    def show(self, action: str, version: Optional[str] = None, *, file=None) -> None:
        from diagnostics import customer, prompt

        if self.tool is None:
            self.tool = next((tool for tool, executable in EXECUTABLES
                              if shutil.which(executable)), None)
            if self.tool is None:
                self.tool = 'manual'
                if sys.stdin.isatty() and sys.stdout.isatty():
                    prompt(SELECTION_PROMPT)
                    try:
                        selected = input(SELECTION_PROMPT).strip()
                    except (EOFError, KeyboardInterrupt, OSError):
                        selected = ''
                    self.tool = {'1': 'os-container-management', '2': 'openvas-deployment',
                                 '3': 'openvas-install', '4': 'manual'}.get(selected, 'manual')
                else:
                    customer('No supported deployment executable detected and no interactive terminal is available; using generic deployment advice.', file=file)
        customer(render(self.tool, action, version or self.target_version), file=file)
