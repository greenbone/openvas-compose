"""Authorize supported Security Intelligence startup using ordinary volume mounts.

Database mounts are strictly read-only. Only the dedicated non-database state
volume is writable. This entrypoint uses Python 3.11's standard library only.
"""

import argparse
import hashlib
import importlib.util
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

LEGACY = (
    "asset_management_postgres",
    "vulnerability_intelligence_postgres",
    "management_console_postgres",
    "notification_service_postgres",
    "keycloak_postgres",
)
MIGRATION = "security-intelligence-postgres"


class Rejected(Exception):
    """Mounted evidence does not authorize database startup."""


class DowngradeRequired(Rejected):
    """An otherwise classified refusal has an actionable deployment recovery."""

    def __init__(self, message: str, version: str) -> None:
        super().__init__(message)
        self.version = version


def show_downgrades(version: str) -> None:
    """Load the explicitly supplied sibling runtime and print all alternatives.

    Isolated Python omits the script directory from its import search path. Use
    this exact runtime file so deployed secrets and packaged scripts behave alike.
    This neither detects a host tool nor calls its executable.
    """
    spec = importlib.util.spec_from_file_location(
        "migration_deployment_advice", Path(__file__).resolve().with_name("deployment_advice.py")
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    print("Downgrade to OPENVAS Security Intelligence " + version + ":", file=sys.stderr)
    for tool in ("os-container-management", "openvas-deployment", "openvas-install"):
        print(module.render(tool, "downgrade", version), file=sys.stderr)


def entries(path: Path) -> List[Path]:
    """Require a readable mounted directory; missing mounts are never fresh."""
    if path.is_symlink() or not path.is_dir():
        raise Rejected(f"Missing or invalid mount: {path.name}")
    return list(path.iterdir())


def unique_fields(pairs: List[Tuple[str, Any]]) -> Dict[str, Any]:
    """Reject contradictory duplicate JSON keys rather than silently choosing one."""
    value: Dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise Rejected("Duplicate fields in migration record")
        value[key] = item
    return value


def record(state: Path, name: str) -> Optional[Dict[str, Any]]:
    """Read optional bounded JSON evidence without modifying its contents.

    Args:
        state: Validated mounted directory.
        name: Trusted internal record basename; no arbitrary path sanitization.

    Returns:
        Object contents, or None when absent. Identity checks belong to callers.

    Raises:
        Rejected: Symlink, non-file, oversize, duplicate fields or non-object root.
        OSError: File inspection or reading fails.
        ValueError: JSON is malformed."""
    path = state / name
    if not path.exists() and not path.is_symlink():
        return None
    if path.is_symlink() or not path.is_file():
        raise Rejected(f"Invalid record: {name}")
    if path.stat().st_size > 65536:
        raise Rejected(f"Oversized record: {name}")
    value = json.loads(path.read_text(), object_pairs_hook=unique_fields)
    if not isinstance(value, dict):
        raise Rejected(f"Invalid record: {name}")
    return value


def valid_version(value: Any) -> bool:
    """Require SemVer, including no leading zero in numeric prerelease fields."""
    if (
        not isinstance(value, str)
        or re.fullmatch(
            r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?",
            value,
        )
        is None
    ):
        return False
    prerelease = value.split("+", 1)[0].partition("-")[2]
    return all(
        not (part.isdigit() and len(part) > 1 and part[0] == "0")
        for part in prerelease.split(".")
    )


def version_at_most(requested: str, ceiling: str) -> bool:
    """Compare already validated SemVer precedence, ignoring build metadata."""

    def precedence(value: str) -> Tuple[Any, ...]:
        core, separator, pre = value.split("+", 1)[0].partition("-")
        return (
            *map(int, core.split(".")),
            not separator,
            (
                tuple(
                    (0, int(part)) if part.isdigit() else (1, part)
                    for part in pre.split(".")
                )
                if separator
                else ()
            ),
        )

    return precedence(requested) <= precedence(ceiling)


def hex_value(value: Any, length: int) -> bool:
    """Validate fixed-size lowercase record identities."""
    return (
        isinstance(value, str)
        and re.fullmatch("[0-9a-f]{" + str(length) + "}", value) is not None
    )


def installation_identity(project: str) -> str:
    """Bind portable durable migration records to the exact Compose project."""
    return hashlib.sha256(
        json.dumps([project], separators=(",", ":")).encode()
    ).hexdigest()


def dump_success_identity(ready: Dict[str, Any], project: str) -> Dict[str, Any]:
    """Validate installation-level successful-dump evidence and its provenance.

    Args:
        ready: Candidate dump-ready record; not mutated.
        project: Selected Compose installation used to check the recorded binding.

    Returns:
        Installation identity only. Capture/hash fields are diagnostic provenance;
        they do not authenticate or select the independently chosen backup.
        This does not probe Docker or verify backup files and decryption.

    Raises:
        Rejected: Structure or recorded installation-bound completion is invalid."""
    daemon = ready.get("daemon")
    installation = installation_identity(project)
    if (
        type(ready.get("schema")) is not int
        or ready.get("schema") != 2
        or ready.get("migration") != MIGRATION
        or ready.get("phase") != "dump-ready"
        or ready.get("project") != project
        or not isinstance(daemon, str)
        or not daemon
        or ready.get("installation") != installation
        or not hex_value(ready.get("capture_id"), 32)
        or not hex_value(ready.get("manifest_sha256"), 64)
        or not isinstance(ready.get("source_version"), str)
        or not ready["source_version"].strip()
        or not isinstance(ready.get("backup"), str)
        or not Path(ready["backup"]).is_absolute()
    ):
        raise Rejected("Invalid installation-bound completed backup evidence")
    return {"installation": ready["installation"]}


def valid_destination_mapping(value: Any) -> bool:
    """Require complete named successful mappings without probing current PGDATA."""
    services = {"asset_management", "vulnerability_intelligence", "management_console",
                "websocket_tunnel", "notification", "keycloak"}
    if not isinstance(value, dict) or set(value) != services:
        return False
    for entry in value.values():
        if not isinstance(entry, dict) or set(entry) != {"database", "role"}:
            return False
        if any(not isinstance(item, str) or not item or "\x00" in item
               or len(item.encode("utf-8")) > 63 for item in entry.values()):
            return False
    return (len({entry["database"] for entry in value.values()}) == 4
            and len({entry["role"] for entry in value.values()}) == 6
            and value["asset_management"]["database"] == value["vulnerability_intelligence"]["database"]
            and value["management_console"]["database"] == value["websocket_tunnel"]["database"])


FINDINGS_FROM = "2000-01-01"
FINDINGS_THROUGH = "2028-01-01"


def valid_findings_result(value: Any) -> bool:
    """Require a published result for the fixed inclusive UTC-day period."""
    return (isinstance(value, dict) and value.get("published") is True
            and value.get("from") == FINDINGS_FROM + "T00:00:00Z"
            and value.get("through") == FINDINGS_THROUGH + "T00:00:00Z")


def valid_findings_history(value: Any) -> bool:
    """Validate self-contained historical reconstruction evidence without DB access."""
    return (isinstance(value, dict)
            and value.get("from") == FINDINGS_FROM
            and value.get("through") == FINDINGS_THROUGH
            and valid_findings_result(value.get("result")))


def valid_completion_basis(value: Dict[str, Any]) -> bool:
    """Completion records required startup, not continued application health."""
    return (value.get("completion_basis") == "verified-data-reconstruction-and-startup"
            and value.get("findings_history_reconstructed") is True
            and valid_findings_history(value.get("findings_history"))
            and value.get("applications_activated") is True)


def completion_identity(completion: Dict[str, Any], project: str) -> Dict[str, Any]:
    """Validate independent installation-bound restoration and startup evidence."""
    daemon = completion.get("daemon")
    installation = installation_identity(project)
    if (type(completion.get("schema")) is not int
            or completion.get("schema") != 2
            or completion.get("migration") != MIGRATION
            or completion.get("project") != project
            or not isinstance(daemon, str) or not daemon
            or completion.get("installation") != installation
            or completion.get("data_verified") is not True
            or not valid_completion_basis(completion)
            or not valid_destination_mapping(completion.get("destination_mapping"))
            or any(not hex_value(completion.get(key), size)
                   for key, size in (("installation", 64), ("capture_id", 32), ("manifest_sha256", 64)))):
        raise Rejected("Invalid completed migration identity or required startup evidence")
    return {key: completion[key] for key in ("installation", "capture_id", "manifest_sha256")}


def completed(state: Path, project: str) -> bool:
    """Validate successful restoration independently of dump capture or PGDATA."""
    completion = record(state, "migration-complete.json")
    if completion is None:
        return False
    completion_identity(completion, project)
    return True


def authorize(args: argparse.Namespace) -> str:
    """Derive startup eligibility from final successes and legacy contents.

    Recovery journals and publication staging are ignored. This mounted-files
    check neither contacts Docker nor coordinates concurrent deployments.
    """
    state = Path(args.state)
    entries(state)
    mounts = {name: entries(Path(args.volumes) / name)
              for name in (*LEGACY, "osi_postgres")}
    ready = record(state, "dump-ready.json")
    if ready is not None:
        dump_success_identity(ready, args.project)
    if completed(state, args.project):
        completion = record(state, "migration-complete.json")
        if ready is not None and ready["installation"] != completion["installation"]:
            raise Rejected("Successful-operation records belong to different installations")
        return "Startup allowed: Your database migration is complete. You can use this version or upgrade to a newer version."
    if ready is None and not any(mounts[name] for name in LEGACY):
        return "Startup allowed: This is a new installation. No database migration is needed."
    if ready is None:
        raise DowngradeRequired(
            "Startup blocked: Your existing databases must be backed up before this upgrade can continue. "
            f"Return to OPENVAS Security Intelligence {args.source_version} using the instructions below, "
            "then follow the migration procedure to create the backup.",
            args.source_version,
        )
    if not valid_version(args.requested) or not valid_version(args.allowed):
        raise Rejected("Pending migration requires valid PRODUCT_VERSION at or below valid MIGRATION_TARGET_VERSION")
    if not version_at_most(args.requested, args.allowed):
        raise DowngradeRequired(
            "Startup blocked: Your database migration is not finished. "
            f"Return to OPENVAS Security Intelligence {args.allowed} using the instructions below, "
            "then follow the migration procedure to restore your backup. "
            "Once migration is complete, you can upgrade to a newer version.",
            args.allowed,
        )
    return ("Startup allowed: Your migration backup is complete. "
            f"You can run OPENVAS Security Intelligence {args.allowed} or an earlier version while restoration is pending. "
            "Follow the migration procedure to restore your backup and finish moving your existing data. "
            "Restoring the backup will replace any data created in the new databases before restoration.")


def main() -> int:
    """Return nonzero on rejection; health status never grants authorization."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--volumes", default="/volumes")
    parser.add_argument("--state", default="/state")
    parser.add_argument("--project", default=os.environ.get("COMPOSE_PROJECT_NAME", ""))
    parser.add_argument("--requested", default=os.environ.get("PRODUCT_VERSION", ""))
    parser.add_argument(
        "--allowed", default=os.environ.get("MIGRATION_TARGET_VERSION", "")
    )
    parser.add_argument("--source-version", default=os.environ.get("MIGRATION_ADVICE_SOURCE_VERSION", "1.6.0"),
                        help="Source release for deployment advice only (default: 1.6.0)")
    args = parser.parse_args()
    try:
        if not args.project:
            raise Rejected("Compose installation project is required")
        print(authorize(args))
        return 0
    except (Rejected, OSError, ValueError) as error:
        print(
            str(error) if isinstance(error, DowngradeRequired) else
            f"Migration authorization rejected: {error}; requested={args.requested!r}, allowed={args.allowed!r}",
            file=sys.stderr,
        )
        if isinstance(error, DowngradeRequired) and valid_version(error.version):
            show_downgrades(error.version)
        return 1


if __name__ == "__main__":
    sys.exit(main())
