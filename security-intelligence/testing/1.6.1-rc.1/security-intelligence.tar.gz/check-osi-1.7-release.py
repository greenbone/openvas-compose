#!/usr/bin/env python3
"""Find the latest published stable Security Intelligence 1.7.x archive."""

import argparse
import json
import re
import sys
from datetime import datetime
from http.client import HTTPException
from typing import Any, Dict, List, Optional, Sequence, Tuple
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


API = "https://api.github.com/repos/greenbone/openvas-compose/"
PRODUCTION = "security-intelligence/production"


class CheckError(Exception):
    """GitHub metadata cannot establish a release result."""


def request_json(endpoint: str, **query: str) -> Any:
    request = Request(
        API + endpoint + "?" + urlencode(query),
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "check-osi-1.7-release",
        },
    )
    try:
        with urlopen(request, timeout=20) as response:
            return json.load(response)
    except HTTPError as error:
        if error.code in (403, 429):
            raise CheckError(
                "GitHub returned HTTP {} (access denied or rate limited); try again later.".format(
                    error.code,
                )
            ) from error
        raise


def read_list(endpoint: str, **query: str) -> List[Dict[str, Any]]:
    data = request_json(endpoint, **query)
    if not isinstance(data, list):
        raise CheckError("Invalid GitHub response for " + endpoint)
    entries: List[Dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            raise CheckError("Invalid GitHub response for " + endpoint)
        entries.append(item)
    return entries


def directory_contents(path: str, revision: str) -> List[Dict[str, Any]]:
    entries = read_list("contents/" + path, ref=revision)
    if len(entries) >= 1000:
        raise CheckError("GitHub Contents API directory limit reached for " + path)
    for item in entries:
        if (not isinstance(item.get("name"), str)
                or item.get("type") not in ("dir", "file", "symlink", "submodule")):
            raise CheckError("Invalid directory entry for " + path)
    return entries


def archive_modified(path: str, revision: str) -> str:
    commits = read_list("commits", sha=revision, path=path, per_page="1")
    try:
        date = commits[0]["commit"]["committer"]["date"]
    except (IndexError, KeyError, TypeError) as error:
        raise CheckError("Missing archive commit date for " + path) from error
    if not isinstance(date, str):
        raise CheckError("Invalid archive commit date for " + path)
    # GitHub returns UTC timestamps. Validate the calendar date before reporting success.
    datetime.strptime(date, "%Y-%m-%dT%H:%M:%SZ")
    return date


def release_candidates() -> Tuple[str, List[str]]:
    # Pin all subsequent reads so a publication during the check cannot mix revisions.
    commits = read_list("commits", sha="main", per_page="1")
    revision = commits[0].get("sha") if len(commits) == 1 else None
    if not isinstance(revision, str) or not re.fullmatch(r"[0-9a-f]{40}", revision):
        raise CheckError("Invalid GitHub revision for main")
    entries = directory_contents(PRODUCTION, revision)
    versions = [
        item["name"] for item in entries
        if item["type"] == "dir" and re.fullmatch(
            r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)", item["name"],
        )
    ]
    versions.sort(key=lambda value: tuple(int(part) for part in value.split(".")), reverse=True)
    return revision, versions


def latest_release(versions: Sequence[str], revision: str) -> Optional[Dict[str, str]]:
    for version in versions:
        directory = PRODUCTION + "/" + version
        files = directory_contents(directory, revision)
        if not any(item["name"] == "security-intelligence.tar.gz" and item["type"] == "file"
                   for item in files):
            continue
        return {
            "version": version,
            "last_modified": archive_modified(directory + "/security-intelligence.tar.gz", revision),
            "url": "https://github.com/greenbone/openvas-compose/tree/main/" + directory,
        }
    return None


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__,
        epilog=(
            "No GitHub account or token is required. Last modified is the archive's "
            "latest Git committer date (UTC), an approximation of publication. "
            "Exit codes: 0 = release found, 1 = no release, 2 = check failed."
        ),
    )
    parser.add_argument("--json", action="store_true", help="output JSON (null if no release)")
    args = parser.parse_args(argv)
    try:
        revision, versions = release_candidates()
        release = latest_release([version for version in versions if version.startswith("1.7.")], revision)
        newest = None
        if release is None and not args.json:
            newest = latest_release(
                [version for version in versions if not version.startswith("1.7.")], revision,
            )
    except (CheckError, HTTPException, OSError, ValueError) as error:
        print("Check failed: " + str(error), file=sys.stderr)
        return 2
    if release is None:
        newest_text = newest["version"] + " from " + newest["last_modified"] if newest else "none"
        print("null" if args.json else (
            "No OPENVAS Security Intelligence 1.7.x release found. "
            "Newest release: " + newest_text
        ))
        return 1
    if args.json:
        print(json.dumps(release))
    else:
        print("Latest stable OSI 1.7.x release: " + release["version"])
        print("Last modified (UTC): " + release["last_modified"])
        print(release["url"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
