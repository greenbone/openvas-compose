#!/bin/sh
# Shared database infrastructure. Identifiers are explicit inputs, never resolved here.
# Keep initialization operations idempotent; stable identities need explicit rename/removal
# migrations. Existing ownership and application contents must remain unchanged.
set -eu

operation=$1
export PGAPPNAME=$2
shift 2
# Destination bootstrap policy is defined here for both initialization and restore.
bootstrap_extension=pg_stat_statements
bootstrap_schema=public
# Names reserved by this bootstrap extension (relations, implicit types, routines).
bootstrap_names=pg_stat_statements,pg_stat_statements_info,pg_stat_statements_reset,_pg_stat_statements,_pg_stat_statements_info
if [ -n "${POSTGRES_PASSWORD_FILE:-}" ]; then
  PGPASSWORD=$(cat "$POSTGRES_PASSWORD_FILE")
  export PGPASSWORD
fi
run_psql() {
  psql -X -w -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" "$@"
}

create_extension() {
    test "$#" -eq 4
    # Initialization may select the image default version; restore supplies the validated version.
    if [ -n "$4" ]; then
      run_psql --dbname "$1" -v extension="$2" -v schema="$3" -v version="$4" <<'SQL'
CREATE EXTENSION :"extension" WITH SCHEMA :"schema" VERSION :'version';
SQL
    else
      run_psql --dbname "$1" -v extension="$2" -v schema="$3" <<'SQL'
CREATE EXTENSION IF NOT EXISTS :"extension" WITH SCHEMA :"schema";
SQL
    fi
}

case "$operation" in
  bootstrap-plan)
    test "$#" -eq 0
    printf '%s\t%s\t%s\n' "$bootstrap_extension" "$bootstrap_schema" "$bootstrap_names"
    ;;
  bootstrap)
    test "$#" -eq 1
    create_extension "$1" "$bootstrap_extension" "$bootstrap_schema" ""
    ;;
  databases)
    test "$#" -eq 10
    vulnerability_db=$1 management_db=$2 notification_db=$3 keycloak_db=$4
    shift 4
    asset_user=$1 vulnerability_user=$2 management_user=$3 wst_user=$4 notification_user=$5 keycloak_user=$6
    run_psql --dbname postgres \
      -v vulnerability_db="$vulnerability_db" -v management_db="$management_db" \
      -v notification_db="$notification_db" -v keycloak_db="$keycloak_db" \
      -v asset_user="$asset_user" -v vulnerability_user="$vulnerability_user" \
      -v management_user="$management_user" -v wst_user="$wst_user" \
      -v notification_user="$notification_user" -v keycloak_user="$keycloak_user" <<'SQL'
SELECT format('CREATE DATABASE %I TEMPLATE template0', :'vulnerability_db') WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = :'vulnerability_db')
\gexec
SELECT format('CREATE DATABASE %I TEMPLATE template0', :'management_db') WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = :'management_db')
\gexec
SELECT format('CREATE DATABASE %I OWNER %I TEMPLATE template0', :'notification_db', :'notification_user') WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = :'notification_db')
\gexec
SELECT format('CREATE DATABASE %I OWNER %I TEMPLATE template0', :'keycloak_db', :'keycloak_user') WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = :'keycloak_db')
\gexec
REVOKE ALL ON DATABASE :"vulnerability_db" FROM PUBLIC;
REVOKE ALL ON DATABASE :"management_db" FROM PUBLIC;
REVOKE ALL ON DATABASE :"notification_db" FROM PUBLIC;
REVOKE ALL ON DATABASE :"keycloak_db" FROM PUBLIC;
GRANT CONNECT, CREATE, TEMPORARY ON DATABASE :"vulnerability_db" TO :"asset_user", :"vulnerability_user";
GRANT CONNECT, CREATE, TEMPORARY ON DATABASE :"management_db" TO :"management_user", :"wst_user";
GRANT CONNECT, CREATE ON DATABASE :"notification_db" TO :"notification_user";
GRANT CONNECT, CREATE ON DATABASE :"keycloak_db" TO :"keycloak_user";
SQL
    for database in "$vulnerability_db" "$management_db" "$notification_db" "$keycloak_db"; do
      run_psql --dbname "$database" <<'SQL'
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
SQL
    done
    run_psql --dbname "$management_db" -v management_user="$management_user" -v wst_user="$wst_user" <<'SQL'
GRANT CREATE ON SCHEMA public TO :"management_user", :"wst_user";
SQL
    ;;
  extension)
    create_extension "$@"
    ;;
  *) exit 2 ;;
esac
