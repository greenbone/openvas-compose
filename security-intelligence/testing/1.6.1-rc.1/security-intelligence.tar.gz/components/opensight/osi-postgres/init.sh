#!/bin/sh
set -eu

# Database/role names are stable identities. Additions must stay idempotent;
# renames/removals need explicit migrations. Unsupported name changes may create
# empty databases; initialization does not detect or adopt renamed identities.
if [ -n "${POSTGRES_PASSWORD_FILE:-}" ]; then
  PGPASSWORD=$(cat "$POSTGRES_PASSWORD_FILE")
  export PGPASSWORD
fi

# Keep application secrets out of argv and out of later provisioning processes.
# The subshell also preserves read failures before invoking psql.
run_psql() (
  OSI_ASSET_PASSWORD=$(cat /run/secrets/asset-management-db-password)
  OSI_VULNERABILITY_PASSWORD=$(cat /run/secrets/vulnerability-intelligence-db-password)
  OSI_KEYCLOAK_PASSWORD=$(cat /run/secrets/keycloak-db-password)
  OSI_NOTIFICATION_PASSWORD=$(cat /run/secrets/notification-service-db-password)
  OSI_MANAGEMENT_PASSWORD=$(cat /run/secrets/management-console-db-password)
  export OSI_ASSET_PASSWORD OSI_VULNERABILITY_PASSWORD OSI_KEYCLOAK_PASSWORD \
    OSI_NOTIFICATION_PASSWORD OSI_MANAGEMENT_PASSWORD
  # psql quotes identifier variables separately from password literals.
  psql -X -w -v ON_ERROR_STOP=1 -v VERBOSITY=terse --username "$POSTGRES_USER" \
    -v vulnerability_db_name="$VULNERABILITY_MANAGEMENT_DB_NAME" \
    -v asset_user="$ASSET_MANAGEMENT_DB_USER" \
    -v vulnerability_user="$VULNERABILITY_INTELLIGENCE_DB_USER" \
    -v keycloak_db_name="$KEYCLOAK_DB_NAME" \
    -v keycloak_user="$KEYCLOAK_DB_USER" \
    -v notification_db_name="$NOTIFICATION_SERVICE_DB_NAME" \
    -v notification_user="$NOTIFICATION_SERVICE_DB_USER" \
    -v management_db_name="$MANAGEMENT_CONSOLE_DB_NAME" \
    -v management_user="$MANAGEMENT_CONSOLE_DB_USER" \
    -v wst_user="$MANAGEMENT_CONSOLE_WST_DB_USER" \
    "$@"
)

run_psql --dbname "$POSTGRES_DB" <<'SQL'
\getenv asset_password OSI_ASSET_PASSWORD
\getenv vulnerability_password OSI_VULNERABILITY_PASSWORD
\getenv keycloak_password OSI_KEYCLOAK_PASSWORD
\getenv notification_password OSI_NOTIFICATION_PASSWORD
\getenv management_password OSI_MANAGEMENT_PASSWORD
-- Do not log statements containing credentials, even if synchronization fails.
SET log_statement = 'none';
SET log_min_duration_statement = -1;
SET log_min_duration_sample = -1;
SET log_transaction_sample_rate = 0;
SET log_min_error_statement = 'panic';
SELECT format('CREATE ROLE %I LOGIN', :'asset_user') WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'asset_user')
\gexec
ALTER ROLE :"asset_user" LOGIN PASSWORD :'asset_password';
-- REPORT's session defaults belong to its configured login role, not the server.
-- Reapply on every initialization; role settings also survive database recreation.
ALTER ROLE :"asset_user" SET timezone = 'Etc/UTC';
ALTER ROLE :"asset_user" SET datestyle = 'iso, mdy';
ALTER ROLE :"asset_user" SET lc_messages = 'en_US.utf8';
ALTER ROLE :"asset_user" SET lc_monetary = 'en_US.utf8';
ALTER ROLE :"asset_user" SET lc_numeric = 'en_US.utf8';
ALTER ROLE :"asset_user" SET lc_time = 'en_US.utf8';
ALTER ROLE :"asset_user" SET default_text_search_config = 'pg_catalog.english';
SELECT format('CREATE ROLE %I LOGIN', :'vulnerability_user') WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'vulnerability_user')
\gexec
ALTER ROLE :"vulnerability_user" LOGIN PASSWORD :'vulnerability_password';
SELECT format('CREATE ROLE %I LOGIN', :'keycloak_user') WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'keycloak_user')
\gexec
ALTER ROLE :"keycloak_user" LOGIN PASSWORD :'keycloak_password';
SELECT format('CREATE ROLE %I LOGIN', :'notification_user') WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'notification_user')
\gexec
ALTER ROLE :"notification_user" LOGIN PASSWORD :'notification_password';
SELECT format('CREATE ROLE %I LOGIN', :'management_user') WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'management_user')
\gexec
ALTER ROLE :"management_user" LOGIN PASSWORD :'management_password';
SELECT format('CREATE ROLE %I LOGIN', :'wst_user') WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'wst_user')
\gexec
ALTER ROLE :"wst_user" LOGIN PASSWORD :'management_password';

SQL

# Freeze the application mapping once and pass it explicitly to shared provisioning.
set -- "$VULNERABILITY_MANAGEMENT_DB_NAME" "$MANAGEMENT_CONSOLE_DB_NAME" \
  "$NOTIFICATION_SERVICE_DB_NAME" "$KEYCLOAK_DB_NAME" \
  "$ASSET_MANAGEMENT_DB_USER" "$VULNERABILITY_INTELLIGENCE_DB_USER" \
  "$MANAGEMENT_CONSOLE_DB_USER" "$MANAGEMENT_CONSOLE_WST_DB_USER" \
  "$NOTIFICATION_SERVICE_DB_USER" "$KEYCLOAK_DB_USER"
sh /run/secrets/osi-postgres-provision databases osi-postgres-init "$@"
# Superuser-only infrastructure required by Asset Management.
sh /run/secrets/osi-postgres-provision bootstrap osi-postgres-init "$1"
