#!/bin/sh
set -eu
# The override names one executable, including paths containing spaces.
if [ "${OSI_POSTGRES_PYTHON+x}" = x ]; then
    if ! command -v "$OSI_POSTGRES_PYTHON" >/dev/null 2>&1 ||
        ! "$OSI_POSTGRES_PYTHON" -c 'import sys; sys.exit(sys.version_info < (3, 6) or sys.prefix != sys.base_prefix)' 2>/dev/null; then
        echo 'OSI_POSTGRES_PYTHON must name a Python 3.6 or newer system base interpreter executable.' >&2
        exit 1
    fi
    exec "$OSI_POSTGRES_PYTHON" "$(dirname "$0")/postgres_transfer/main.py" restore "$@"
fi
for python in python3 python python3.11 python3.6; do
    if command -v "$python" >/dev/null 2>&1 &&
        "$python" -c 'import sys; sys.exit(sys.version_info < (3, 6) or sys.prefix != sys.base_prefix)' 2>/dev/null; then
        exec "$python" "$(dirname "$0")/postgres_transfer/main.py" restore "$@"
    fi
done
echo 'Python 3.6 or newer is required (system base interpreter).' >&2
exit 1
